using System.Text.Json;

namespace RxFlowOpsMcp;

public static class Program
{
    public static async Task Main()
    {
        var settings = Settings.FromConfiguration(new SettingsOptions(
            Environment.GetEnvironmentVariable("AZDO_ORG"),
            Environment.GetEnvironmentVariable("AZDO_PROJECT"),
            Environment.GetEnvironmentVariable("AZDO_PAT"),
            bool.TryParse(Environment.GetEnvironmentVariable("OPS_CATALOG_MOCK"), out var mock) && mock,
            (Environment.GetEnvironmentVariable("AZDO_WRITABLE_PROJECTS") ?? Environment.GetEnvironmentVariable("AZDO_PROJECT"))?
                .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)));
       
        var azure = new AzureDevOpsClient(settings);
        var gate = new PermissionGate(settings);
        var tools = new RxFlowTools(
            azure,
            gate,
            settings,
            Environment.GetEnvironmentVariable("MCP_AUDIT_LOG_PATH"));

        string? line;
        while ((line = await Console.In.ReadLineAsync()) is not null)
        {
            try
            {
                using var document = JsonDocument.Parse(line);
                var response = await tools.HandleAsync(document.RootElement);
                if (response is not null)
                    await Console.Out.WriteLineAsync(JsonSerializer.Serialize(response));
            }
            catch (Exception ex)
            {
                await Console.Out.WriteLineAsync(JsonSerializer.Serialize(Rpc.Error(null, -32603, ex.Message)));
            }
            await Console.Out.FlushAsync();
        }
    }
}
