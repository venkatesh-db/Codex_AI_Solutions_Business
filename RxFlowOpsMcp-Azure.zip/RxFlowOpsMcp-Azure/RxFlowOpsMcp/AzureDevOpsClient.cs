using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace RxFlowOpsMcp;

public sealed class AzureDevOpsClient
{
    private readonly Settings settings;
    private readonly HttpClient http = new() { Timeout = TimeSpan.FromSeconds(15) };

    public AzureDevOpsClient(Settings settings) => this.settings = settings;

    public async Task<JsonElement> GetTicketAsync(int id, CancellationToken cancellationToken = default)
    {
        RequireCredentials();
        var request = new HttpRequestMessage(HttpMethod.Get, $"https://dev.azure.com/{Uri.EscapeDataString(settings.Organization)}/{Uri.EscapeDataString(settings.Project)}/_apis/wit/workitems/{id}?api-version=7.1-preview.3");
        request.Headers.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes($":{settings.Pat}")));
        using var response = await http.SendAsync(request, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);
        if (!response.IsSuccessStatusCode) throw new InvalidOperationException($"Azure DevOps returned {(int)response.StatusCode}: {body}");
        using var document = JsonDocument.Parse(body);
        return document.RootElement.Clone();
    }

    private void RequireCredentials()
    {
        if (string.IsNullOrWhiteSpace(settings.Organization) || string.IsNullOrWhiteSpace(settings.Project) || string.IsNullOrWhiteSpace(settings.Pat))
            throw new InvalidOperationException("AZDO_ORG, AZDO_PROJECT, and AZDO_PAT are required for Azure DevOps operations.");
    }
}
