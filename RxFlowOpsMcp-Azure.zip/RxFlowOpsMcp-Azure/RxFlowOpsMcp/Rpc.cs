using System.Text.Json;

namespace RxFlowOpsMcp;

public static class Rpc
{
    public static object Result(JsonElement id, object result) => new { jsonrpc = "2.0", id, result };
    public static object Error(JsonElement? id, int code, string message) => new { jsonrpc = "2.0", id, error = new { code, message } };
}
