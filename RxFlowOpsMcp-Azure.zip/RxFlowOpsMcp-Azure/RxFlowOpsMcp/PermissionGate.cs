namespace RxFlowOpsMcp;

public sealed class PermissionGate(Settings settings)
{
    public void EnsureWritable(string project, string operation)
    {
        if (!settings.WritableProjects.Contains(project))
            throw new InvalidOperationException($"Write operation '{operation}' is not allowed for project '{project}'.");
    }
}
