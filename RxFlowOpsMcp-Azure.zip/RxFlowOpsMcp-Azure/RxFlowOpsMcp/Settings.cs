namespace RxFlowOpsMcp;

public sealed record Settings(string Organization, string Project, string Pat, bool OpsCatalogMock, HashSet<string> WritableProjects)
{
    public static Settings FromConfiguration(SettingsOptions options)
    {
        var org = Required(options.Organization, nameof(options.Organization));
        var project = Required(options.Project, nameof(options.Project));
        var pat = Required(options.Pat, nameof(options.Pat));
        var writable = options.WritableProjects?.Where(p => !string.IsNullOrWhiteSpace(p))
            .Select(p => p.Trim()).ToHashSet(StringComparer.OrdinalIgnoreCase)
            ?? new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (writable.Count == 0) writable.Add(project);
        return new Settings(org, project, pat, options.OpsCatalogMock, writable);
    }

    private static string Required(string? value, string name)
    {
        var trimmed = value?.Trim();
        return string.IsNullOrWhiteSpace(trimmed)
            ? throw new InvalidOperationException($"Required configuration '{name}' is missing.")
            : trimmed;
    }
}

public sealed record SettingsOptions(
    string? Organization,
    string? Project,
    string? Pat,
    bool OpsCatalogMock,
    IEnumerable<string>? WritableProjects);
