using System.Text.Json;

namespace RxFlowOpsMcp;

public sealed class ToolCallHooks(string? auditLogPath = null)
{
    private readonly object sync = new();

    public void Before(string name, IReadOnlyDictionary<string, object?> arguments)
    {
        var entry = new
        {
            timestampUtc = DateTimeOffset.UtcNow,
            eventName = "tool_call",
            tool = name,
            argumentCount = arguments.Count,
            argumentNames = arguments.Keys.Order(StringComparer.Ordinal).ToArray()
        };

        var line = JsonSerializer.Serialize(entry);
        Console.Error.WriteLine(line);

        if (string.IsNullOrWhiteSpace(auditLogPath)) return;
        lock (sync)
        {
            File.AppendAllText(auditLogPath, line + Environment.NewLine);
        }
    }
}
