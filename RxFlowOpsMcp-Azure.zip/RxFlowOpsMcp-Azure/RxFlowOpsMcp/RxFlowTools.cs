using System.Text.Json;

namespace RxFlowOpsMcp;

public sealed class RxFlowTools(AzureDevOpsClient azure, PermissionGate gate, Settings settings, string? auditLogPath = null)
{
    private readonly ToolCallHooks hooks = new(auditLogPath);

    public async Task<object?> HandleAsync(JsonElement request)
    {
        if (!request.TryGetProperty("method", out var method)) return null;
        var name = method.GetString();
        if (name is "notifications/initialized") return null;
        var id = request.TryGetProperty("id", out var requestId) ? requestId : (JsonElement?)null;
        if (name == "initialize")
            return Rpc.Result(requestId, new { protocolVersion = "2024-11-05", capabilities = new { tools = new { } }, serverInfo = new { name = "rxflow-ops", version = "1.0.0" } });
        if (name == "tools/list")
            return Rpc.Result(requestId, new { tools = new[] {
                Tool("get_ticket", "Read an Azure DevOps work item", new { type = "object", properties = new { workItemId = new { type = "integer" } }, required = new[] { "workItemId" } }),
                Tool("list_valid_states", "List supported work item states", new { type = "object", properties = new { } }),
                Tool("get_service_owner", "Get a service owner from the operations catalog", new { type = "object", properties = new { service = new { type = "string" } }, required = new[] { "service" } })
            }});
        if (name != "tools/call") return id is null ? null : Rpc.Error(id, -32601, $"Unknown method '{name}'.");

        var parameters = request.GetProperty("params");
        var tool = parameters.GetProperty("name").GetString()!;
        var args = parameters.TryGetProperty("arguments", out var rawArgs) ? rawArgs : default;
        var argumentMap = new Dictionary<string, object?>();
        if (args.ValueKind == JsonValueKind.Object) foreach (var p in args.EnumerateObject()) argumentMap[p.Name] = p.Value.ToString();
        hooks.Before(tool, argumentMap);
        if (tool is "create_change_request" or "update_ticket_status")
            gate.EnsureWritable(settings.Project, tool);
        object result = tool switch
        {
            "get_ticket" => await GetTicket(args),
            "list_valid_states" => new { content = new[] { new { type = "text", text = "To Do\nDoing\nDone" } } },
            "get_service_owner" when settings.OpsCatalogMock => new { content = new[] { new { type = "text", text = "owner unavailable (mock catalog)" } } },
            "create_change_request" or "update_ticket_status" => throw new InvalidOperationException("Mutating tools require explicit human approval and are not enabled by this server.") ,
            _ => throw new InvalidOperationException($"Unknown tool '{tool}'.")
        };
        return Rpc.Result(id!.Value, result);
    }

    private async Task<object> GetTicket(JsonElement args)
    {
        var id = args.GetProperty("workItemId").GetInt32();
        var item = await azure.GetTicketAsync(id);
        var fields = item.GetProperty("fields");
        var title = fields.TryGetProperty("System.Title", out var t) ? t.GetString() : "";
        var state = fields.TryGetProperty("System.State", out var s) ? s.GetString() : "";
        return new { content = new[] { new { type = "text", text = JsonSerializer.Serialize(new { id, title, state }) } } };
    }

    private static object Tool(string name, string description, object schema) => new { name, description, inputSchema = schema };
}
