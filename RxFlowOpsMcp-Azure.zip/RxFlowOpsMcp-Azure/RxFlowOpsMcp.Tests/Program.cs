using RxFlowOpsMcp;
using Xunit;

namespace RxFlowOpsMcp.Tests;

public sealed class PermissionGateTests
{
    [Fact]
    public void Settings_defaults_are_safe()
    {
        var s = Settings.FromConfiguration(new SettingsOptions("o", "p", "pat", true, null));
        Assert.DoesNotContain("other-project", s.WritableProjects);
    }

    [Fact]
    public void Permission_gate_rejects_another_project()
    {
        var gate = new PermissionGate(new Settings("o", "p", "", true, new() { "p" }));
        Assert.Throws<InvalidOperationException>(() => gate.EnsureWritable("other", "update"));
    }

    [Fact]
    public void Permission_gate_allows_configured_project()
    {
        var gate = new PermissionGate(new Settings("o", "p", "", true, new() { "p" }));
        gate.EnsureWritable("p", "update");
    }

    [Fact]
    public void Mock_catalog_setting_is_represented()
    {
        var s = new Settings("o", "p", "", true, new() { "p" });
        Assert.True(s.OpsCatalogMock);
    }

    [Fact]
    public void Writable_projects_are_case_insensitive()
    {
        var gate = new PermissionGate(new Settings("o", "p", "", true, new() { "RxFlow" }));
        gate.EnsureWritable("rxflow", "update");
    }
}
