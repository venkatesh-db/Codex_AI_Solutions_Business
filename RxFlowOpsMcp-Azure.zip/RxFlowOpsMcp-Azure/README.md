# RxFlowOpsMcp-Azure

Minimal .NET 8 MCP server for Azure DevOps operations over JSON-RPC stdio.

## Run

```sh
export DOTNET_ROOT="$HOME/.dotnet8"
export PATH="$HOME/.dotnet8:$PATH"
export AZDO_ORG=venkateshdb
export AZDO_PROJECT=RxFlow
export AZDO_PAT='<set in your shell; never print or commit it>'
export OPS_CATALOG_MOCK=true
dotnet run --project RxFlowOpsMcp/RxFlowOpsMcp.csproj
```

The server supports `initialize`, `tools/list`, and `tools/call` for `get_ticket`,
`list_valid_states`, and the mock-safe `get_service_owner`. It intentionally
does not execute mutating tools without a future explicit approval flow.

## Test

```sh
dotnet test RxFlowOpsMcp.Tests/RxFlowOpsMcp.Tests.csproj
```

The PAT is read only from `AZDO_PAT`, used in an Authorization header, and is
never logged by the application. In production, inject `AZDO_PAT` from a
managed secret store such as Azure Key Vault; do not put it in source control,
`appsettings.json`, command history, or deployment manifests.

Set `MCP_AUDIT_LOG_PATH` to store JSONL audit records for tool calls. The log
stores the timestamp, tool name, argument count, and argument names—not values.
