import { digest, redact, safeRelative, type Task, type Approval } from './core.js';

type Any = Record<string, unknown>;
const obj = (x: unknown): Any => x && typeof x === 'object' && !Array.isArray(x) ? x as Any : {};
const str = (x: unknown): string => typeof x === 'string' ? x : '';
const arr = (x: unknown): unknown[] => Array.isArray(x) ? x : [];

export function project(task: Task, message: Any): Task {
  const method = str(message.method);
  const params = obj(message.params);
  if (!method || (params.threadId && params.threadId !== task.threadId)) {
    task.diagnostics.push('Malformed or unrelated event ignored'); return task;
  }
  // The protocol has no universal event cursor. Stable lifecycle payloads can be deduplicated;
  // output deltas cannot be safely deduplicated by content and are intentionally not persisted.
  if (!method.endsWith('/delta') && !method.endsWith('/outputDelta')) {
    const key = digest(JSON.stringify({method, params, id:message.id}));
    if (task.seenEvents.includes(key)) return task;
    task.seenEvents.push(key);
    if (task.seenEvents.length > 500) task.seenEvents.shift();
  }
  task.seq++;
  task.updatedAt = new Date().toISOString();
  const item = obj(params.item);
  const itemId = str(item.id);
  switch (method) {
    case 'turn/started':
      task.turnId = str(obj(params.turn).id) || task.turnId;
      task.status = 'active'; break;
    case 'turn/plan/updated':
      task.plan = arr(params.plan).map(x => obj(x)).filter(x => str(x.step)).map(x => ({step:redact(x.step,300),status: x.status === 'completed' ? 'completed' : x.status === 'inProgress' ? 'in_progress' : 'pending'})); break;
    case 'item/agentMessage/delta':
      if (params.delta) task.progress.push(redact(params.delta,300));
      if (task.progress.length > 100) task.progress.shift(); break;
    case 'item/started':
    case 'item/completed': {
      if (item.type === 'agentMessage' && method === 'item/completed') {
        task.finalResponse = redact(item.text,4000);
      }
      if (item.type === 'fileChange') {
        for (const raw of arr(item.changes)) {
          const change = obj(raw);
          const relative = safeRelative(task.repository,str(change.path));
          if (!relative) { task.diagnostics.push('File change outside repository omitted'); continue; }
          const kindType = obj(change.kind).type;
          const kind = kindType === 'add' ? 'added' : kindType === 'delete' ? 'deleted' : kindType === 'update' ? 'modified' : 'unknown';
          const existing = task.changedFiles.find(f => f.path === relative);
          if (existing) { existing.change = kind; existing.evidence = itemId; }
          else task.changedFiles.push({path:relative,change:kind,evidence:itemId});
        }
      }
      if (item.type === 'commandExecution') {
        const command = redact(item.command,500);
        const existing = task.commands.find(c => c.id === itemId);
        const value = {id:itemId,command,exitCode:typeof item.exitCode === 'number' ? item.exitCode : null,status:str(item.status),result:redact(item.aggregatedOutput,1000),evidence:itemId};
        if (existing) Object.assign(existing,value); else task.commands.push(value);
      }
      break;
    }
    case 'turn/completed': {
      const turn = obj(params.turn);
      task.turnId = str(turn.id) || task.turnId;
      task.status = turn.status === 'completed' ? 'completed' : turn.status === 'interrupted' ? 'interrupted' : 'failed';
      if (turn.error) task.error = redact(obj(turn.error).message || turn.error,500);
      break;
    }
    case 'error': task.error = redact(params.message || 'App Server error',500); task.status = 'failed'; break;
    case 'serverRequest/resolved': {
      const a = task.approvals.find(x => x.wireId === params.requestId && x.pending);
      if (a) a.pending = false;
      if (task.status === 'waiting_for_approval') task.status = 'active';
      break;
    }
    case 'item/commandExecution/requestApproval':
    case 'item/fileChange/requestApproval': {
      const wireId = message.id;
      if (typeof wireId !== 'string' && typeof wireId !== 'number') { task.diagnostics.push('Approval without request ID ignored'); break; }
      const type: Approval['type'] = method.includes('commandExecution') ? 'command' : 'file';
      const id = digest(`${task.threadId}:${wireId}:${str(params.approvalId)}`).slice(0,24);
      if (task.approvals.some(a => a.requestId === id)) break;
      task.approvals.push({requestId:id,wireId,type,summary:redact(type === 'command' ? params.command : 'File change request',400),target:redact(type === 'command' ? params.cwd : params.grantRoot,300),reason:redact(params.reason,400),pending:true});
      task.status = 'waiting_for_approval'; break;
    }
    default:
      if (!['item/commandExecution/outputDelta','item/fileChange/outputDelta','item/fileChange/patchUpdated'].includes(method)) task.diagnostics.push(`Unknown event: ${redact(method,80)}`);
  }
  if (task.diagnostics.length > 100) task.diagnostics.shift();
  return task;
}
