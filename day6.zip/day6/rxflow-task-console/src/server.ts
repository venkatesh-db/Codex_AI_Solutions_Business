import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { timingSafeEqual } from 'node:crypto';
import { digest, redact } from './core.js';
import { TaskStore } from './store.js';
import { ThreadService } from './service.js';

type User = {id:string;tokenSha256:string};
const users: User[] = JSON.parse(process.env.CONSOLE_USERS_JSON || '[]') as User[];
const repositories = (process.env.CONSOLE_REPOSITORIES || '').split(':').filter(Boolean);
if (!users.length || !repositories.length) throw new Error('Configure CONSOLE_USERS_JSON and CONSOLE_REPOSITORIES');
const store = new TaskStore(resolve(process.env.CONSOLE_DATA_DIR || './data'));
const service = new ThreadService(store,repositories);
const publicDir = fileURLToPath(new URL('../public/',import.meta.url));
function auth(req: IncomingMessage): string | null {
  const match = /^Bearer (.{16,})$/.exec(req.headers.authorization || '');if(!match) return null;
  const hash = Buffer.from(digest(match[1] || ''),'hex');
  for (const user of users) {const expected=Buffer.from(user.tokenSha256,'hex');if(expected.length===hash.length && timingSafeEqual(hash,expected)) return user.id;}
  return null;
}
function json(res:ServerResponse,status:number,data:unknown) {res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(data));}
async function body(req:IncomingMessage):Promise<Record<string,unknown>> {
  let value='';for await(const chunk of req){value+=String(chunk);if(value.length>16_384) throw new Error('payload too large');}
  const parsed:unknown=JSON.parse(value||'{}');if(!parsed||typeof parsed!=='object'||Array.isArray(parsed)) throw new Error('invalid JSON');return parsed as Record<string,unknown>;
}
const server=createServer(async(req,res)=>{
  res.setHeader('x-content-type-options','nosniff');res.setHeader('referrer-policy','no-referrer');
  res.setHeader('content-security-policy',"default-src 'self'; style-src 'self'; script-src 'self'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'");
  const url=new URL(req.url||'/',`http://${req.headers.host||'localhost'}`);
  if(url.pathname==='/'||url.pathname==='/app.js'||url.pathname==='/style.css') {
    const name=url.pathname==='/'?'index.html':url.pathname.slice(1);
    try {const file=await readFile(resolve(publicDir,name));res.writeHead(200,{'content-type':name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':'text/html','cache-control':'no-store'});res.end(file);}catch{res.writeHead(404);res.end();}return;
  }
  if(url.pathname==='/healthz'){json(res,200,{status:'ok'});return;}
  const owner=auth(req);if(!owner){json(res,401,{error:'unauthorized'});return;}
  try {
    if(url.pathname==='/api/tasks'&&req.method==='GET'){json(res,200,await store.list(owner));return;}
    if(url.pathname==='/api/tasks'&&req.method==='POST') {const input=await body(req);json(res,201,await service.start(owner,String(input.repository||'')));return;}
    const match=/^\/api\/tasks\/([A-Za-z0-9_-]{1,120})(?:\/(resume|turn|cancel|report|events|approvals))?$/.exec(url.pathname);
    if(!match){json(res,404,{error:'not found'});return;}
    const id=match[1]!,action=match[2];
    if(req.method==='GET'&&!action){json(res,200,await service.owned(owner,id));return;}
    if(req.method==='GET'&&action==='report'){json(res,200,await service.evidence(owner,id));return;}
    if(req.method==='GET'&&action==='events'){
      const task=await service.owned(owner,id);
      res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-store','connection':'keep-alive'});
      res.write(`event: snapshot\ndata: ${JSON.stringify(task)}\n\n`);
      const off=service.subscribe(id,x=>{if(!res.writableEnded)res.write(`event: update\ndata: ${JSON.stringify(x)}\n\n`);});
      const ping=setInterval(()=>{if(!res.writableEnded)res.write(': heartbeat\n\n');},15000);
      req.on('close',()=>{clearInterval(ping);off();});return;
    }
    if(req.method==='POST'&&action==='resume'){json(res,200,await service.resume(owner,id));return;}
    if(req.method==='POST'&&action==='turn'){const input=await body(req);json(res,200,await service.continue(owner,id,String(input.prompt||'')));return;}
    if(req.method==='POST'&&action==='cancel'){json(res,200,await service.cancel(owner,id));return;}
    if(req.method==='POST'&&action==='approvals'){const input=await body(req);json(res,200,await service.decide(owner,id,String(input.requestId||''),input.decision as 'approved'|'denied'));return;}
    json(res,405,{error:'method not allowed'});
  }catch(e){const message=redact(e instanceof Error?e.message:e,300);json(res,/not found/.test(message)?404:400,{error:message});}
});
server.listen(Number(process.env.PORT||4177),'127.0.0.1');
server.on('error',error=>{process.stderr.write(`HTTP server unavailable: ${redact(error instanceof Error?error.message:error,160)}\n`);process.exitCode=1;});
process.on('SIGTERM',()=>{service.close();server.close();});
process.on('SIGINT',()=>{service.close();server.close();});
