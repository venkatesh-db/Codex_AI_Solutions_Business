import { mkdir, readFile, readdir, rename, writeFile, chmod } from 'node:fs/promises';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import type { Task } from './core.js';

export class TaskStore {
  constructor(private root: string) {}
  async save(task: Task) {
    await mkdir(this.root,{recursive:true,mode:0o700});
    const file = join(this.root,encodeURIComponent(task.threadId)+'.json');
    const temp = file+'.'+randomUUID()+'.tmp';
    await writeFile(temp,JSON.stringify(task),{mode:0o600});
    await chmod(temp,0o600);
    await rename(temp,file);
  }
  async get(id: string): Promise<Task | null> {
    if (!/^[a-zA-Z0-9_-]{1,120}$/.test(id)) return null;
    try {const text = await readFile(join(this.root,encodeURIComponent(id)+'.json'),'utf8');return JSON.parse(text) as Task;}
    catch {return null;}
  }
  async list(owner: string): Promise<Task[]> {
    let files: string[];
    try {files = await readdir(this.root);} catch {return [];}
    const tasks = await Promise.all(files.filter(x=>x.endsWith('.json')).map(x=>this.get(decodeURIComponent(x.slice(0,-5)))));
    return tasks.filter((x): x is Task => !!x && x.owner === owner);
  }
}
