import { EventEmitter } from 'node:events';
import { allowedRepository, newTask, redact, report, validateReport, type Task } from './core.js';
import { project } from './projector.js';
import { TaskStore } from './store.js';
import { AppServerAdapter, type CodexAdapter } from './transport.js';

const PROMPT = `Investigate the RxFlow defect where a slow client retries POST /orders and a duplicate order may be created. Read repository instructions. Reproduce the defect with a failing regression test when feasible, identify the root cause, and make the smallest compatible idempotency correction. Run focused and required checks. Do not access production or real patient data. Report observed evidence and limitations. Request approval for actions that require it.`;
type Factory = () => CodexAdapter;
export class ThreadService {
  private adapters = new Map<string,CodexAdapter>();
  private events = new EventEmitter();
  private busy = new Set<string>();
  private writes = new Map<string,Promise<void>>();
  private deciding = new Set<string>();
  constructor(readonly store: TaskStore, private repositories: string[], private factory: Factory = () => new AppServerAdapter()) {}
  private enqueue(id:string, work:()=>Promise<void>) {
    const prior=this.writes.get(id)||Promise.resolve();
    const next=prior.catch(()=>{}).then(work);
    this.writes.set(id,next);
    void next.catch(()=>{});
  }
  async idle(id:string) {await this.writes.get(id);}
  private async bind(id: string, adapter: CodexAdapter) {
    this.adapters.set(id,adapter);
    adapter.onEvent(event => this.enqueue(id,async()=>{
      const task = await this.store.get(id); if (!task) return;
      project(task,event);
      await this.store.save(task);
      if (['completed','failed','interrupted','cancelled'].includes(task.status)) this.busy.delete(id);
      this.events.emit(id,task);
    }));
    adapter.onClose(() => this.enqueue(id,async()=>{
      this.adapters.delete(id);this.busy.delete(id);
      const task = await this.store.get(id); if (!task || ['completed','failed','cancelled'].includes(task.status)) return;
      task.status = 'interrupted';task.diagnostics.push('App Server connection closed; resume explicitly');
      for (const approval of task.approvals) approval.pending = false;
      await this.store.save(task);this.events.emit(id,task);
    }));
  }
  async start(owner: string, requestedRepository: string): Promise<Task> {
    const repository = await allowedRepository(requestedRepository,this.repositories);
    const active = (await this.store.list(owner)).filter(t=>['active','waiting_for_approval'].includes(t.status));
    if (active.length >= 2) throw new Error('active task limit reached');
    const adapter = this.factory();
    try {
      const id = await adapter.start(repository);
      const task = newTask(id,repository,owner);
      await this.store.save(task);await this.bind(id,adapter);
      this.busy.add(id);
      try { task.turnId = await adapter.turn(id,PROMPT);await this.store.save(task); }
      catch(e) {task.status='failed';task.error=redact(e,300);await this.store.save(task);this.busy.delete(id);}
      return task;
    } catch(e) {adapter.close();throw e;}
  }
  async resume(owner: string, id: string): Promise<Task> {
    const task = await this.owned(owner,id);
    if (this.adapters.has(id)) return task;
    const repository = await allowedRepository(task.repository,this.repositories);
    const adapter = this.factory();
    try {const state=await adapter.resume(id,repository);await this.bind(id,adapter);task.status=state==='active'?'active':'interrupted';if(state==='active')this.busy.add(id);task.error=null;await this.store.save(task);return task;}
    catch(e) {adapter.close();task.error=`Resume failed: ${redact(e,250)}`;await this.store.save(task);throw new Error(task.error);}
  }
  async continue(owner: string,id: string,prompt: string): Promise<Task> {
    const task = await this.owned(owner,id);
    if (this.busy.has(id) || task.status === 'waiting_for_approval') throw new Error('turn already active');
    if (typeof prompt !== 'string' || !prompt.trim() || prompt.length > 4000) throw new Error('invalid prompt');
    let adapter = this.adapters.get(id);
    if (!adapter) {await this.resume(owner,id);adapter=this.adapters.get(id);}
    if (!adapter) throw new Error('resume unavailable');
    this.busy.add(id);task.status='active';task.error=null;
    try {task.turnId=await adapter.turn(id,prompt);await this.store.save(task);return task;}
    catch(e) {this.busy.delete(id);task.status='failed';task.error=redact(e,300);await this.store.save(task);throw e;}
  }
  async decide(owner: string,id: string,requestId: string,decision: 'approved' | 'denied'): Promise<Task> {
    const key=`${id}:${requestId}`;
    if(this.deciding.has(key)) throw new Error('approval decision in progress');
    this.deciding.add(key);
    try {
      await this.idle(id);
      const task = await this.owned(owner,id);
      const approval = task.approvals.find(a=>a.requestId===requestId);
      if (!approval || !approval.pending || approval.decision) throw new Error('approval no longer pending');
      if (decision !== 'approved' && decision !== 'denied') throw new Error('invalid decision');
      const adapter=this.adapters.get(id);if (!adapter) throw new Error('resume required before deciding');
      approval.pending=false;
      try {await adapter.decide(approval.wireId,decision==='approved'?'accept':'decline');
        approval.decision=decision;approval.actor=owner;approval.decidedAt=new Date().toISOString();
        task.status='active';await this.store.save(task);return task;
      } catch(e) {approval.pending=true;task.error=`Approval delivery failed: ${redact(e,250)}`;await this.store.save(task);throw e;}
    } finally {this.deciding.delete(key);}
  }
  async cancel(owner:string,id:string):Promise<Task> {
    const task=await this.owned(owner,id);const adapter=this.adapters.get(id);
    if (!adapter || !task.turnId) throw new Error('no active turn');
    await adapter.interrupt(id,task.turnId);task.status='cancelled';await this.store.save(task);this.busy.delete(id);return task;
  }
  async owned(owner:string,id:string):Promise<Task> {
    const task=await this.store.get(id);if(!task || task.owner!==owner) throw new Error('task not found');return task;
  }
  async evidence(owner:string,id:string) {const value=report(await this.owned(owner,id));if(!validateReport(value)) throw new Error('report validation failed');return value;}
  subscribe(id:string,listener:(task:Task)=>void) {this.events.on(id,listener);return ()=>this.events.off(id,listener);}
  close() {for (const adapter of this.adapters.values()) adapter.close();}
}
