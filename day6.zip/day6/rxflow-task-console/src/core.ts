import { createHash } from 'node:crypto';
import { realpath } from 'node:fs/promises';
import { relative, isAbsolute, sep } from 'node:path';

export type Status = 'active' | 'waiting_for_approval' | 'completed' | 'failed' | 'interrupted' | 'cancelled';
export type PlanStep = { step: string; status: 'pending' | 'in_progress' | 'completed' };
export type Approval = { requestId: string; wireId: string | number; type: 'command' | 'file'; summary: string; target: string; reason: string; decision?: 'approved' | 'denied'; decidedAt?: string; actor?: string; pending: boolean };
export type Command = { id: string; command: string; exitCode: number | null; status: string; result: string; evidence: string };
export type FileChange = { path: string; change: 'added' | 'modified' | 'deleted' | 'unknown'; evidence: string };
export type Task = { schemaVersion: 1; threadId: string; turnId: string | null; repository: string; owner: string; status: Status; seq: number; seenEvents: string[]; plan: PlanStep[]; progress: string[]; changedFiles: FileChange[]; commands: Command[]; approvals: Approval[]; finalResponse: string; diagnostics: string[]; error: string | null; createdAt: string; updatedAt: string };

const secret = /(bearer\s+\S+|sk-[A-Za-z0-9_-]{8,}|(?:api[_-]?key|authorization|password|token)\s*[:=]\s*\S+)/gi;
export function redact(input: unknown, limit = 1200): string {
  return String(input ?? '').replace(/authorization\s*[:=]\s*bearer\s+[^\s"']+/gi, '[REDACTED]').replace(secret, '[REDACTED]').replace(/\b\d{3}-\d{2}-\d{4}\b/g, '[REDACTED]').slice(0, limit);
}
export function digest(value: string): string { return createHash('sha256').update(value).digest('hex'); }
export async function allowedRepository(requested: string, allowlist: string[]): Promise<string> {
  const resolved = await realpath(requested);
  if (!isAbsolute(resolved)) throw new Error('invalid repository path');
  const roots = await Promise.all(allowlist.map(x => realpath(x)));
  if (!roots.includes(resolved)) throw new Error('repository not allowlisted');
  return resolved;
}
export function safeRelative(base: string, path: string): string | null {
  if (!isAbsolute(path)) return null;
  const rel = relative(base, path);
  return rel && rel !== '..' && !rel.startsWith(`..${sep}`) && !isAbsolute(rel) ? rel : null;
}
export function newTask(threadId: string, repository: string, owner: string): Task {
  const now = new Date().toISOString();
  return { schemaVersion: 1, threadId, turnId: null, repository, owner, status: 'active', seq: 0, seenEvents: [], plan: [], progress: [], changedFiles: [], commands: [], approvals: [], finalResponse: '', diagnostics: [], error: null, createdAt: now, updatedAt: now };
}
export function report(t: Task) {
  const tests = t.commands.filter(c => /(?:pytest|vitest|jest|npm test|node --test)/i.test(c.command));
  return { schemaVersion: 1, threadId: t.threadId, turnId: t.turnId, repository: t.repository, status: t.status, summary: t.finalResponse || 'No final response received', plan: t.plan, changedFiles: t.changedFiles, commands: t.commands, tests: { state: !tests.length ? 'NOT_RUN' : tests.some(x => x.exitCode === null) ? 'UNKNOWN' : tests.some(x => x.exitCode !== 0) ? 'FAILED' : 'PASSED', verified: tests.length > 0 && tests.every(x => x.exitCode !== null), evidence: tests.map(x => x.evidence) }, approvals: t.approvals.filter(a => a.decision).map(a => ({requestId:a.requestId, decision:a.decision, actor:a.actor, decidedAt:a.decidedAt})), limitations: [...t.diagnostics, ...(tests.length ? [] : ['No test execution evidence'])], createdAt: t.createdAt, updatedAt: t.updatedAt };
}
export function validateReport(value: ReturnType<typeof report>): boolean {
  return value.schemaVersion === 1 && typeof value.threadId === 'string' && value.threadId.length > 0
    && typeof value.repository === 'string' && typeof value.summary === 'string'
    && ['active','waiting_for_approval','completed','failed','interrupted','cancelled'].includes(value.status)
    && Array.isArray(value.plan) && value.plan.every(x=>typeof x.step==='string'&&['pending','in_progress','completed'].includes(x.status))
    && Array.isArray(value.changedFiles) && value.changedFiles.every(x=>typeof x.path==='string'&&['added','modified','deleted','unknown'].includes(x.change))
    && Array.isArray(value.commands) && value.commands.every(x=>typeof x.command==='string'&&(x.exitCode===null||typeof x.exitCode==='number'))
    && ['NOT_RUN','UNKNOWN','FAILED','PASSED'].includes(value.tests.state) && typeof value.tests.verified === 'boolean'
    && Array.isArray(value.approvals) && Array.isArray(value.limitations)
    && typeof value.createdAt === 'string' && typeof value.updatedAt === 'string';
}
