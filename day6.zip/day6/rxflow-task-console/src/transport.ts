import { spawn, type ChildProcessWithoutNullStreams } from 'node:child_process';
import { EventEmitter } from 'node:events';
import { redact } from './core.js';

type Pending = { resolve: (x: Record<string, unknown>) => void; reject: (e: Error) => void; timer: NodeJS.Timeout };
export interface CodexAdapter {
  start(cwd: string): Promise<string>;
  resume(threadId: string, cwd: string): Promise<'active' | 'idle'>;
  turn(threadId: string, prompt: string): Promise<string>;
  decide(wireId: string | number, decision: 'accept' | 'decline'): Promise<void>;
  interrupt(threadId: string, turnId: string): Promise<void>;
  onEvent(listener: (event: Record<string, unknown>) => void): void;
  onClose(listener: () => void): void;
  close(): void;
}

export class AppServerAdapter implements CodexAdapter {
  private process: ChildProcessWithoutNullStreams;
  private events = new EventEmitter();
  private pending = new Map<number, Pending>();
  private nextId = 1;
  private ready: Promise<void>;
  private buffer = '';
  constructor(binary = 'codex') {
    this.process = spawn(binary,['app-server','--stdio'],{stdio:['pipe','pipe','pipe'],env:process.env});
    this.process.stdout.setEncoding('utf8');
    this.process.stdout.on('data',(chunk:string) => {
      this.buffer += chunk;
      if(this.buffer.length>512_000){this.buffer='';this.events.emit('event',{method:'error',params:{message:'Oversized App Server frame'}});this.process.kill();return;}
      let index;
      while((index=this.buffer.indexOf('\n'))>=0){const line=this.buffer.slice(0,index);this.buffer=this.buffer.slice(index+1);this.acceptLine(line);}
    });
    this.process.stderr.on('data',() => { /* never forward raw stderr */ });
    this.process.on('error',() => {this.events.emit('event',{method:'error',params:{message:'App Server process could not start'}});});
    this.process.on('close',() => {for (const p of this.pending.values()) {clearTimeout(p.timer);p.reject(new Error('App Server closed'));} this.pending.clear();this.events.emit('close');});
    this.ready = this.requestRaw('initialize',{clientInfo:{name:'rxflow_task_console',title:'RxFlow Task Console',version:'0.1.0'}},10000).then(() => {this.send({method:'initialized',params:{}});});
  }
  private send(value: unknown) { this.process.stdin.write(JSON.stringify(value)+'\n'); }
  private requestRaw(method: string, params: unknown, timeout = 30000): Promise<Record<string, unknown>> {
    const id = this.nextId++;
    return new Promise((resolve,reject) => {
      const timer = setTimeout(() => {this.pending.delete(id);reject(new Error(`${method} timed out`));},timeout);
      this.pending.set(id,{resolve,reject,timer});
      this.send({id,method,params});
    });
  }
  private async request(method: string, params: unknown) {await this.ready;return this.requestRaw(method,params);}
  private acceptLine(line: string) {
    if (line.length > 512_000) {this.events.emit('event',{method:'error',params:{message:'Oversized App Server event'}});return;}
    let msg: Record<string,unknown>;
    try { const parsed: unknown = JSON.parse(line); if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error(); msg = parsed as Record<string,unknown>; }
    catch {this.events.emit('event',{method:'error',params:{message:'Malformed App Server JSONL'}});return;}
    if (typeof msg.id === 'number' && !msg.method) {
      const p = this.pending.get(msg.id); if (!p) return;
      this.pending.delete(msg.id); clearTimeout(p.timer);
      if (msg.error) p.reject(new Error(redact((msg.error as Record<string,unknown>).message,300)));
      else p.resolve((msg.result && typeof msg.result === 'object') ? msg.result as Record<string,unknown> : {});
    } else if (typeof msg.method === 'string') {
      if ((typeof msg.id === 'number' || typeof msg.id === 'string') && !['item/commandExecution/requestApproval','item/fileChange/requestApproval'].includes(msg.method)) {
        this.send({id:msg.id,error:{code:-32601,message:'Request type not supported by console'}});
      }
      this.events.emit('event',msg);
    }
  }
  async start(cwd: string): Promise<string> {
    const result = await this.request('thread/start',{cwd,approvalPolicy:'on-request',approvalsReviewer:'user',sandbox:'workspace-write'});
    const thread = result.thread as Record<string,unknown> | undefined;
    if (typeof thread?.id !== 'string') throw new Error('thread/start lacked thread ID');
    return thread.id;
  }
  async resume(threadId: string, cwd: string): Promise<'active' | 'idle'> {
    const result=await this.request('thread/resume',{threadId,cwd,approvalPolicy:'on-request',approvalsReviewer:'user',sandbox:'workspace-write',excludeTurns:true});
    const thread=result.thread as Record<string,unknown>|undefined;
    if(thread?.id!==threadId) throw new Error('resume returned a different thread');
    const status=(thread.status && typeof thread.status==='object') ? thread.status as Record<string,unknown> : {};
    return status.type==='active'?'active':'idle';
  }
  async turn(threadId: string, prompt: string): Promise<string> {
    const result = await this.request('turn/start',{threadId,input:[{type:'text',text:prompt}]});
    const turn = result.turn as Record<string,unknown> | undefined;
    if (typeof turn?.id !== 'string') throw new Error('turn/start lacked turn ID');
    return turn.id;
  }
  async decide(wireId: string | number, decision: 'accept' | 'decline') {await this.ready;this.send({id:wireId,result:{decision}});}
  async interrupt(threadId: string, turnId: string) {await this.request('turn/interrupt',{threadId,turnId});}
  onEvent(listener: (event: Record<string,unknown>) => void) {this.events.on('event',listener);}
  onClose(listener: () => void) {this.events.on('close',listener);}
  close() {this.process.kill();}
}
