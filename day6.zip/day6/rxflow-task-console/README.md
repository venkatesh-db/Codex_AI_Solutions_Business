# RxFlow engineering task console

A local, server-side TypeScript console for a human-controlled Codex incident task. It keeps the Codex process and credentials on the server, projects streamed events into a task snapshot, requires explicit approval decisions, persists a thread ID for resume, and exports an evidence report. It does **not** fix the RxFlow defect itself, deploy, or merge code.

## Interface decision

This new console uses **Codex App Server over local stdio**. The installed `codex-cli 0.154.0` generated the protocol types in `protocol/`; `thread/start`, `thread/resume`, `turn/start`, `turn/interrupt`, plan and item notifications, and command/file approval requests were inspected from that version. App Server is appropriate because the UI must mediate approval requests and display rich streamed state. The [official App Server documentation](https://learn.chatgpt.com/docs/app-server) describes the JSONL handshake and these concepts. The [Codex SDK](https://learn.chatgpt.com/docs/codex-sdk) is appropriate for simpler application-controlled threads, but its public guide does not establish the approval exchange needed here.

The supplied attachment said to extend a prepared starter, but no TypeScript starter was attached. This project was created beside `day6/rxflow`, which is the available Python RxFlow repository. Existing RxFlow code was not changed.

## Architecture and trust boundaries

```mermaid
flowchart LR
  Browser[Engineer browser] -->|Bearer token| API[Local HTTP API]
  API --> Auth[User authentication and thread ownership]
  Auth --> Service[ThreadService]
  Service --> Policy[Repository allowlist and task limits]
  Service --> Store[(Private task snapshots)]
  Service --> Projector[Event projector and redaction]
  Service --> Approval[Explicit approval decision]
  Service --> Adapter[App Server adapter]
  Adapter -->|JSONL stdio| Codex[Local Codex App Server]
  Codex -->|workspace write sandbox| Repo[Allowlisted RxFlow checkout]
  Codex -->|Notifications and approval requests| Adapter
  Projector --> Store
  Store -->|Snapshot and SSE| Browser
```

The browser never supplies a Codex working directory directly to App Server. The API resolves the requested path with `realpath` and requires an exact allowlist match. It also checks thread ownership on every task endpoint. Approval responses are tied to the server's pending request ID and are never automatic.

## Run locally

Requires Node.js 18.17+ for this npm version, TypeScript, `@types/node`, and a compatible `codex` executable. With package registry access, run `npm install`, `npm run typecheck`, `npm test`, and `npm run build` in this directory. No live Codex credentials are needed for tests.

Create one random access token and store only its SHA-256 digest in `CONSOLE_USERS_JSON`. For example, generate a token and digest using a local secret manager or a short Node script; never commit the token. Set `CONSOLE_REPOSITORIES` to the absolute path of the **checkout the console may edit**, `CONSOLE_DATA_DIR` to a private directory, and run `node dist/server.js`. The server binds only `127.0.0.1:4177` by default. For shared use, place it behind an organization's authenticated TLS proxy and replace this simple token registry with the organization's identity system.

Example configuration shape (placeholders only):

```text
CONSOLE_USERS_JSON=[{"id":"engineer-id","tokenSha256":"64-lowercase-hex-characters"}]
CONSOLE_REPOSITORIES=/absolute/path/to/authorized/rxflow-checkout
CONSOLE_DATA_DIR=/private/path/to/task-state
PORT=4177
```

Open `http://127.0.0.1:4177`, enter the access token and allowlisted repository path, then start the incident task. The server uses a fixed prompt for the duplicate-order scenario. A follow-up turn is available after the active turn completes. An interrupted process can be reconnected by its stored thread ID; a failed resume does not silently create a replacement thread.

## State, evidence, and governance

- `ThreadService` owns start, continue, resume, cancel, task limits, and per-owner access. A thread can contain multiple turns.
- `AppServerAdapter` performs `initialize` before requests and correlates responses by ID. Approval requests remain pending until the engineer chooses approve or deny.
- `projector.ts` maps plan, progress, file changes, commands, terminal status, and approval requests into one snapshot. Repeated lifecycle messages are deduplicated. Unknown methods become diagnostics. Output deltas have no stable protocol-wide cursor, so reconnect uses the latest authoritative local snapshot.
- `TaskStore` writes permission-restricted JSON snapshots with atomic rename. It stores no prompt text. The report's command and test claims refer to observed item IDs; without test events it reports `NOT_RUN`.
- `config/report.schema.json` and `config/internal-event.schema.json` are versioned contracts. The report is assembled from the projection and validated before export.

## Privacy and operational limits

The server truncates event frames, limits request bodies, redacts common credential patterns, avoids logging raw App Server stderr, and keeps token values out of URLs. Rule-based redaction cannot reliably identify every patient identifier or prescription. **Do not run this client against repositories or tasks containing real patient data** until an organization-specific privacy review and stronger content controls are implemented. Task snapshots can include sanitized agent messages, command summaries, and file paths; protect and delete `CONSOLE_DATA_DIR` according to the organization's retention policy.

The local token registry, JSON-file store, in-memory connection map, and best-effort event deduplication are suitable for a controlled pilot, not a multi-instance production deployment. There is no live Codex integration test, encrypted storage, external audit sink, OpenTelemetry exporter, or deployment automation. See [operations.md](docs/operations.md) for rollout and rollback guidance.
