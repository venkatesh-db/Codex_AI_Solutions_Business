from PIL import Image, ImageDraw, ImageFont
from pathlib import Path

OUT = Path(__file__).with_name('human-codex-many-bugs-end-to-end.png')
W, H = 2400, 1840
im = Image.new('RGB', (W, H), '#f4f7fb')
d = ImageDraw.Draw(im)
FONT = '/System/Library/Fonts/Supplemental/Arial.ttf'
BOLD = '/System/Library/Fonts/Supplemental/Arial Bold.ttf'
title = ImageFont.truetype(BOLD, 58)
subtitle = ImageFont.truetype(FONT, 27)
head = ImageFont.truetype(BOLD, 34)
body = ImageFont.truetype(FONT, 26)
small = ImageFont.truetype(FONT, 23)

def text(x, y, s, font=body, fill='#223047'):
    d.text((x, y), s, font=font, fill=fill)

def arrow(points, color='#52647d', width=7):
    d.line(points, fill=color, width=width, joint='curve')
    x1, y1 = points[-2]
    x2, y2 = points[-1]
    if x2 > x1:
        tip = [(x2,y2),(x2-19,y2-13),(x2-19,y2+13)]
    elif x2 < x1:
        tip = [(x2,y2),(x2+19,y2-13),(x2+19,y2+13)]
    elif y2 > y1:
        tip = [(x2,y2),(x2-13,y2-19),(x2+13,y2-19)]
    else:
        tip = [(x2,y2),(x2-13,y2+19),(x2+13,y2+19)]
    d.polygon(tip, fill=color)

def card(x, y, number, name, owner, lines, accent):
    w, h = 700, 575
    d.rounded_rectangle((x+7,y+9,x+w+7,y+h+9), radius=26, fill='#dce4ee')
    d.rounded_rectangle((x,y,x+w,y+h), radius=26, fill='white', outline='#c9d5e3', width=3)
    d.rounded_rectangle((x,y,x+w,y+92), radius=26, fill=accent)
    d.rectangle((x,y+65,x+w,y+92), fill=accent)
    text(x+30,y+20,f'{number}. {name}',head,'white')
    text(x+31,y+113,owner,small,'#52647d')
    sy = y+168
    for i, line in enumerate(lines):
        cy = sy+i*73
        d.rounded_rectangle((x+28,cy,x+w-28,cy+57), radius=12, fill='#f0f4f9')
        d.ellipse((x+43,cy+18,x+63,cy+38), fill=accent)
        text(x+82,cy+12,line,body)

text(82, 45, 'Human + Codex: fixing many bugs over time', title, '#132339')
text(84, 118, 'One controlled loop per bug  |  Shared prioritization, evidence, and learning', subtitle, '#53657d')

card(80,220,'1','Bug portfolio','Owner: human engineering lead',[
    'Collect reports, alerts, support cases, and tests',
    'Deduplicate; link symptoms to one bug record',
    'Prioritize impact, urgency, and dependencies',
    'Choose one bounded bug and success criteria',
    'Assign owner and capture affected revision'], '#3167a2')
card(850,220,'2','Triage and safety','Owner: human + workflow controller',[
    'Confirm reproduction and affected users',
    'Set scope, access, and organization rules',
    'Identify data, security, and compatibility risks',
    'Choose required tests and rollback condition',
    'Route unclear or high-risk work to specialist'], '#7257a6')
card(1620,220,'3','Codex diagnosis','Owner: Codex in isolated checkout',[
    'Read caller, implementation, and tests',
    'Reproduce symptom or gather diagnostic evidence',
    'Trace root cause and impacted behavior',
    'Propose smallest supported correction',
    'Show hypothesis and evidence to human owner'], '#137d89')
card(1620,960,'4','Fix and verify','Codex edits; independent checks provide evidence',[
    'Implement focused code and regression check',
    'Run targeted check, then required suite',
    'Inspect diff for scope and unintended changes',
    'Retry only with concrete failure evidence',
    'Record checked revision, outputs, and gaps'], '#b67120')
card(850,960,'5','Human decision','Owner: maintainer or designated reviewer',[
    'Review root cause, diff, tests, and risks',
    'Challenge missed cases and business behavior',
    'Request revision, reject, or approve',
    'Apply normal merge and release gates',
    'Keep decision and reviewer in bug record'], '#9a4d72')
card(80,960,'6','Release and learn','Owner: existing delivery and operations teams',[
    'Deploy with monitoring and rollback readiness',
    'Confirm symptom resolves in real environment',
    'Watch regressions and customer impact',
    'Update tests, runbook, and recurring patterns',
    'Feed remaining bugs back to portfolio'], '#27734f')

arrow([(780,506),(839,506)])
arrow([(1550,506),(1609,506)])
arrow([(1970,795),(1970,949)])
arrow([(1620,1247),(1561,1247)])
arrow([(850,1247),(791,1247)])
text(1480,844,'Root cause + evidence',small,'#52647d')

# Failure and retry paths are drawn outside the main cards.
arrow([(2322,1220),(2350,1220),(2350,825),(2240,825),(2240,786)],'#b67120',5)
text(2045,828,'Evidence-based retry',small,'#8b5a1f')
arrow([(1200,960),(1200,864),(430,864),(430,807)],'#9a4d72',5)
text(580,826,'Review feedback: new attempt',small,'#8a4568')

d.rounded_rectangle((80,1635,2320,1770),radius=22,fill='#e4ebf4')
text(112,1655,'Stop paths',head,'#1b2d45')
text(112,1707,'Cannot reproduce • Unclear root cause • Failed checks • High-risk change • Rejected review',body,'#34475f')
text(84,1792,'Each bug has its own owner, checked revision, evidence, and decision. Scale by repeating the loop.',small,'#56677e')
im.save(OUT)
print(OUT)
