
Act as a principal software architect and repository-governance engineer. Design, implement, and verify a concise, maintainable `AGENTS.md` hierarchy for the RxFlow monorepo.

The expected conceptual components are:

- `order_api`
- `routing`
- `pricing`
- `workers`
- `analytics`
- `infra`

The repository may contain Java/Spring Boot, .NET/ASP.NET Core, Python, and C/C++ components. Discover the actual structure, languages, build systems, and test frameworks before proposing or writing instructions. Do not invent components, tools, paths, or commands that are not present.

## Objective

Create durable repository guidance that:

- follows Codex closest-file precedence;
- keeps universal rules in the repository-root `AGENTS.md`;
- places component-specific and language-specific guidance at the narrowest reliable scope;
- references detailed engineering standards instead of duplicating them;
- remains within the installed Codex instruction byte limits;
- preserves useful existing guidance and unrelated user work;
- proves, through executable repository tests, that representative directories discover the required instruction chain.

Treat repository instructions as durable guidance, not as a security boundary. An `AGENTS.md` file cannot override system instructions, managed policy, sandbox restrictions, or user authorization.

## Required durable rules

The effective instruction chain must enforce all of the following:

1. Payment-path changes require idempotency analysis and duplicate-submission tests.
2. Database changes require upgrade instructions, rollback or forward-fix instructions, and migration validation.
3. Public API and externally consumed interface changes require compatibility review.
4. New external calls require explicit timeout and retry policies.
5. Sensitive data must never be logged.
6. Infrastructure changes require security validation.
7. Every defect correction requires a regression test that demonstrates the failure before the correction and passes afterward.
8. Final reports must include commands executed, exit codes, and concise results.

These are repository standards, not one-time task instructions. Put each rule in the narrowest common `AGENTS.md` scope that reliably covers every relevant Java, .NET, Python, and C/C++ component.

Do not duplicate a rule across multiple files merely for visibility. Prefer inheritance from the nearest appropriate common ancestor.

## Permission and safety boundary

- Work only inside the current repository.
- Read every existing `AGENTS.md` and `AGENTS.override.md` before editing.
- Inspect the installed Codex version and its local instruction-discovery configuration.
- Determine configured fallback instruction filenames and instruction byte limits from the installed environment.
- Preserve useful existing guidance and unrelated user changes.
- Do not modify application behavior, dependencies, lockfiles, database schemas, generated artifacts, or infrastructure resources.
- Do not create global instructions under the real Codex home directory.
- If global guidance would be educationally useful, provide only a sanitized repository-local example that contains no machine-specific paths.
- Do not deploy, push, merge, access production, or use real patient data.
- Do not place secrets, patient identifiers, prescriptions, credentials, private keys, machine-specific paths, or production endpoints in instructions, tests, or examples.
- Do not use `AGENTS.md` for command enforcement, lifecycle blocking, external-data retrieval, or large reusable workflows when a Rule, Hook, MCP server, or Skill is the appropriate mechanism.
- Do not claim that precedence or discovery works until it has been tested from representative component directories.
- Use additional agents only when explicitly authorized.
- Do not weaken or replace an existing repository standard without identifying the conflict and explaining the migration.
- Do not modify files outside the governance hierarchy, its supporting documentation, and its verification tests unless strictly necessary to verify discovery.

## Phase 1 — Repository intelligence

Before editing:

1. Determine the actual repository root.
2. Inspect repository status and preserve unrelated changes.
3. Map:
   - component directories;
   - language boundaries;
   - build and package boundaries;
   - shared libraries;
   - test projects and fixtures;
   - API definitions;
   - database migration locations;
   - infrastructure code.
4. Locate and read all existing:
   - `AGENTS.md`;
   - `AGENTS.override.md`;
   - configured fallback instruction files;
   - engineering standards referenced by those files.
5. Determine the effective scope of every current instruction file.
6. Identify guidance that is:
   - contradictory;
   - duplicated;
   - stale;
   - vague;
   - non-operational;
   - stored at the wrong scope;
   - too detailed for an `AGENTS.md`;
   - better implemented as a Rule, Hook, MCP integration, or Skill.
7. Inspect the installed Codex instruction-discovery configuration and documentation. Establish:
   - recognized filenames;
   - override behavior;
   - repository-root detection;
   - closest-file precedence;
   - ordering of inherited instructions;
   - fallback filenames;
   - maximum combined instruction bytes;
   - relevant CLI or diagnostic commands available in the installed version.
8. Measure the effective combined instruction size for representative component directories and compare it with the configured limit.
9. Identify detailed standards that should live under `docs/engineering/` and be referenced from `AGENTS.md`.
10. Present an evidence-backed proposal before editing.

Do not pause for routine approval after presenting the proposal unless repository evidence exposes a material ambiguity that would change ownership, precedence, or irreversible scope.

## Required pre-edit proposal

Before modifying files, report:

- the observed repository structure;
- conceptual-to-actual component mappings;
- detected language and build profiles;
- the current instruction hierarchy;
- problems in the current hierarchy;
- the proposed hierarchy;
- ownership of each durable rule;
- representative precedence examples;
- the migration plan;
- planned verification commands;
- material assumptions and unresolved risks.

Include a compact ownership table such as:

| Rule or concern | Owning instruction scope | Supporting document | Representative consumers |
| --- | --- | --- | --- |
| Sensitive-data logging | Repository root | Sensitive-data standard | All components |
| Payment idempotency | Narrowest shared payment scope | Testing standard | Actual payment-path components |
| Infrastructure security | Infrastructure scope | Infrastructure-security standard | Infrastructure code |

Populate the table from repository evidence rather than copying these examples blindly.

## Supported stack profiles

Only add a stack profile when the repository proves that the stack is present. Reference repository-pinned versions, committed wrappers, configuration files, and verified commands.

### Java and Spring Boot

Inspect for:

- Maven or Gradle toolchains;
- committed Maven Wrapper or Gradle Wrapper;
- Java version configuration;
- Spring MVC or WebFlux;
- JPA/Hibernate;
- Flyway or Liquibase;
- JUnit 5 and repository-specific test conventions;
- Spring Kafka;
- Redis/Lettuce;
- Resilience4j;
- configured formatting, static analysis, coverage, security, and dependency checks.

Use only commands that are verified in the repository. Prefer committed wrappers over globally installed tools.

### .NET and ASP.NET Core

Inspect for:

- `global.json`;
- solution and project files;
- central package configuration;
- ASP.NET Core;
- EF Core and migration locations;
- xUnit, NUnit, or MSTest;
- Confluent.Kafka;
- StackExchange.Redis;
- Polly or built-in .NET resilience;
- analyzers, formatting, coverage, security, and dependency checks.

Use only repository-verified `dotnet` commands and applicable solution or project paths.

### Python

Inspect for:

- `pyproject.toml`, `setup.cfg`, `setup.py`, `requirements*.txt`, `Pipfile`, or lockfiles;
- supported Python versions;
- repository-managed virtual-environment or package commands;
- Poetry, uv, PDM, pip-tools, Hatch, Tox, Nox, or other proven tooling;
- Django, Flask, FastAPI, Starlette, SQLAlchemy, Alembic, Celery, or other actual frameworks;
- pytest, unittest, Hypothesis, or repository-specific test conventions;
- Ruff, Black, isort, mypy, Pyright, pylint, Bandit, coverage, or dependency checks when configured;
- synchronous and asynchronous external-call patterns;
- database migration ownership;
- native-extension or FFI boundaries.

Python guidance must:

- use the repository’s pinned interpreter and environment workflow;
- avoid assuming a virtual-environment location;
- preserve async cancellation and timeout behavior where applicable;
- require compatibility review for public modules, HTTP APIs, events, schemas, and command-line interfaces;
- use only commands demonstrated to work in the repository.

Do not introduce a new Python environment manager, formatter, linter, or test framework.

### C and C++

Inspect for:

- CMake, Meson, Bazel, Make, Ninja, Autotools, or other actual build systems;
- compiler and language-standard configuration;
- committed presets, toolchain files, and dependency manifests;
- GoogleTest, Catch2, doctest, CTest, or repository-specific test conventions;
- Clang-Tidy, Clang-Format, include-what-you-use, sanitizers, Valgrind, coverage, fuzzing, or static-analysis configuration;
- ABI boundaries and exported symbols;
- C APIs, shared libraries, native extensions, or foreign-function interfaces;
- ownership, lifetime, threading, exception, and error-code conventions;
- platform-specific code and supported build targets.

C/C++ guidance must require, where relevant:

- public header and ABI compatibility review;
- explicit ownership and lifetime semantics;
- preservation of thread-safety and error-handling contracts;
- bounds-safe handling of buffers and lengths;
- validation of serialization and wire-format compatibility;
- focused sanitizer or static-analysis checks when already supported;
- repository-verified build and test commands.

Do not assume GCC, Clang, MSVC, a package manager, sanitizer support, or a particular build generator unless repository evidence proves it.

## Cross-language contract handling

Determine whether components communicate through:

- HTTP or RPC APIs;
- OpenAPI specifications;
- Protocol Buffers or gRPC;
- events or message brokers;
- shared schemas;
- database tables;
- native FFI;
- shared libraries;
- generated clients;
- files or batch interfaces.

Place compatibility requirements at the narrowest common scope covering every producer and consumer.

A public contract includes more than HTTP endpoints. It may include:

- Java public APIs;
- .NET public assemblies;
- Python importable modules and CLI contracts;
- C public headers;
- C++ exported symbols and ABI;
- database schemas;
- event payloads;
- serialization formats;
- configuration formats.

Do not treat a language-local build success as sufficient proof of cross-component compatibility.

## Required hierarchy

Adapt this structure to actual repository paths:

```text
AGENTS.md
docs/engineering/
  testing-standards.md
  api-compatibility.md
  database-migrations.md
  external-call-resilience.md
  sensitive-data-and-observability.md
  infrastructure-security.md
  final-evidence-reporting.md
  native-code-compatibility.md        # only if C/C++ exists
  python-engineering.md               # only if Python exists and details warrant it
  java-engineering.md                 # only if Java exists and details warrant it
  dotnet-engineering.md               # only if .NET exists and details warrant it
services/
  order_api/AGENTS.md
  routing/AGENTS.md
  pricing/AGENTS.md
  workers/AGENTS.md
  analytics/AGENTS.md
infra/
  AGENTS.md
scripts/
  agents/
    verify-hierarchy.<existing-supported-extension>
tests/
  agents/
    ...

Create this project for Python tech stack
