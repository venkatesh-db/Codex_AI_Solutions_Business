# Infrastructure guidance

Scope: infrastructure definitions and their tests or documentation. Repository-root instructions remain in force.

- Every infrastructure change requires security validation covering least privilege, secret handling, network exposure, encryption, and destructive-change risk as applicable. Follow [infrastructure security](../docs/engineering/infrastructure-security.md).
- Inspect a non-mutating plan or equivalent diff before reporting a change ready for review.
- Document rollback or forward-fix handling for stateful changes.
- Do not deploy, apply, mutate remote state, or access production without explicit authorization.
- Never embed credentials, patient data, machine-specific paths, or production endpoints.

