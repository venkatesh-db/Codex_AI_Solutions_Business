# External-call resilience

Every new network, broker, database, filesystem, process, or service call must define:

- a finite timeout or deadline;
- which failures are retryable;
- retry count, delay, and backoff behavior;
- whether jitter is required;
- cancellation propagation;
- idempotency and duplicate-side-effect risk;
- terminal error behavior and observable, non-sensitive diagnostics.

Retries must be bounded. Do not stack retries across layers without analyzing the combined attempt count and latency. Never retry authentication failures or non-idempotent operations by default.

