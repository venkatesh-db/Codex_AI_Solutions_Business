# Infrastructure security validation

Review infrastructure changes for:

- least-privilege identities and permissions;
- secret storage and accidental disclosure;
- inbound and outbound network exposure;
- encryption in transit and at rest where applicable;
- public accessibility and trust boundaries;
- destructive or state-replacement operations;
- auditability and non-sensitive diagnostics;
- rollback or forward-fix feasibility.

Use only repository-configured, non-mutating validation. A generated plan must be inspected, not merely generated. Deployment and remote-state mutation require separate explicit authorization.

