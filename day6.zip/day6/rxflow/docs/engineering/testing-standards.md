# Testing standards

## Mandatory

- Test externally meaningful behavior and failure handling, not implementation details alone.
- For a defect correction, first demonstrate a focused regression test failing for the reported behavior, then record it passing after the correction. If the original failure cannot be reproduced safely, report that limitation rather than claiming before/after proof.
- Payment-path changes must test duplicate submissions and the declared idempotency outcome. Add concurrent or replay coverage when those paths are possible.
- Use synthetic, non-identifying fixtures. Sensitive or production-derived data is prohibited.

## Evidence

Record the command, exit code, and concise result. Compilation or collection without executing the relevant assertion is not behavioral evidence.

