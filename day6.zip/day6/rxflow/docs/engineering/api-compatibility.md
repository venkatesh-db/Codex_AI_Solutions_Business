# API and contract compatibility

Compatibility review applies to HTTP interfaces, events, schemas, exported files, command-line behavior, and importable public Python modules.

## Mandatory review

1. Identify producers, consumers, and version ownership.
2. Compare request, response, event, error, ordering, and default-value behavior.
3. Prefer additive evolution. Explain removals, renames, type changes, and newly required fields.
4. Validate representative old and new consumers when fixtures or contract tests exist.
5. Document migration and rollback or forward-fix handling for an intentional breaking change.

A local unit-test pass does not by itself establish consumer compatibility.

