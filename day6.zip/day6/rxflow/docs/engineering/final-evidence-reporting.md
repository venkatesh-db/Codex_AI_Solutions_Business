# Final evidence reporting

Final implementation reports must lead with the delivered outcome and include:

| Field | Required content |
| --- | --- |
| Scope | Files or behavior changed and important exclusions |
| Commands | Every validation command actually executed |
| Exit codes | Numeric exit code for each completed command |
| Results | Concise observed output or behavior |
| Coverage | Acceptance criterion supported by each check |
| Limitations | Unverified claims, environmental constraints, or remaining risks |

Do not present planned checks, successful edits, or running processes as evidence. Re-run affected checks after later edits invalidate earlier results.

