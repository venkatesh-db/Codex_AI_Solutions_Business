# Database migration standard

Every database change must include:

- ordered upgrade instructions;
- rollback steps when rollback is safe, otherwise a forward-fix plan;
- validation proving the migration reaches the intended state;
- compatibility analysis for code running before, during, and after rollout;
- an explicit treatment of partial failure, locking, and long-running data changes when relevant.

Use the migration mechanism already owned by the component. Do not invent a tool or run against a remote database. Tests must use synthetic data and exercise both success and relevant failure behavior.

