# Sensitive data and observability

Sensitive data must never be logged. This includes health information, prescriptions, personal identifiers, payment credentials, authentication material, session data, and unredacted request or event bodies that may contain them.

Use approved non-identifying correlation identifiers, bounded metrics, and structured event names. Validate error paths as well as normal paths because exception objects and client-library diagnostics may contain request data. Redaction is a fallback, not permission to collect data unnecessarily.

Examples and fixtures must be synthetic and must not resemble real people or production records.

