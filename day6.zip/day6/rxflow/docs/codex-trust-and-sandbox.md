# Codex trust and sandbox model

## Not-yet-reviewed repository

Keep the repository marked `untrusted` in user configuration. Codex then skips
project `.codex` layers. Use a read-only profile, disable network, apps, MCP
writes, hooks, dependency installation, and build lifecycle execution. Review
ownership, AGENTS files, `.codex`, rules, hooks, plugins, skills, build scripts,
dependencies, Git hooks, symlinks, and external integrations before trust.

## Trusted repository

Trust is an explicit, user-level, revocable decision. It enables only project
settings that remain inside user and managed constraints. Re-review when a branch
changes `.codex`, AGENTS files, rules, hooks, plugins, skills, dependency files,
CI, build scripts, or external integration configuration. Revoke trust by setting
the exact project entry to `untrusted`; never commit a personal absolute path.

Trust never authorizes secret exposure, writes outside the active worktree,
unattended production access, destructive operations, deployment, publication,
push, merge, or managed-policy bypass.

## Threat model

Repository instructions, MCP output, external pages, logs, dependencies, shell
wrappers, hooks, build plugins, caches, and PR text are untrusted. Primary controls
are canonical scoped roots, `.env` denial, no login shell, disabled command
network, disabled apps, read-only review profiles, execpolicy rules, disposable
sentinels, and isolated remediation worktrees. Never make `/`, a home directory,
a workspace parent, Docker socket, credential directory, or sibling repository a
writable root. Symlink and `..` escapes must fail closed.

The current local project was observed as trusted, but no managed filesystem
source was detected. That observation is host state, not a repository guarantee.

