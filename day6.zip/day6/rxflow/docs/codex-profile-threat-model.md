# Codex profile threat model

## Assets and trust boundaries

Protected assets are tracked source, Git metadata, credentials, environment files, adjacent worktrees, the primary worktree during remediation, and external systems. Repository content—including prompts, scripts, hooks, response files, and build metadata—is untrusted input.

The sandbox boundary is primary. Command rules only classify the command tokens Codex presents and cannot constrain arbitrary interpreter behavior. Managed requirements outrank user intent and must not be weakened. Profile templates are reviewed input, not an authorization grant.

## Threats and controls

| Threat | Primary control | Verification |
| --- | --- | --- |
| Read-only profile modifies tracked data | Read-only permission profile | Sentinel write is denied and hash is unchanged |
| Scoped writer escapes approved paths | Workspace root read plus narrow subtree writes | Root, sibling, and symlink writes are denied |
| Repository code reaches the network | Permission-profile network disabled | Local socket attempt is denied |
| CI pauses for approval | `approval_policy = "never"`, timeout | Static contract, bounded runner, deterministic non-zero failure |
| Destructive or deployment command | Forbidden execpolicy prefixes | `codex execpolicy check` |
| Dependency install bypasses review | Prompt rule plus CI `never` | Rule evaluates to `prompt`; CI cannot prompt |
| Remediator touches primary worktree | Detached worktree plus scoped workspace | Disposable lifecycle test and sibling-write denial |
| Cleanup removes an arbitrary directory | Exact marker, base SHA, registered worktree, clean state | Positive lifecycle and negative argument tests |
| Credential disclosure | Minimal runtime/workspace access; `.env` deny; isolated CI credential injection | Static profile validation and synthetic inaccessible sibling |

## Escape-route review

- `..` paths cannot broaden permission-profile workspace roots.
- A symlink inside a writable subtree is tested against an outside destination.
- Login shells are disabled to reduce shell-profile influence.
- Broad interpreter allow rules are intentionally absent.
- Git hooks and build lifecycle scripts are untrusted; read-only profiles consume pre-generated evidence instead of executing write-producing builds.
- Docker sockets and home credential directories are not granted as workspace roots.
- Response files and alternate command flags remain contained by filesystem/network permissions even when no command prefix matches.
- Concurrent remediation jobs require distinct destinations under an operator-approved parent.

## Residual risks

The repository cannot enforce credential issuance, managed policy, runner hardening, or isolation from processes outside the Codex sandbox. A malicious compiler or interpreter reachable through `:minimal` remains a supply-chain concern; use pinned host tooling and ephemeral runners. Profile installation into a real Codex home is an operator action and must be reviewed after Codex upgrades.

