# Codex enterprise governance

The file `examples/codex/managed-requirements.toml` is a reviewable example, not
installed policy. **MANUAL ADMIN ACTION REQUIRED.** Platform Security owns the
managed ceiling; repository owners own project templates; users own personal
defaults; CI owners own runner isolation and short-lived identity.

Administrators must approve models/providers and reasoning ranges, permission
profiles, MCP/plugin/skill/hook allowlists, login methods, identity lifetime,
network destinations, audit redaction and retention, rate/cost/timeout limits,
version rollout, and exception expiry. The example disables browser/computer
use, apps, plugins, remote plugins, login shells, unmanaged hooks, broad
sandboxes, and web search. `models.new_thread` is only a managed default; it is
not a model allowlist, so provider/model enforcement requires an administrator
controlled catalog and workspace controls.

Unattended CI receives no deployment, publication, merge, infrastructure, or
production credential. Repository-controlled builds must run in a separate
process environment from model credentials. Suspected compromise requires trust
revocation, credential invalidation, runner isolation, audit preservation,
configuration review, and re-onboarding. Access and exceptions require periodic
review. Break-glass access must be human-controlled, time-limited, audited, and
outside repository prompts and profiles.

