# Codex configuration rollout and rollback

## Rollout

1. Run static tests and disposable sandbox probes.
2. Review the managed example; an administrator installs an approved equivalent.
3. Copy only reviewed profile files to a dedicated Codex home as
   `<profile>.config.toml`; do not overwrite an existing home.
4. Keep the repository untrusted until its security-relevant files are reviewed.
5. Grant trust in user configuration for the exact canonical worktree path.
6. Pilot read-only profiles, then Python implementation, CI, and isolated
   remediation. Record version, profile, exit code, timeout, and redacted result.
7. Promote only after golden tasks and negative tests pass.

## Rollback

Set the exact project entry to `untrusted`, stop new jobs, remove only the five
installed RxFlow profile files and the RxFlow rule file from the dedicated Codex
home, and preserve all unrelated user and managed settings. Revert repository
templates through an ordinary reviewed change. Do not recursively delete a
Codex home or shared configuration directory.

## Break glass

No repository profile grants full access. Any organizational exception requires
separate human approval, an isolated environment, expiry, audit, and subsequent
revocation. It must never give unattended automation production authority.

