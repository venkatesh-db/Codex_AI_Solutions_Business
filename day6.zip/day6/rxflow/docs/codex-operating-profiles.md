# RxFlow Codex operating profiles

RxFlow defines five versioned profile templates for Codex CLI 0.154.0 or later. They are examples to install into a dedicated Codex home; the repository does not modify user or managed configuration.

| Profile | Filesystem | Approvals | Network | Intended use |
| --- | --- | --- | --- | --- |
| `rx-analyst` | Workspace read-only | Never | Disabled | Architecture and investigation |
| `rx-developer` | Scoped writes | On request | Disabled | Local code and tests |
| `rx-security` | Workspace read-only | Never | Disabled | Adversarial review |
| `rx-ci` | Workspace read-only | Never | Disabled | Non-interactive analysis |
| `rx-remediator` | Scoped writes in isolated worktree | Never | Disabled | Controlled patch production |

Scoped-write profiles can modify only `services/`, `tests/`, `docs/`, and `artifacts/` relative to the active workspace root. The workspace root itself remains read-only. Environment files are denied, applications are disabled, login shells are disabled, and network access is disabled.

## Installation model

Current Codex profile files live beside the base configuration as `$CODEX_HOME/<name>.config.toml` and are selected with `--profile <name>`. Copy templates explicitly into a dedicated user or CI Codex home after review:

```sh
install -m 0600 .codex/profiles/rx-analyst.config.toml "$CODEX_HOME/rx-analyst.config.toml"
install -m 0600 .codex/profiles/rx-developer.config.toml "$CODEX_HOME/rx-developer.config.toml"
install -m 0600 .codex/profiles/rx-security.config.toml "$CODEX_HOME/rx-security.config.toml"
install -m 0600 .codex/profiles/rx-ci.config.toml "$CODEX_HOME/rx-ci.config.toml"
install -m 0600 .codex/profiles/rx-remediator.config.toml "$CODEX_HOME/rx-remediator.config.toml"
install -m 0600 .codex/rules/rxflow-operating-profiles.rules "$CODEX_HOME/rules/rxflow-operating-profiles.rules"
```

Do not copy a whole repository `.codex` directory over an existing Codex home. That could overwrite unrelated profiles, rules, hooks, or MCP configuration.

## Selection

```sh
codex --profile rx-analyst
codex --profile rx-developer
codex --profile rx-security
codex --profile rx-remediator -C /path/to/isolated-worktree
```

The repository verification harness stages the same files into a disposable Codex home:

```sh
python3 scripts/codex-profiles/verify_profiles.py
python3 scripts/codex-profiles/verify_profiles.py --live
```

The first command checks configuration intent. The second also launches disposable commands through `codex sandbox` and must be run on a host that permits nested sandboxing.

## Enforcement layers

- Permission profiles enforce filesystem and command-network access.
- Approval policy determines whether an escalation can pause for input. `rx-ci` uses `never`.
- Execpolicy rules forbid narrow destructive, deployment, infrastructure-mutation, and publication command prefixes. They are defense in depth and cannot replace the sandbox.
- The remediation scripts validate the repository, immutable base, destination, marker, clean state, and registered worktree before lifecycle operations.
- Credential separation, managed requirements, CI runner isolation, and deployment authority remain external controls.

Official contract references: [configuration](https://learn.chatgpt.com/docs/config-file/config-reference), [permissions](https://learn.chatgpt.com/docs/permissions), [rules](https://learn.chatgpt.com/docs/agent-configuration/rules), and [non-interactive mode](https://learn.chatgpt.com/docs/non-interactive-mode).

