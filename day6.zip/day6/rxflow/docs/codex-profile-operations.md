# Codex profile operations

## Validate

```sh
python3 -m unittest discover -s tests -p 'test_*.py' -v
python3 scripts/codex-profiles/verify_profiles.py --live \
  --output artifacts/codex-profiles/verification-results.json
codex execpolicy check --pretty \
  --rules .codex/rules/rxflow-operating-profiles.rules \
  git reset --hard HEAD
```

A denial is successful evidence only when the target is a disposable sentinel and its hash remains unchanged.

## CI analysis

Install `rx-ci.config.toml` into a dedicated runner Codex home, provide a short-lived credential only to the Codex invocation, and run:

```sh
python3 scripts/codex-profiles/run_ci_analysis.py \
  --output-dir artifacts/codex-profiles/runtime/ci \
  --timeout 300
```

The wrapper uses `codex exec`, JSONL, a final-output schema, read-only sandboxing, `approval_policy=never`, ephemeral session state, and a hard timeout. A timeout returns `124`; other CLI/auth/tool failures retain the transcript and return the Codex exit code. Do not expose credentials to repository-controlled build scripts.

## Remediation worktree

Resolve an approved base commit and choose a dedicated parent that contains no user worktrees:

```sh
python3 scripts/codex-profiles/create_remediation_worktree.py \
  --repo . \
  --base BASE_SHA \
  --allowed-parent ../rxflow-remediation-lab \
  --destination ../rxflow-remediation-lab/job-id
```

Run the remediator only with that destination as its workspace. Produce the reviewed patch in its `artifacts/` directory. Cleanup refuses dirty worktrees; hand off or revert the patch explicitly before retrying:

```sh
python3 scripts/codex-profiles/cleanup_remediation_worktree.py \
  --repo . \
  --base-sha BASE_SHA \
  --allowed-parent ../rxflow-remediation-lab \
  --destination ../rxflow-remediation-lab/job-id
```

## Rollback

1. Remove only the five exact installed profile files from the dedicated Codex home.
2. Remove only `rules/rxflow-operating-profiles.rules` from that home.
3. Preserve every unrelated config, profile, rule, hook, plugin, and MCP file.
4. Remove repository templates and scripts through an ordinary reviewed change if they are no longer wanted.

Break-glass access belongs in managed policy and human-controlled operations. Do not implement it in repository prompts or rules.

