# RxFlow Codex configuration baseline

RxFlow uses Codex CLI 0.154.0 syntax and a Python-only profile set. Java and
.NET profiles are intentionally absent because those stacks are not present.

## Precedence

Highest to lowest: CLI overrides; trusted project `.codex/config.toml` layers
(closest first); selected `$CODEX_HOME/<name>.config.toml`; user config;
cloud-managed defaults; system config; built-in defaults. Administrator
`requirements.toml` is an enforcement ceiling rather than a weaker default.
Untrusted projects skip project `.codex` configuration, hooks, and rules.

## Files

- `.codex/config.toml` contains restrictive shared project settings.
- `.codex/profiles/rx-*.config.toml` are installation templates.
- `examples/codex/user-config.toml` is a sanitized personal-default example.
- `examples/codex/managed-requirements.toml` is an administrator-reviewed
  example only; **MANUAL ADMIN ACTION REQUIRED**.
- `config/codex/profile-policy.json` is the expected machine-readable matrix.

## Profiles

| Profile | Access | Approval | Network | Use |
| --- | --- | --- | --- | --- |
| `rx-investigate` | Read-only | Never | Off | Architecture and incident investigation |
| `rx-implement-python` | Scoped write | On request | Off | Python implementation and local validation |
| `rx-review` | Read-only | Never | Off | Correctness, security, compatibility review |
| `rx-ci` | Read-only | Never | Off | Non-interactive assessment |
| `rx-isolated-remediation` | Scoped write | Never | Off | Patch creation in a disposable worktree |

The example model is `gpt-5.6-sol` at `low` effort because that is the observed
local default. It is not asserted to be enterprise-approved. Administrators must
approve the model and run golden-task evaluation before changing it.

Run `python3 scripts/codex-config/verify_config.py` and
`python3 scripts/codex-config/show_effective_config.py`. The latter reads only
repository templates and never credentials.

