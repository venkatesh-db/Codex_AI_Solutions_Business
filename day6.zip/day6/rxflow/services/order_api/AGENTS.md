# Order API guidance

Scope: order intake and the payment submission boundary. Root and service instructions remain in force.

- Payment-path changes require an idempotency analysis and automated duplicate-submission tests, including concurrent or replayed requests where applicable.
- Define who owns each idempotency key, its validity window, persisted outcome, and behavior after partial failure. Never log payment credentials or sensitive order content.
- Treat request/response shapes and emitted order events as public contracts.
- Keep payment-provider calls behind an explicit timeout and retry policy; do not retry an operation unless its idempotency behavior is established.

Detailed test expectations are in [testing standards](../../docs/engineering/testing-standards.md).

