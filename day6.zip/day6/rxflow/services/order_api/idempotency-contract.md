# Order submission idempotency contract

## Scope

This lab contract covers the in-process `OrderService` payment boundary. The
caller supplies a non-blank idempotency key, and the service owns its association
with the completed outcome for the lifetime of that service instance.

## Rules

- The first submission for a key calls the payment provider once and stores the
  successful result.
- Replaying an equivalent request with the same key returns the stored result
  without calling the provider again.
- Reusing the same key with materially different request data raises an
  idempotency conflict without calling the provider or replacing the first result.
- Different keys represent independent submissions.
- A blank key is rejected before the provider is called.
- A provider exception is propagated and does not create a successful stored
  outcome. The service performs no automatic retry.
- Concurrent submissions to the same service instance are serialized so a
  same-key replay cannot execute a second payment call.
- The provider boundary receives an explicit positive timeout.
- Payment credentials, idempotency keys, and complete order content are never
  logged.

## Request equivalence

Equivalence covers order reference, lab reference, amount in minor currency
units, currency, and payment token. The implementation stores only a SHA-256
fingerprint of canonical request data, not the payment token itself in the
idempotency record.

## Limitations

The in-memory outcome store does not survive process restart and is not shared
between service instances. The lab uses one process-wide submission lock, so
different keys are also serialized within a service instance. Distributed
concurrency, expiry, and an ambiguous provider outcome after a timeout require
durable storage and provider-supported idempotency; they are outside this lab's
verified guarantees.
