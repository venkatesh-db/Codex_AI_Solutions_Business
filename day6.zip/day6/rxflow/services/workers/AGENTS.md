# Worker guidance

Scope: asynchronous and scheduled processing. Root and service instructions remain in force.

- Assume messages may be delivered more than once; make side effects idempotent or explicitly deduplicated.
- Define acknowledgement, retry, dead-letter, and poison-message behavior for changes to message processing.
- Preserve cancellation and bounded shutdown; do not abandon partially committed work silently.
- Treat event payloads and queue-facing schemas as public contracts.

