# Laboratory throughput contract

## Scope

This contract governs the dependency-free calculation in `src/rxflow_analytics/throughput.py`. It does not define an HTTP API, persistence model, cache, event consumer, or laboratory operating schedule because none exists in this repository.

## Formula and time rules

- The reporting window is `[report_start, report_end)`: start inclusive and end exclusive.
- Every timestamp must be timezone-aware and is normalized to UTC before comparison.
- Until a scheduled-operating-hours source exists, scheduled duration equals the reporting-window duration.
- Each offline interval is clipped to the reporting window. An interval with no end remains offline through the report end.
- Clipped intervals are sorted and their union is calculated. Overlapping, adjacent, duplicated, and out-of-order intervals are counted once.
- `available minutes = scheduled minutes - merged offline minutes`, clamped to zero.
- A completed job is counted when its completion instant falls inside the reporting window. Completion events are counted even when an availability interval says the lab was offline; availability changes the denominator, not event validity.
- `throughput per operating hour = completed jobs / (available minutes / 60)`.
- When available minutes are zero, throughput is `None` (not applicable).
- A naive timestamp, an empty or reversed report window, or a non-positive offline interval raises `ValueError`.

## Decision table

All examples use a report window of `08:00–16:00 UTC` unless stated otherwise.

| Scenario | Offline input | Available minutes | Completed jobs | Throughput | Basis |
| --- | --- | ---: | ---: | ---: | --- |
| Partial-day outage | `12:00–14:00` | 360 | 12 | 2.0 | Regression contract |
| Offline at report start | `07:00–09:00` | 420 | 0 | 0.0 | Interval clipped at start |
| Still offline at report end | `15:00–open` | 420 | 0 | 0.0 | Open end closes at report end |
| Spans entire report | `07:00–17:00` | 0 | 1 | `None` | No division by zero |
| Overlap and adjacency | `10:00–11:00`, `10:30–12:00`, `12:00–13:00` | 300 | 0 | 0.0 | Union is `10:00–13:00` |
| Duplicate intervals | two copies of `12:00–14:00` | 360 | 0 | 0.0 | Duplicate counted once |
| Outside report | `16:00–17:00` | 480 | 0 | 0.0 | No positive overlap |
| Boundary completions | jobs at `08:00`, `15:59:59`, `16:00` | 480 | 2 | 0.25 | End is exclusive |

## Deterministic verification

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest \
  services.analytics.tests.test_throughput.ThroughputRegressionTests.test_lab_offline_for_part_of_window_excludes_offline_minutes -v

PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s services/analytics/tests -p 'test_*.py' -v
```

Tests use fixed synthetic instants and do not contact databases, caches, brokers, containers, networks, or production systems.

