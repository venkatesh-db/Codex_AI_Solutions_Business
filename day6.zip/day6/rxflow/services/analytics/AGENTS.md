# Analytics guidance

Scope: analytical processing and exported datasets. Root and service instructions remain in force.

- Use de-identified or synthetic fixtures; never copy sensitive production records into tests or examples.
- Treat exported schemas, metric definitions, and scheduled file formats as public contracts.
- Make late, duplicated, and out-of-order input behavior explicit for pipeline changes.
- Validate reconciliation or completeness invariants when transformation logic changes.

