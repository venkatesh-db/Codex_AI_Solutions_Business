# Pricing guidance

Scope: price calculation and pricing contracts. Root and service instructions remain in force.

- Use explicit decimal and rounding rules; do not use binary floating-point for monetary amounts.
- Treat price inputs, outputs, rule identifiers, and emitted pricing events as public contracts.
- Tests must cover boundary values and the applicable rounding behavior.
- Keep price calculations deterministic for the same validated inputs and rule version.

