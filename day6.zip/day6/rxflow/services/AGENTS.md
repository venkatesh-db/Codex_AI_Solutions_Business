# Python service guidance

This file applies to all RxFlow services in this subtree. The repository-root instructions remain in force.

- Database changes require documented upgrade steps, rollback or forward-fix instructions, and migration validation. Follow [database migrations](../docs/engineering/database-migrations.md).
- Changes to HTTP APIs, events, schemas, command-line interfaces, or importable public Python modules require compatibility review. Follow [API compatibility](../docs/engineering/api-compatibility.md).
- Every new external call requires an explicit timeout and a deliberate retry policy. Preserve async cancellation and make non-retryable failures explicit. Follow [external-call resilience](../docs/engineering/external-call-resilience.md).
- Keep transport, validation, domain decisions, and persistence responsibilities separable without adding layers that have no current use.
- Add component-specific commands only after they exist and have been run successfully from the documented directory.

