# Routing guidance

Scope: route selection and routing contracts. Root and service instructions remain in force.

- Keep routing decisions deterministic for the same validated inputs and configuration version.
- Treat route requests, responses, and emitted routing events as public contracts.
- Regression tests for routing defects must capture the failing input without sensitive data.
- Bound external topology or availability lookups with the service resilience rules.

