# RxFlow repository guidance

This file governs the entire RxFlow repository. A closer `AGENTS.md` may add or specialize guidance for its subtree; it does not cancel these repository-wide rules. Instructions are durable guidance, not a security boundary, and never override system policy, sandboxing, or user authorization.

## Repository-wide invariants

- Never log sensitive data. Treat health, prescription, payment, authentication, and personal data as sensitive; use non-identifying correlation data where diagnostics are necessary. Follow [sensitive-data and observability](docs/engineering/sensitive-data-and-observability.md).
- Every defect correction requires a regression test that demonstrates the defect before the correction and passes afterward. Follow [testing standards](docs/engineering/testing-standards.md).
- Preserve public and cross-component contracts unless an approved compatibility plan exists. See [API compatibility](docs/engineering/api-compatibility.md).
- Do not deploy, access production, use real patient data, or introduce secrets or production endpoints without explicit authorization.
- Keep changes focused. Do not add frameworks, services, dependencies, or infrastructure without a demonstrated requirement.

## Python baseline

- Use the repository-supported Python interpreter and standard-library tooling unless the component already establishes another tool.
- Keep package boundaries explicit; avoid import-time side effects and hidden global state.
- Preserve cancellation in asynchronous code, validate data at trust boundaries, and make ownership of state changes clear.
- Run the narrowest relevant tests first, followed by the repository checks affected by the change.

## Evidence

Final implementation reports must list every validation command executed, its exit code, and a concise result. Distinguish verified behavior from assumptions or unverified limitations. Follow [final evidence reporting](docs/engineering/final-evidence-reporting.md).

