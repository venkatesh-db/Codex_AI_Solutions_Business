# Prompt 2 outcome: Secure Codex operating profiles

This diagram explains how developers select an RxFlow Codex profile, which security layers enforce it, and how each profile behaves.

```mermaid
flowchart TB
    DEV[Developer or CI job] --> SELECT{Select operating profile}

    SELECT --> ANALYST[rx-analyst<br/>Architecture and investigation]
    SELECT --> DEVELOPER[rx-developer<br/>Code modification and testing]
    SELECT --> SECURITY[rx-security<br/>Adversarial review]
    SELECT --> CI[rx-ci<br/>Non-interactive PR analysis]
    SELECT --> REMEDIATOR[rx-remediator<br/>Controlled patch creation]

    subgraph CONFIG[Versioned repository configuration]
        PT[.codex/profiles/*.config.toml<br/>Profile templates]
        MATRIX[config/codex-profile-matrix.json<br/>Machine-readable expectations]
        RULES[.codex/rules/*.rules<br/>Command policy]
        SCHEMA[config/ci-result.schema.json<br/>CI result contract]
    end

    PT -. defines .-> ANALYST
    PT -. defines .-> DEVELOPER
    PT -. defines .-> SECURITY
    PT -. defines .-> CI
    PT -. defines .-> REMEDIATOR
    MATRIX -. verifies .-> PT

    subgraph ENFORCEMENT[Enforcement layers]
        MANAGED[Managed and system policy<br/>Highest authority]
        PERMISSIONS[Codex permission profile<br/>Filesystem and network]
        APPROVALS[Approval policy<br/>Interactive or never]
        EXEC[Execpolicy rules<br/>Allow, prompt, forbid]
        ISOLATION[Runner or worktree isolation<br/>Credential and workspace boundary]

        MANAGED --> PERMISSIONS
        PERMISSIONS --> APPROVALS
        APPROVALS --> EXEC
        EXEC --> ISOLATION
    end

    ANALYST --> RO[Workspace read-only<br/>Network disabled<br/>Apps disabled]
    SECURITY --> RO

    DEVELOPER --> SW[Scoped workspace writes<br/>services + tests + docs + artifacts<br/>Network disabled]

    CI --> NCI[Read-only + approval never<br/>JSONL + output schema<br/>Hard timeout + retained transcript]

    REMEDIATOR --> WT[Detached disposable worktree<br/>Bound to immutable base SHA]
    WT --> RW[Scoped writes inside isolated worktree<br/>Patch artifact only]

    RO --> PERMISSIONS
    SW --> PERMISSIONS
    NCI --> PERMISSIONS
    RW --> PERMISSIONS
    RULES --> EXEC

    subgraph COMMANDS[Command outcomes]
        SAFE[Read-only Git and inspection<br/>No escalation rule]
        CONTROLLED[Dependency installation<br/>Prompt]
        BLOCKED[Reset, clean, push, deploy,<br/>publish, apply, destroy<br/>Forbidden]
    end

    EXEC --> SAFE
    EXEC --> CONTROLLED
    EXEC --> BLOCKED

    subgraph REMEDIATION[Remediation lifecycle]
        BASE[Validate immutable base commit]
        CREATE[Create marked detached worktree]
        PATCH[Edit code and tests<br/>Run regression validation]
        HANDOFF[Review diff and produce patch artifact]
        CLEAN{Clean and marker valid?}
        REMOVE[git worktree remove<br/>Only validated target]
        REFUSE[Fail closed<br/>Preserve worktree and user changes]

        BASE --> CREATE --> PATCH --> HANDOFF --> CLEAN
        CLEAN -->|Yes| REMOVE
        CLEAN -->|No| REFUSE
    end

    RW --> PATCH

    subgraph VERIFY[Python verification]
        STATIC[Static TOML and matrix checks]
        LIVE[Disposable Codex sandbox probes]
        NEGATIVE[Negative tests<br/>root + sibling + symlink + network]
        UNIT[Unit tests<br/>rules + CI wrapper + worktree lifecycle]
        RESULT[artifacts/codex-profiles/<br/>verification-results.json]

        STATIC --> LIVE --> NEGATIVE --> UNIT --> RESULT
    end

    CONFIG --> STATIC
    ENFORCEMENT --> LIVE

    RESULT --> EVIDENCE{All expected outcomes observed?}
    EVIDENCE -->|Yes| READY[Profile kit ready for reviewed installation]
    EVIDENCE -->|No| FAIL[Fail with sanitized evidence<br/>Do not broaden permissions]
```

## Developer interpretation

1. **Choose the least-powerful profile that can complete the task.** Investigation and review use read-only profiles; implementation uses `rx-developer`; controlled repair uses `rx-remediator` in an isolated worktree.
2. **Profiles do not override higher policy.** System instructions, managed requirements, sandbox policy, and user authorization remain authoritative.
3. **Filesystem access is explicit.** Read-only profiles cannot modify the workspace. Write profiles keep the workspace root read-only and grant writes only to approved subdirectories.
4. **Network access is disabled for sandboxed commands.** Dependency access or external research requires a separately authorized, controlled workflow.
5. **Rules are defense in depth.** They classify specific commands, but filesystem permissions, network permissions, credential isolation, and worktree isolation are the primary security controls.
6. **CI cannot request approval.** `rx-ci` uses `approval_policy = "never"`, bounded execution, JSONL events, and schema-constrained final output.
7. **Remediation never falls back to the primary worktree.** Invalid base commits, unsafe destinations, dirty worktrees, or missing markers cause a closed failure.

## How Codex uses a profile

```text
Developer or CI selects --profile rx-...
    -> Codex loads the reviewed profile from a dedicated CODEX_HOME
    -> managed policy constrains the profile
    -> permission profile establishes filesystem and network access
    -> approval policy determines whether escalation may pause
    -> command rules classify sensitive commands
    -> Codex performs the task inside the resulting boundary
    -> Python verification records positive and negative evidence
```

## Verified outcomes

```text
Read-only profiles       : workspace reads succeed; sentinel writes fail
rx-developer             : approved subtree write succeeds; root/sibling/symlink writes fail
rx-ci                    : write and controlled-loopback network attempts fail without approval
rx-remediator            : approved isolated write succeeds; primary/sibling access fails
Command policy           : destructive commands forbidden; dependency install prompts
Remediation lifecycle    : disposable worktree creation and validated cleanup succeed
```

