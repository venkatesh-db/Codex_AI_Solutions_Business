# Prompt 1 outcome: RxFlow governance and Codex instruction flow

This diagram shows the delivered Python-only repository-governance hierarchy and how a Codex agent resolves instructions before working in a component.

```mermaid
flowchart TB
    U[Developer request] --> C[Codex starts in a target directory]
    C --> D{Discover instructions<br/>from repository root to working directory}

    subgraph H[Closest-file instruction hierarchy]
        R[AGENTS.md<br/>Repository-wide invariants]
        S[services/AGENTS.md<br/>Shared Python service rules]
        O[services/order_api/AGENTS.md<br/>Payment and order rules]
        RT[services/routing/AGENTS.md<br/>Routing rules]
        P[services/pricing/AGENTS.md<br/>Money and rounding rules]
        W[services/workers/AGENTS.md<br/>Message-processing rules]
        A[services/analytics/AGENTS.md<br/>Analytics and data rules]
        I[infra/AGENTS.md<br/>Infrastructure security rules]

        R --> S
        S --> O
        S --> RT
        S --> P
        S --> W
        S --> A
        R --> I
    end

    D --> R
    D --> X{Current working scope}
    X -->|Order API| O
    X -->|Routing| RT
    X -->|Pricing| P
    X -->|Workers| W
    X -->|Analytics| A
    X -->|Infrastructure| I

    subgraph E[Effective instruction chain examples]
        EO[order_api/src<br/>Root + Services + Order API]
        EA[analytics/src<br/>Root + Services + Analytics]
        EI[infra/modules<br/>Root + Infrastructure]
    end

    O --> EO
    A --> EA
    I --> EI

    EO --> G[Codex plans and implements<br/>within effective rules]
    EA --> G
    EI --> G

    subgraph ST[Referenced engineering standards]
        T[Testing and regression evidence]
        API[API and contract compatibility]
        DB[Database migrations]
        ER[External-call resilience]
        SD[Sensitive data and observability]
        IS[Infrastructure security]
        FR[Final evidence reporting]
    end

    R -. references .-> T
    R -. references .-> API
    R -. references .-> SD
    R -. references .-> FR
    S -. references .-> DB
    S -. references .-> ER
    I -. references .-> IS

    G --> V[Run focused validation]
    V --> VH[scripts/agents/verify_hierarchy.py]
    VH --> Q{Expected chain, links,<br/>ownership, and byte limit valid?}
    Q -->|No| F[Fail with actionable diagnostics]
    Q -->|Yes| REP[Final report:<br/>commands + exit codes + concise results]
```

## What developers should understand

1. **Root rules always apply.** Sensitive-data handling, defect regression tests, compatibility expectations, and evidence reporting start in the repository-root `AGENTS.md`.
2. **Service rules are inherited.** Work below `services/` also receives database-migration, public-contract, and external-call resilience requirements.
3. **The closest component file specializes behavior.** For example, `order_api` adds payment idempotency and duplicate-submission testing without repeating every root rule.
4. **Infrastructure has a separate branch.** It inherits repository rules and adds infrastructure-specific security validation, but it does not inherit service-only rules.
5. **Detailed standards stay in `docs/engineering/`.** `AGENTS.md` files remain short and link to the full procedures.
6. **The hierarchy is executable governance.** The Python verifier checks expected discovery order, unique rule ownership, links, prohibited content, and the configured instruction-byte limit.

## How a Codex agent uses the hierarchy

For work in `services/order_api/src`, Codex receives instructions in this order:

```text
AGENTS.md
  -> services/AGENTS.md
  -> services/order_api/AGENTS.md
```

The later, closer file adds component context while the earlier repository and service rules remain active. A component file must not weaken higher-priority system policy, sandbox restrictions, managed policy, or user authorization.

The verified representative chains are:

```text
services/order_api/src  : root -> services -> order_api
services/routing/src    : root -> services -> routing
services/pricing/src    : root -> services -> pricing
services/workers/src    : root -> services -> workers
services/analytics/src  : root -> services -> analytics
infra/modules           : root -> infra
```

