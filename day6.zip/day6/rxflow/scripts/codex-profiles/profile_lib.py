"""Shared, dependency-free helpers for RxFlow Codex operating profiles."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import tomllib
from pathlib import Path
from typing import Any, Sequence

PROFILE_NAMES = ("rx-analyst", "rx-developer", "rx-security", "rx-ci", "rx-remediator")
WRITE_PROFILES = {"rx-developer", "rx-remediator"}
APPROVED_WRITES = ("services", "tests", "docs", "artifacts")


def repository_root() -> Path:
    return Path(__file__).resolve().parents[2]


def load_matrix(root: Path) -> dict[str, Any]:
    return json.loads((root / "config" / "codex-profile-matrix.json").read_text(encoding="utf-8"))


def profile_template(root: Path, name: str) -> Path:
    if name not in PROFILE_NAMES:
        raise ValueError(f"unknown profile: {name}")
    return root / ".codex" / "profiles" / f"{name}.config.toml"


def load_profile(root: Path, name: str) -> dict[str, Any]:
    with profile_template(root, name).open("rb") as stream:
        return tomllib.load(stream)


def stage_codex_home(root: Path, destination: Path) -> Path:
    """Copy only versioned profile/rule templates into a disposable Codex home."""
    destination.mkdir(parents=True, exist_ok=False)
    for name in PROFILE_NAMES:
        shutil.copyfile(profile_template(root, name), destination / f"{name}.config.toml")
    rules = destination / "rules"
    rules.mkdir()
    shutil.copyfile(
        root / ".codex" / "rules" / "rxflow-operating-profiles.rules",
        rules / "rxflow-operating-profiles.rules",
    )
    return destination


def codex_environment(codex_home: Path) -> dict[str, str]:
    allowed = {"PATH", "LANG", "LC_ALL", "LC_CTYPE", "TERM", "TMPDIR"}
    environment = {key: value for key, value in os.environ.items() if key in allowed}
    environment["CODEX_HOME"] = str(codex_home)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    return environment


def run(
    command: Sequence[str],
    *,
    cwd: Path,
    environment: dict[str, str] | None = None,
    timeout: int = 20,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        list(command),
        cwd=cwd,
        env=environment,
        text=True,
        capture_output=True,
        timeout=timeout,
        check=False,
    )


def validate_static(root: Path) -> list[str]:
    errors: list[str] = []
    matrix = load_matrix(root)["profiles"]
    if tuple(matrix) != PROFILE_NAMES:
        errors.append("profile matrix names or order do not match the required five profiles")
    for name in PROFILE_NAMES:
        data = load_profile(root, name)
        expected = matrix[name]
        if data.get("approval_policy") != expected["approval_policy"]:
            errors.append(f"{name}: approval policy differs from matrix")
        if data.get("allow_login_shell") is not False:
            errors.append(f"{name}: login shells must be disabled")
        if data.get("web_search") != "disabled":
            errors.append(f"{name}: web search must be disabled")
        if data.get("apps", {}).get("_default", {}).get("enabled") is not False:
            errors.append(f"{name}: apps must be disabled by default")
        permission_name = data.get("default_permissions")
        permission = data.get("permissions", {}).get(permission_name, {})
        if permission.get("network", {}).get("enabled") is not False:
            errors.append(f"{name}: command network must be disabled")
        filesystem = permission.get("filesystem", {})
        if filesystem.get(":minimal") != "read":
            errors.append(f"{name}: minimal runtime must be readable")
        workspace = filesystem.get(":workspace_roots", {})
        if workspace.get(".") != "read":
            errors.append(f"{name}: workspace root baseline must be read-only")
        writes = tuple(path for path, access in workspace.items() if access == "write")
        expected_writes = tuple(expected["writable_paths"])
        if writes != expected_writes:
            errors.append(f"{name}: writable paths {writes!r} differ from {expected_writes!r}")
        if name not in WRITE_PROFILES and writes:
            errors.append(f"{name}: read-only profile contains write grants")
        forbidden_text = profile_template(root, name).read_text(encoding="utf-8")
        for unsafe in ("danger-full-access", 'network_access = true', '":root" = "write"'):
            if unsafe in forbidden_text:
                errors.append(f"{name}: unsafe setting present: {unsafe}")
    return errors

