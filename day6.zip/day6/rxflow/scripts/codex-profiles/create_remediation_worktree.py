#!/usr/bin/env python3
"""Create a marked, detached remediation worktree at an immutable commit."""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

MARKER = ".rxflow-remediation.json"


def git(repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(["git", "-C", str(repo), *args], text=True, capture_output=True, check=False)


def contained(path: Path, parent: Path) -> bool:
    return path == parent or parent in path.parents


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--base", required=True, help="immutable commit SHA or ref resolved before creation")
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--allowed-parent", type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    destination = args.destination.resolve()
    allowed_parent = args.allowed_parent.resolve()
    if not contained(destination, allowed_parent) or destination == allowed_parent:
        parser.error("destination must be a child of the explicit allowed parent")
    if contained(destination, repo) or contained(repo, destination):
        parser.error("remediation worktree must be separate from the primary worktree")
    if destination.exists():
        parser.error("destination already exists")
    resolved = git(repo, "rev-parse", "--verify", f"{args.base}^{{commit}}")
    if resolved.returncode:
        parser.error("base does not resolve to an immutable commit")
    base_sha = resolved.stdout.strip()
    created = git(repo, "worktree", "add", "--detach", str(destination), base_sha)
    if created.returncode:
        print(created.stderr.strip())
        return created.returncode
    (destination / "artifacts").mkdir()
    (destination / MARKER).write_text(json.dumps({"schema_version": 1, "base_sha": base_sha}, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"destination": str(destination), "base_sha": base_sha}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

