#!/usr/bin/env python3
"""Run schema-constrained, non-interactive Codex analysis with the rx-ci profile."""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

from profile_lib import repository_root


def command(codex: str, root: Path, prompt: str, output_dir: Path) -> list[str]:
    return [
        codex,
        "--profile", "rx-ci",
        "--ask-for-approval", "never",
        "exec",
        "--strict-config",
        "--ignore-user-config",
        "--ephemeral",
        "--json",
        "--sandbox", "read-only",
        "--cd", str(root),
        "--output-schema", str(root / "config" / "ci-result.schema.json"),
        "--output-last-message", str(output_dir / "result.json"),
        prompt,
    ]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prompt", default="Review the current diff and return only evidence-based findings.")
    parser.add_argument("--output-dir", type=Path, default=Path("artifacts/codex-profiles/runtime/ci"))
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--codex", default=shutil.which("codex") or "codex")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    root = repository_root()
    output_dir = (root / args.output_dir).resolve() if not args.output_dir.is_absolute() else args.output_dir.resolve()
    artifacts = (root / "artifacts").resolve()
    if output_dir != artifacts and artifacts not in output_dir.parents:
        parser.error("output directory must stay under artifacts/")
    invocation = command(args.codex, root, args.prompt, output_dir)
    if args.dry_run:
        print(" ".join(invocation))
        return 0
    output_dir.mkdir(parents=True, exist_ok=True)
    transcript = output_dir / "events.jsonl"
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    try:
        with transcript.open("w", encoding="utf-8") as stream:
            completed = subprocess.run(invocation, cwd=root, env=environment, stdout=stream, stderr=subprocess.PIPE, text=True, timeout=args.timeout, check=False)
    except subprocess.TimeoutExpired:
        print(f"rx-ci timed out after {args.timeout}s; partial transcript retained", file=sys.stderr)
        return 124
    except FileNotFoundError:
        print("rx-ci failed: configured Codex executable was not found", file=sys.stderr)
        return 127
    if completed.returncode:
        print("rx-ci failed; inspect the sanitized transcript and runner diagnostics", file=sys.stderr)
    return completed.returncode


if __name__ == "__main__":
    raise SystemExit(main())
