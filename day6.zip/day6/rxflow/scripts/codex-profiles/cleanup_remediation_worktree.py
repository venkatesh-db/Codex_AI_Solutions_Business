#!/usr/bin/env python3
"""Remove only a clean worktree bearing the expected RxFlow remediation marker."""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

from create_remediation_worktree import MARKER, contained, git


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--allowed-parent", type=Path, required=True)
    parser.add_argument("--base-sha", required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    destination = args.destination.resolve()
    allowed_parent = args.allowed_parent.resolve()
    if not contained(destination, allowed_parent) or destination == allowed_parent:
        parser.error("destination must be a child of the explicit allowed parent")
    marker = destination / MARKER
    if not marker.is_file():
        parser.error("refusing cleanup: remediation marker is absent")
    metadata = json.loads(marker.read_text(encoding="utf-8"))
    if metadata.get("base_sha") != args.base_sha:
        parser.error("refusing cleanup: base SHA does not match marker")
    registered = git(repo, "worktree", "list", "--porcelain")
    if f"worktree {destination}\n" not in registered.stdout:
        parser.error("refusing cleanup: destination is not a registered worktree")
    status = git(destination, "status", "--porcelain")
    allowed_untracked = {f"?? {MARKER}", "?? artifacts/"}
    unexpected = [line for line in status.stdout.splitlines() if line not in allowed_untracked]
    if unexpected:
        parser.error("refusing cleanup: worktree contains changes that require handoff")
    marker.unlink()
    artifacts = destination / "artifacts"
    if artifacts.exists() and not any(artifacts.iterdir()):
        artifacts.rmdir()
    removed = git(repo, "worktree", "remove", str(destination))
    if removed.returncode:
        print(removed.stderr.strip())
        return removed.returncode
    git(repo, "worktree", "prune")
    print(f"removed validated remediation worktree: {destination}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

