#!/usr/bin/env python3
"""Validate profile templates and optionally run disposable Codex sandbox probes."""

from __future__ import annotations

import argparse
import hashlib
import json
import shlex
import shutil
import socket
import sys
import tempfile
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from profile_lib import PROFILE_NAMES, codex_environment, repository_root, run, stage_codex_home, validate_static


@dataclass
class Result:
    profile: str
    test_id: str
    expected: str
    actual: str
    exit_code: int
    passed: bool
    duration_ms: int
    evidence: str
    before_hash: str | None = None
    after_hash: str | None = None


def digest(path: Path) -> str | None:
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None


def execute_probe(
    *,
    codex: str,
    codex_home: Path,
    profile: str,
    workspace: Path,
    shell: str,
    test_id: str,
    code: str,
    expected_success: bool,
    sentinel: Path | None = None,
) -> Result:
    before = digest(sentinel) if sentinel else None
    started = time.monotonic()
    completed = run(
        [codex, "sandbox", "-p", profile, "-P", profile, "-C", str(workspace), shell, "-c", code],
        cwd=workspace,
        environment=codex_environment(codex_home),
    )
    duration = int((time.monotonic() - started) * 1000)
    after = digest(sentinel) if sentinel else None
    succeeded = completed.returncode == 0
    passed = succeeded is expected_success
    actual = "allowed" if succeeded else "denied"
    diagnostic = completed.stderr.strip().splitlines()
    evidence = diagnostic[-1] if diagnostic else f"process exited {completed.returncode}"
    evidence = evidence.replace(str(workspace), "<workspace>").replace(str(workspace.parent), "<lab>")
    return Result(profile, test_id, "allowed" if expected_success else "denied", actual, completed.returncode, passed, duration, evidence, before, after)


def prepare_workspace(path: Path) -> None:
    for relative in ("services", "tests", "docs", "artifacts"):
        (path / relative).mkdir(parents=True)
    (path / "services" / "sample.py").write_text("VALUE = 1\n", encoding="utf-8")
    (path / "sentinel.txt").write_text("unchanged\n", encoding="utf-8")


def run_live(root: Path, codex: str) -> list[Result]:
    results: list[Result] = []
    shell = shutil.which("sh")
    netcat = shutil.which("nc")
    if not shell or not netcat:
        raise RuntimeError("live verification requires sh and nc")
    with tempfile.TemporaryDirectory(prefix="rxflow-profiles-") as temporary:
        lab = Path(temporary)
        codex_home = stage_codex_home(root, lab / "codex-home")
        workspace = lab / "workspace with spaces"
        sibling = lab / "sibling"
        workspace.mkdir()
        sibling.mkdir()
        prepare_workspace(workspace)
        (sibling / "outside.txt").write_text("outside\n", encoding="utf-8")
        sentinel = workspace / "sentinel.txt"

        for profile in PROFILE_NAMES:
            results.append(execute_probe(
                codex=codex, codex_home=codex_home, profile=profile, workspace=workspace,
                shell=shell, test_id=f"{profile}-read", code="test -r services/sample.py",
                expected_success=True,
            ))

        for profile in ("rx-analyst", "rx-security", "rx-ci"):
            results.append(execute_probe(
                codex=codex, codex_home=codex_home, profile=profile, workspace=workspace,
                shell=shell, test_id=f"{profile}-write-denied", code="printf changed > sentinel.txt",
                expected_success=False, sentinel=sentinel,
            ))

        for profile in ("rx-developer", "rx-remediator"):
            writable = workspace / "services" / f"{profile}.txt"
            results.append(execute_probe(
                codex=codex, codex_home=codex_home, profile=profile, workspace=workspace,
                shell=shell, test_id=f"{profile}-approved-write", code=f"printf ok > {shlex.quote(str(writable))}",
                expected_success=True, sentinel=writable,
            ))
            results.append(execute_probe(
                codex=codex, codex_home=codex_home, profile=profile, workspace=workspace,
                shell=shell, test_id=f"{profile}-root-write-denied", code="printf changed > sentinel.txt",
                expected_success=False, sentinel=sentinel,
            ))
            results.append(execute_probe(
                codex=codex, codex_home=codex_home, profile=profile, workspace=workspace,
                shell=shell, test_id=f"{profile}-outside-write-denied", code=f"printf changed > {shlex.quote(str(sibling / 'outside.txt'))}",
                expected_success=False, sentinel=sibling / "outside.txt",
            ))

        link = workspace / "services" / "escape"
        link.symlink_to(sibling, target_is_directory=True)
        results.append(execute_probe(
            codex=codex, codex_home=codex_home, profile="rx-developer", workspace=workspace,
            shell=shell,
            test_id="rx-developer-symlink-escape-denied",
            code="printf changed > services/escape/escaped.txt",
            expected_success=False,
        ))

        listener = socket.socket()
        listener.bind(("127.0.0.1", 0))
        listener.listen(1)
        listener.settimeout(2)
        accepted: list[bool] = []
        def accept_once() -> None:
            try:
                connection, _ = listener.accept()
                connection.close()
                accepted.append(True)
            except TimeoutError:
                accepted.append(False)
        thread = threading.Thread(target=accept_once)
        thread.start()
        port = listener.getsockname()[1]
        network_result = execute_probe(
            codex=codex, codex_home=codex_home, profile="rx-ci", workspace=workspace,
            shell=shell, test_id="rx-ci-network-denied",
            code=f"{shlex.quote(netcat)} -z 127.0.0.1 {port}", expected_success=False,
        )
        thread.join(timeout=3)
        listener.close()
        if accepted and accepted[0]:
            network_result.passed = False
            network_result.evidence = "controlled loopback endpoint accepted a connection"
        results.append(network_result)
    return results


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live", action="store_true", help="run nested Codex sandbox probes")
    parser.add_argument("--codex", default=shutil.which("codex") or "codex")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = repository_root()
    static_errors = validate_static(root)
    results = run_live(root, args.codex) if args.live and not static_errors else []
    payload = {
        "schema_version": 1,
        "static_validation": "passed" if not static_errors else "failed",
        "static_errors": static_errors,
        "live_validation": "passed" if results and all(item.passed for item in results) else ("not-run" if not args.live else "failed"),
        "results": [asdict(item) for item in results],
    }
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0 if not static_errors and (not args.live or all(item.passed for item in results)) else 1


if __name__ == "__main__":
    raise SystemExit(main())
