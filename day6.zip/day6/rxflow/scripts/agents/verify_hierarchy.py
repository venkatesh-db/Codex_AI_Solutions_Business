#!/usr/bin/env python3
"""Verify RxFlow's repository-local Codex instruction hierarchy."""

from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

DEFAULT_MAX_BYTES = 32_768
PRIMARY_FILENAMES = ("AGENTS.override.md", "AGENTS.md")

COMPONENTS = ("order_api", "routing", "pricing", "workers", "analytics")
STANDARD_DOCS = (
    "testing-standards.md",
    "api-compatibility.md",
    "database-migrations.md",
    "external-call-resilience.md",
    "sensitive-data-and-observability.md",
    "infrastructure-security.md",
    "final-evidence-reporting.md",
)

RULE_OWNERS = {
    "Payment-path changes require an idempotency analysis": "services/order_api/AGENTS.md",
    "Database changes require documented upgrade steps": "services/AGENTS.md",
    "require compatibility review": "services/AGENTS.md",
    "Every new external call requires an explicit timeout": "services/AGENTS.md",
    "Never log sensitive data": "AGENTS.md",
    "Every infrastructure change requires security validation": "infra/AGENTS.md",
    "Every defect correction requires a regression test": "AGENTS.md",
    "must list every validation command executed": "AGENTS.md",
}

MARKDOWN_LINK = re.compile(r"(?<!!)\[[^]]+\]\(([^)]+)\)")
PROHIBITED = (
    re.compile(r"/(?:Users|home)/[^/\s]+/"),
    re.compile(r"(?i)\b(?:api[_-]?key|password|secret)\s*[:=]\s*['\"][^'\"]+"),
    re.compile(r"(?i)https?://[^/\s]*(?:prod|production)[^/\s]*"),
)


@dataclass(frozen=True)
class Discovery:
    files: tuple[Path, ...]
    bytes_loaded: int
    truncated: bool


def instruction_name(directory: Path, fallbacks: Sequence[str] = ()) -> str | None:
    """Return the highest-precedence instruction filename in one directory."""
    for name in (*PRIMARY_FILENAMES, *fallbacks):
        if (directory / name).is_file():
            return name
    return None


def discover(
    root: Path,
    cwd: Path,
    *,
    fallbacks: Sequence[str] = (),
    max_bytes: int = DEFAULT_MAX_BYTES,
) -> Discovery:
    """Model Codex project-document discovery from root through cwd."""
    root = root.resolve()
    cwd = cwd.resolve()
    if cwd != root and root not in cwd.parents:
        raise ValueError(f"{cwd} is outside project root {root}")

    relative = cwd.relative_to(root)
    directories = [root]
    current = root
    for part in relative.parts:
        current /= part
        directories.append(current)

    selected: list[Path] = []
    loaded = 0
    truncated = False
    for directory in directories:
        name = instruction_name(directory, fallbacks)
        if name is None:
            continue
        candidate = directory / name
        size = len(candidate.read_bytes())
        remaining = max_bytes - loaded
        if remaining <= 0:
            truncated = True
            break
        selected.append(candidate)
        if size > remaining:
            loaded += remaining
            truncated = True
            break
        loaded += size
    return Discovery(tuple(selected), loaded, truncated)


def governed_files(root: Path) -> list[Path]:
    files = list(root.rglob("AGENTS.md")) + list(root.rglob("AGENTS.override.md"))
    files.extend((root / "docs" / "engineering").glob("*.md"))
    return sorted(set(files))


def check_required_files(root: Path) -> list[str]:
    expected = [root / "AGENTS.md", root / "services" / "AGENTS.md", root / "infra" / "AGENTS.md"]
    expected.extend(root / "services" / name / "AGENTS.md" for name in COMPONENTS)
    expected.extend(root / "docs" / "engineering" / name for name in STANDARD_DOCS)
    return [f"missing required file: {path.relative_to(root)}" for path in expected if not path.is_file()]


def check_rule_ownership(root: Path) -> list[str]:
    errors: list[str] = []
    instruction_files = sorted(root.rglob("AGENTS.md")) + sorted(root.rglob("AGENTS.override.md"))
    for marker, owner in RULE_OWNERS.items():
        matches = [path for path in instruction_files if marker in path.read_text(encoding="utf-8")]
        expected = root / owner
        if matches != [expected]:
            rendered = ", ".join(str(path.relative_to(root)) for path in matches) or "none"
            errors.append(f"rule marker {marker!r} expected only in {owner}; found {rendered}")
    return errors


def check_links(root: Path) -> list[str]:
    errors: list[str] = []
    for path in governed_files(root):
        for target in MARKDOWN_LINK.findall(path.read_text(encoding="utf-8")):
            if "://" in target or target.startswith("#"):
                continue
            destination = (path.parent / target.split("#", 1)[0]).resolve()
            if not destination.exists():
                errors.append(f"broken link in {path.relative_to(root)}: {target}")
    return errors


def check_prohibited_content(root: Path) -> list[str]:
    errors: list[str] = []
    for path in governed_files(root):
        text = path.read_text(encoding="utf-8")
        for pattern in PROHIBITED:
            if pattern.search(text):
                errors.append(f"prohibited content pattern in {path.relative_to(root)}: {pattern.pattern}")
    return errors


def representative_directories(root: Path) -> dict[str, tuple[str, ...]]:
    expected: dict[str, tuple[str, ...]] = {}
    for component in COMPONENTS:
        relative = f"services/{component}/src"
        expected[relative] = ("AGENTS.md", "services/AGENTS.md", f"services/{component}/AGENTS.md")
    expected["infra/modules"] = ("AGENTS.md", "infra/AGENTS.md")
    return expected


def check_discovery(root: Path, max_bytes: int) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    summaries: list[str] = []
    for relative, expected in representative_directories(root).items():
        cwd = root / relative
        if not cwd.is_dir():
            errors.append(f"missing representative directory: {relative}")
            continue
        result = discover(root, cwd, max_bytes=max_bytes)
        actual = tuple(str(path.relative_to(root)) for path in result.files)
        summaries.append(f"{relative}: {' -> '.join(actual)} ({result.bytes_loaded} bytes)")
        if actual != expected:
            errors.append(f"discovery mismatch for {relative}: expected {expected}, found {actual}")
        if result.truncated:
            errors.append(f"instruction chain exceeds {max_bytes} bytes for {relative}")
    return errors, summaries


def verify(root: Path, max_bytes: int) -> tuple[list[str], list[str]]:
    errors = check_required_files(root)
    errors.extend(check_rule_ownership(root))
    errors.extend(check_links(root))
    errors.extend(check_prohibited_content(root))
    discovery_errors, summaries = check_discovery(root, max_bytes)
    errors.extend(discovery_errors)
    return errors, summaries


def parse_args(argv: Sequence[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--max-bytes", type=int, default=DEFAULT_MAX_BYTES)
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(sys.argv[1:] if argv is None else argv)
    errors, summaries = verify(args.root.resolve(), args.max_bytes)
    for summary in summaries:
        print(f"PASS discovery {summary}")
    if errors:
        for error in errors:
            print(f"FAIL {error}", file=sys.stderr)
        return 1
    print(f"PASS hierarchy ({len(summaries)} representative scopes, limit={args.max_bytes} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

