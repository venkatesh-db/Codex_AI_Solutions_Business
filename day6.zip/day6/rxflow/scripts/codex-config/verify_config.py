#!/usr/bin/env python3
"""Validate the versioned RxFlow Codex configuration baseline."""

import json
from config_policy import root, validate

errors = validate(root())
print(json.dumps({"schema_version": 1, "status": "passed" if not errors else "failed", "errors": errors}, indent=2))
raise SystemExit(1 if errors else 0)
