#!/usr/bin/env python3
"""Ask the installed Codex CLI to load each profile in an isolated home."""

import os
import shutil
import subprocess
import tempfile

from config_policy import PROFILE_NAMES, profile_path, root

repo = root()
codex = shutil.which("codex")
if not codex:
    print("BLOCKED: codex executable not found")
    raise SystemExit(2)

failures = 0
with tempfile.TemporaryDirectory(prefix="rxflow-codex-config-") as temporary:
    for name in PROFILE_NAMES:
        shutil.copyfile(profile_path(repo, name), os.path.join(temporary, f"{name}.config.toml"))
    environment = {
        key: value for key, value in os.environ.items()
        if key in {"PATH", "LANG", "LC_ALL", "LC_CTYPE", "TERM", "TMPDIR"}
    }
    environment["CODEX_HOME"] = temporary
    for name in PROFILE_NAMES:
        completed = subprocess.run(
            [
                codex, "sandbox", "-p", name,
                "-P", name, "-C", str(repo), "/usr/bin/true",
            ],
            cwd=repo, env=environment, text=True, capture_output=True,
            timeout=20, check=False,
        )
        status = "PASS" if completed.returncode == 0 else "FAIL"
        print(f"{status} {name}: exit={completed.returncode}")
        if completed.returncode:
            diagnostic = completed.stderr.strip().splitlines()
            print(diagnostic[-1] if diagnostic else "no diagnostic")
        failures += completed.returncode != 0

raise SystemExit(1 if failures else 0)
