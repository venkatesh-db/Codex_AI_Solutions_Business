#!/usr/bin/env python3
"""Print a redacted, repository-owned configuration summary."""

import json
from config_policy import PROFILE_NAMES, load_toml, profile_path, root

repo = root()
profiles = {}
for name in PROFILE_NAMES:
    data = load_toml(profile_path(repo, name))
    permission = data["permissions"][name]
    profiles[name] = {
        "approval_policy": data["approval_policy"],
        "web_search": data["web_search"],
        "network": permission["network"]["enabled"],
        "writable_paths": [k for k, v in permission["filesystem"][":workspace_roots"].items() if v == "write"],
    }
print(json.dumps({"sources": ["managed requirements (external ceiling)", "user config", "selected profile", "trusted project config", "CLI override"], "profiles": profiles, "secrets": "redacted/not-read"}, indent=2))
