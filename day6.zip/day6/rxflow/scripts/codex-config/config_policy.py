"""Dependency-free validation helpers for the RxFlow Codex baseline."""

from __future__ import annotations

import json
import tomllib
from pathlib import Path
from typing import Any

PROFILE_NAMES = (
    "rx-investigate", "rx-implement-python", "rx-review", "rx-ci",
    "rx-isolated-remediation",
)
WRITE_PROFILES = {"rx-implement-python", "rx-isolated-remediation"}
WRITABLE_PATHS = ("services", "tests", "docs", "artifacts")


def root() -> Path:
    return Path(__file__).resolve().parents[2]


def load_toml(path: Path) -> dict[str, Any]:
    with path.open("rb") as stream:
        return tomllib.load(stream)


def profile_path(repo: Path, name: str) -> Path:
    return repo / ".codex" / "profiles" / f"{name}.config.toml"


def validate(repo: Path) -> list[str]:
    errors: list[str] = []
    policy = json.loads((repo / "config/codex/profile-policy.json").read_text())
    if tuple(policy["profiles"]) != PROFILE_NAMES:
        errors.append("profile-policy names or order differ from required Python profiles")
    for relative in (
        ".codex/config.toml", "examples/codex/user-config.toml",
        "examples/codex/managed-requirements.toml",
    ):
        load_toml(repo / relative)
    for name in PROFILE_NAMES:
        data = load_toml(profile_path(repo, name))
        expected = policy["profiles"][name]
        if data.get("approval_policy") != expected["approval_policy"]:
            errors.append(f"{name}: approval policy mismatch")
        if data.get("web_search") != "disabled" or data.get("allow_login_shell") is not False:
            errors.append(f"{name}: network/search or login shell is not restrictive")
        permission = data.get("permissions", {}).get(name, {})
        if permission.get("network", {}).get("enabled") is not False:
            errors.append(f"{name}: command network must be disabled")
        workspace = permission.get("filesystem", {}).get(":workspace_roots", {})
        writes = tuple(k for k, v in workspace.items() if v == "write")
        expected_writes = WRITABLE_PATHS if name in WRITE_PROFILES else ()
        if writes != expected_writes:
            errors.append(f"{name}: writes {writes!r} != {expected_writes!r}")
        text = profile_path(repo, name).read_text()
        if "danger-full-access" in text or 'enabled = true' in text:
            errors.append(f"{name}: unsafe capability found")
    managed = load_toml(repo / "examples/codex/managed-requirements.toml")
    if "danger-full-access" in managed.get("allowed_sandbox_modes", []):
        errors.append("managed example permits danger-full-access")
    if managed.get("allowed_web_search_modes") != []:
        errors.append("managed example must allow only disabled web search")
    return errors
