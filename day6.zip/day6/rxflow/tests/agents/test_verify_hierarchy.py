from __future__ import annotations

import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
MODULE_PATH = ROOT / "scripts" / "agents" / "verify_hierarchy.py"
SPEC = importlib.util.spec_from_file_location("verify_hierarchy", MODULE_PATH)
assert SPEC and SPEC.loader
verify_hierarchy = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = verify_hierarchy
SPEC.loader.exec_module(verify_hierarchy)


class DiscoveryTests(unittest.TestCase):
    def write(self, root: Path, relative: str, content: str = "instruction\n") -> None:
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def test_closest_files_are_applied_root_to_leaf(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.write(root, "AGENTS.md", "root")
            self.write(root, "services/AGENTS.md", "services")
            self.write(root, "services/orders/AGENTS.md", "orders")
            cwd = root / "services" / "orders" / "src"
            cwd.mkdir(parents=True)

            result = verify_hierarchy.discover(root, cwd)

            self.assertEqual(
                [path.relative_to(root.resolve()).as_posix() for path in result.files],
                ["AGENTS.md", "services/AGENTS.md", "services/orders/AGENTS.md"],
            )

    def test_override_wins_within_its_directory(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.write(root, "AGENTS.md", "root")
            self.write(root, "area/AGENTS.md", "ordinary")
            self.write(root, "area/AGENTS.override.md", "override")

            result = verify_hierarchy.discover(root, root / "area")

            self.assertEqual(result.files[-1].name, "AGENTS.override.md")
            self.assertNotIn(root / "area" / "AGENTS.md", result.files)

    def test_configured_fallback_is_used_after_primary_names(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.write(root, "PROJECT.md", "fallback")
            self.write(root, "area/PROJECT.md", "fallback child")
            (root / "area").mkdir(exist_ok=True)

            result = verify_hierarchy.discover(root, root / "area", fallbacks=("PROJECT.md",))

            self.assertEqual([path.name for path in result.files], ["PROJECT.md", "PROJECT.md"])

    def test_primary_name_wins_over_fallback(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.write(root, "AGENTS.md", "primary")
            self.write(root, "PROJECT.md", "fallback")

            result = verify_hierarchy.discover(root, root, fallbacks=("PROJECT.md",))

            self.assertEqual([path.name for path in result.files], ["AGENTS.md"])

    def test_byte_limit_reports_truncation(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.write(root, "AGENTS.md", "12345")
            self.write(root, "area/AGENTS.md", "67890")

            result = verify_hierarchy.discover(root, root / "area", max_bytes=7)

            self.assertEqual(result.bytes_loaded, 7)
            self.assertTrue(result.truncated)
            self.assertEqual(len(result.files), 2)


class RepositoryHierarchyTests(unittest.TestCase):
    def test_repository_hierarchy_is_valid(self) -> None:
        errors, _ = verify_hierarchy.verify(ROOT, verify_hierarchy.DEFAULT_MAX_BYTES)
        self.assertEqual(errors, [])


if __name__ == "__main__":
    unittest.main()
