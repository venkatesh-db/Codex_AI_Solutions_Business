from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts/codex-config"))
import config_policy  # noqa: E402


class ConfigurationBaselineTests(unittest.TestCase):
    def test_policy_is_internally_consistent(self) -> None:
        self.assertEqual([], config_policy.validate(ROOT))

    def test_all_examples_parse(self) -> None:
        for relative in (
            ".codex/config.toml", "examples/codex/user-config.toml",
            "examples/codex/managed-requirements.toml",
        ):
            self.assertIsInstance(config_policy.load_toml(ROOT / relative), dict)

    def test_untrusted_projects_skip_project_layer_by_contract(self) -> None:
        project = config_policy.load_toml(ROOT / ".codex/config.toml")
        user = config_policy.load_toml(ROOT / "examples/codex/user-config.toml")
        effective_untrusted = dict(user)
        self.assertNotIn("project_doc_max_bytes", effective_untrusted)
        effective_trusted = dict(user) | project
        self.assertEqual(32768, effective_trusted["project_doc_max_bytes"])

    def test_managed_ceiling_rejects_broad_sandbox(self) -> None:
        managed = config_policy.load_toml(ROOT / "examples/codex/managed-requirements.toml")
        self.assertNotIn("danger-full-access", managed["allowed_sandbox_modes"])
        self.assertEqual([], managed["allowed_web_search_modes"])

    def test_policy_json_has_no_absent_stack(self) -> None:
        policy = json.loads((ROOT / "config/codex/profile-policy.json").read_text())
        self.assertEqual("python", policy["stack"])
        self.assertNotIn("rx-implement-java", policy["profiles"])
        self.assertNotIn("rx-implement-dotnet", policy["profiles"])


if __name__ == "__main__":
    unittest.main()
