from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
SCRIPT_DIR = ROOT / "scripts" / "codex-profiles"
sys.path.insert(0, str(SCRIPT_DIR))

import profile_lib  # noqa: E402


class ProfileConfigurationTests(unittest.TestCase):
    def test_static_profile_contracts(self) -> None:
        self.assertEqual(profile_lib.validate_static(ROOT), [])

    def test_templates_parse_with_tomllib(self) -> None:
        for name in profile_lib.PROFILE_NAMES:
            data = profile_lib.load_profile(ROOT, name)
            self.assertEqual(data["default_permissions"], name)

    def test_ci_dry_run_is_non_interactive_and_schema_constrained(self) -> None:
        completed = subprocess.run(
            [sys.executable, str(SCRIPT_DIR / "run_ci_analysis.py"), "--dry-run"],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        for token in ("--profile rx-ci", "--ask-for-approval never", "--json", "--output-schema", "--ephemeral"):
            self.assertIn(token, completed.stdout)

    def test_ci_missing_executable_fails_without_input(self) -> None:
        completed = subprocess.run(
            [sys.executable, str(SCRIPT_DIR / "run_ci_analysis.py"), "--codex", "codex-executable-that-does-not-exist", "--output-dir", "artifacts/codex-profiles/runtime/missing-tool"],
            cwd=ROOT,
            text=True,
            capture_output=True,
            timeout=5,
            check=False,
        )
        self.assertEqual(completed.returncode, 127)
        self.assertIn("was not found", completed.stderr)


@unittest.skipUnless(shutil.which("codex"), "Codex CLI is unavailable")
class CommandRuleTests(unittest.TestCase):
    RULES = ROOT / ".codex" / "rules" / "rxflow-operating-profiles.rules"

    def decision(self, *command: str) -> str | None:
        completed = subprocess.run(
            ["codex", "execpolicy", "check", "--rules", str(self.RULES), *command],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        return json.loads(completed.stdout).get("decision")

    def test_destructive_git_is_forbidden(self) -> None:
        self.assertEqual(self.decision("git", "reset", "--hard", "HEAD"), "forbidden")

    def test_dependency_install_prompts(self) -> None:
        self.assertEqual(self.decision("python3", "-m", "pip", "install", "sample-package"), "prompt")

    def test_read_only_git_has_no_escalation_rule(self) -> None:
        self.assertIsNone(self.decision("git", "status", "--short"))


@unittest.skipUnless(shutil.which("git"), "Git is unavailable")
class RemediationWorktreeTests(unittest.TestCase):
    def git(self, repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(["git", "-C", str(repo), *args], text=True, capture_output=True, check=False)

    def test_create_and_cleanup_disposable_worktree(self) -> None:
        with tempfile.TemporaryDirectory(prefix="rxflow-worktree-test-") as temporary:
            lab = Path(temporary)
            repo = lab / "primary"
            allowed = lab / "remediation"
            destination = allowed / "job with spaces"
            repo.mkdir()
            allowed.mkdir()
            self.assertEqual(self.git(repo, "init", "-q").returncode, 0)
            self.assertEqual(self.git(repo, "config", "user.name", "RxFlow Test").returncode, 0)
            self.assertEqual(self.git(repo, "config", "user.email", "rxflow-test@example.invalid").returncode, 0)
            (repo / "README.md").write_text("synthetic fixture\n", encoding="utf-8")
            self.assertEqual(self.git(repo, "add", "README.md").returncode, 0)
            self.assertEqual(self.git(repo, "commit", "-q", "-m", "fixture").returncode, 0)
            base = self.git(repo, "rev-parse", "HEAD").stdout.strip()

            created = subprocess.run(
                [sys.executable, str(SCRIPT_DIR / "create_remediation_worktree.py"), "--repo", str(repo), "--base", base, "--allowed-parent", str(allowed), "--destination", str(destination)],
                text=True, capture_output=True, check=False,
            )
            self.assertEqual(created.returncode, 0, created.stderr + created.stdout)
            self.assertTrue((destination / ".rxflow-remediation.json").is_file())
            self.assertTrue((repo / "README.md").is_file())

            cleaned = subprocess.run(
                [sys.executable, str(SCRIPT_DIR / "cleanup_remediation_worktree.py"), "--repo", str(repo), "--base-sha", base, "--allowed-parent", str(allowed), "--destination", str(destination)],
                text=True, capture_output=True, check=False,
            )
            self.assertEqual(cleaned.returncode, 0, cleaned.stderr + cleaned.stdout)
            self.assertFalse(destination.exists())
            self.assertTrue((repo / "README.md").is_file())


if __name__ == "__main__":
    unittest.main()
