from PIL import Image, ImageDraw, ImageFont
from pathlib import Path

OUT = Path(__file__).with_name('codex-sdk-automation-end-to-end.png')
W, H = 2400, 1840
im = Image.new('RGB', (W, H), '#f4f7fb')
d = ImageDraw.Draw(im)
FONT = '/System/Library/Fonts/Supplemental/Arial.ttf'
BOLD = '/System/Library/Fonts/Supplemental/Arial Bold.ttf'
title = ImageFont.truetype(BOLD, 58)
subtitle = ImageFont.truetype(FONT, 27)
head = ImageFont.truetype(BOLD, 34)
body = ImageFont.truetype(FONT, 26)
small = ImageFont.truetype(FONT, 23)

def text(x, y, s, font=body, fill='#223047'):
    d.text((x, y), s, font=font, fill=fill)

def arrow(points, color='#52647d', width=7):
    d.line(points, fill=color, width=width, joint='curve')
    x1, y1 = points[-2]
    x2, y2 = points[-1]
    if x2 > x1:
        tip = [(x2,y2),(x2-19,y2-13),(x2-19,y2+13)]
    elif x2 < x1:
        tip = [(x2,y2),(x2+19,y2-13),(x2+19,y2+13)]
    elif y2 > y1:
        tip = [(x2,y2),(x2-13,y2-19),(x2+13,y2-19)]
    else:
        tip = [(x2,y2),(x2-13,y2+19),(x2+13,y2+19)]
    d.polygon(tip, fill=color)

def card(x, y, number, name, owner, lines, accent):
    w, h = 700, 575
    d.rounded_rectangle((x+7,y+9,x+w+7,y+h+9), radius=26, fill='#dce4ee')
    d.rounded_rectangle((x,y,x+w,y+h), radius=26, fill='white', outline='#c9d5e3', width=3)
    d.rounded_rectangle((x,y,x+w,y+92), radius=26, fill=accent)
    d.rectangle((x,y+65,x+w,y+92), fill=accent)
    text(x+30,y+20,f'{number}. {name}',head,'white')
    text(x+31,y+113,owner,small,'#52647d')
    sy = y+168
    for i, line in enumerate(lines):
        cy = sy+i*73
        d.rounded_rectangle((x+28,cy,x+w-28,cy+57), radius=12, fill='#f0f4f9')
        d.ellipse((x+43,cy+18,x+63,cy+38), fill=accent)
        text(x+82,cy+12,line,body)

text(82, 45, 'Codex SDK: organization-specific automation', title, '#132339')
text(84, 118, 'End-to-end control flow  |  Example: recurring dependency update', subtitle, '#53657d')

card(80,220,'1','Intake','Boundary: external request is untrusted',[
    'Ticket, CI event, or engineer request',
    'Normalize task and capture source revision',
    'Assign repository + ticket + revision + attempt',
    'Return prior result for a duplicate run',
    'Record requester and trigger provenance'], '#3167a2')
card(850,220,'2','Policy and scope','Owner: organization controller',[
    'Load approved AGENTS.md and runbook version',
    'Check repository, task, identity, and allowlist',
    'Set write paths, network, time, and cost limits',
    'Define exact acceptance checks',
    'Deny or escalate unclear authorization'], '#7257a6')
card(1620,220,'3','Codex execution','Boundary: isolated checkout and sandbox',[
    'Create clean checkout at captured revision',
    'Provide least-privilege runtime credentials',
    'Start or resume a Codex SDK thread',
    'Inspect code; make bounded code/test edits',
    'Return thread ID, response, and changed files'], '#137d89')
card(1620,960,'4','Independent validation','Owner: organization controller and CI',[
    'Reject edits outside allowed paths or scope',
    'Run required build, tests, scans, policy checks',
    'Capture exit codes, logs, and checked revision',
    'Retry recoverable failure within budget',
    'Stop and retain diagnostics on failed checks'], '#b67120')
card(850,960,'5','Human review','Owner: maintainer or designated reviewer',[
    'Assemble diff, logs, policy version, summary',
    'Open a review-ready proposal',
    'Review business behavior and evidence',
    'Reject, request a new attempt, or approve',
    'Retain decision and reviewer identity'], '#9a4d72')
card(80,960,'6','Delivery and learning','Owner: existing delivery system',[
    'Apply existing merge and release gates',
    'Deploy through approved pipeline',
    'Monitor result and handle rollback if needed',
    'Measure lead time, effort, quality, safety',
    'Archive run record and audit trail'], '#27734f')

arrow([(780,506),(839,506)])
arrow([(1550,506),(1609,506)])
arrow([(1970,795),(1970,949)])
arrow([(1620,1247),(1561,1247)])
arrow([(850,1247),(791,1247)])
text(1510,844,'Diff + checks',small,'#52647d')

# Failure and retry paths are drawn outside the main cards.
arrow([(2322,1220),(2350,1220),(2350,825),(2240,825),(2240,786)],'#b67120',5)
text(2050,828,'Bounded retry to SDK',small,'#8b5a1f')
arrow([(1200,960),(1200,864),(430,864),(430,807)],'#9a4d72',5)
text(595,826,'Changes requested: new attempt',small,'#8a4568')

d.rounded_rectangle((80,1635,2320,1770),radius=22,fill='#e4ebf4')
text(112,1655,'Stop paths',head,'#1b2d45')
text(112,1707,'Denied scope • Out-of-scope edits • Exhausted retries • Incomplete checks • Rejected review',body,'#34475f')
text(84,1792,'Proposed design. No organization-specific policy, deployment, or measured result is assumed.',small,'#56677e')
im.save(OUT)
print(OUT)
