# Day 6: Codex SDK for organization-specific engineering automation

## Intended achievement

Turn a repeatable engineering request into a **reviewable change with evidence**: the automation reads the organization's approved instructions, works in an isolated checkout, runs required checks, and returns a diff plus a concise result for a human owner. This is a proposed outcome, not a claim that an organization has deployed or measured it.

The [Codex SDK](https://learn.chatgpt.com/docs/codex-sdk) supports programmatic local Codex threads for internal workflows and CI jobs. The organization supplies the policies, repository context, access controls, and acceptance checks; the SDK does not define those business rules.

## End-to-end architecture and control flow

```mermaid
flowchart TB
    subgraph Intake[1. Request intake - untrusted boundary]
        A[Ticket, CI event, or engineer request] --> B[Normalize task and capture source revision]
        B --> C[Assign run ID: repository + ticket + revision + attempt]
        C --> D{Already processed?}
        D -->|Yes| E[Return existing run and evidence]
    end

    subgraph Control[2. Organization-owned controller]
        D -->|No| F[Load approved policy version and task template]
        P[AGENTS.md, runbooks, allowlists, required checks] --> F
        F --> G{Repository, task, identity, and permissions allowed?}
        G -->|No or unclear| X[Stop and route to human owner]
        G -->|Yes| H[Set time, cost, network, and write limits]
    end

    subgraph Workspace[3. Isolated execution boundary]
        H --> I[Create clean checkout at captured revision]
        I --> J[Provide least-privilege credentials and sandbox]
        J --> K[Build task prompt with scope and acceptance criteria]
        K --> L[Start Codex SDK thread]
        L --> M[Inspect code, edit files, and add relevant tests]
        M --> N[Return thread ID, final response, and changed files]
    end

    subgraph Validation[4. Controller-owned validation]
        N --> O{Changes within allowed paths and scope?}
        O -->|No| Y[Quarantine diff and escalate]
        O -->|Yes| Q[Run required build, tests, scans, and policy checks]
        Q --> R{All required checks completed and passed?}
        R -->|No| S{Retry budget and recoverable failure?}
        S -->|Yes| T[Resume thread with exact failure evidence]
        T --> M
        S -->|No| U[Record failed run and diagnostics]
        R -->|Yes| V[Assemble diff, logs, policy version, and check results]
    end

    subgraph Handoff[5. Human and existing delivery process]
        V --> W[Create review-ready proposal]
        W --> Z{Maintainer review}
        Z -->|Changes requested| AA[Return feedback for a new bounded run]
        AA --> B
        Z -->|Rejected| AB[Close with reason and retained evidence]
        Z -->|Approved| AC[Existing merge and release gates]
        AC --> AD[Deploy through existing process]
        AD --> AE[Monitor outcome and record metrics]
    end

    X --> AF[Run record and audit trail]
    Y --> AF
    U --> AF
    E --> AF
    AB --> AF
    AE --> AF
    V --> AF
```

**Ownership boundary:** the organization-owned controller chooses the task, checkout, permissions, retry budget, and independent checks. Codex performs bounded engineering work in the isolated checkout. The maintainer owns approval; existing systems own merge, release, and deployment. A passing agent response alone is not acceptance evidence.

**Failure behavior:** denied scope, out-of-scope edits, exhausted retries, or incomplete checks stop the run and retain diagnostics. A retry resumes only with the specific failure evidence and a bounded budget. Review feedback increments the attempt and starts a new run against a captured revision so its evidence stays tied to the code actually checked.

## Concrete example: recurring dependency update

1. A scheduled job identifies a dependency update ticket and creates an isolated checkout.
2. The controller loads the repository's approved `AGENTS.md`, dependency policy, and required commands. It rejects tasks outside the allowlisted repository or package scope.
3. A Codex SDK thread updates the dependency and any necessary code or tests. The task prompt includes the exact acceptance criteria and asks for a concise change summary.
4. The controller runs the prescribed build, tests, and security checks independently of the agent's written conclusion.
5. It records the commit or diff, check results, failures, and thread identifier. A maintainer reviews the change before merge.

## Organization-specific inputs to define

| Input | Decision the organization owns |
| --- | --- |
| Repository and task scope | Which projects and change types may be automated |
| Instructions | Versioned `AGENTS.md`, coding standards, runbooks, and acceptance criteria |
| Identity and permissions | Service identity, writable paths, network access, secret access, and approval rules |
| Validation | Required commands, test environment, failure thresholds, and evidence retention |
| Human handoff | Reviewer, escalation path, merge authority, and release process |

Keep secrets outside prompts and repository files. Treat ticket text, dependency metadata, and external documents as untrusted input. Use the narrowest practical sandbox and credentials. Fail closed when required checks cannot run, and make reruns idempotent by associating each run with a unique ticket and revision.

## Measuring the achievement

Establish a baseline before rollout, then measure the same task class over a defined period:

| Measure | Evidence |
| --- | --- |
| Lead time | Ticket creation to review-ready diff |
| Acceptance rate | Reviewed changes accepted without substantial rework |
| Reliability | Runs with all required checks completed and passed |
| Human effort | Minutes spent preparing, reviewing, and correcting each task |
| Safety | Escaped defects, unauthorized changes, and failed policy checks |

Start with one low-risk, frequent task class. Expand scope only after its results are reviewed. The first milestone is a working pilot that produces a reviewable diff and independently recorded validation, not an unverified productivity percentage.

## SDK starting point

The [official TypeScript example](https://learn.chatgpt.com/docs/codex-sdk) uses `@openai/codex-sdk` to start and run a thread. The SDK is intended for server-side use and requires Node.js 18 or later. The same documentation describes a Python SDK and sandbox presets. A production controller still needs to implement the organization gates and evidence capture shown above.

## Sources

- [Codex SDK documentation](https://learn.chatgpt.com/docs/codex-sdk)
- [Codex as a platform](https://developers.openai.com/blog/codex-as-a-platform)
