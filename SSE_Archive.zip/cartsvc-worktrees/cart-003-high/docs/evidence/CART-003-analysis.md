# CART-003 — Operation One Shot

**Classification:** HIGH PRIORITY · **Profile:** `seniorsoftwaredev` · **Status:** Analysis complete; no fix implemented

## Mission outcome

A coupon with `usage_limit = 1` can be accepted by multiple concurrent checkouts. The code-level failure mechanism is confirmed; runtime reproduction remains pending because this host has .NET 6 while CartSvc targets .NET 8.

## Defect record

| Field | Evidence-backed conclusion |
| --- | --- |
| Expected behavior | At most one checkout redeems a single-use coupon |
| Actual behavior | Multiple checkouts can validate the same available use and increment `uses` independently |
| Trigger | Concurrent checkouts using the same coupon before any request redeems it |
| Failure mechanism | `Validate` reads `uses` and `usage_limit`; `Redeem` later performs an unconditional increment on another connection |
| Root cause | Validation and redemption are neither atomic nor protected by a transaction, lock, or conditional update |
| Business impact | Promotion limits can be exceeded, reducing revenue and making campaign accounting incorrect |
| Violated invariant | `coupons.uses <= coupons.usage_limit` must always hold |
| Priority rationale | Direct financial/data-integrity impact, a deterministic concurrency window, and no enforcing database constraint |
| Confidence | High for the mechanism; runtime manifestation is unverified in this environment |

## Evidence

- `src/CartSvc/CouponService.cs:5-15`: availability is read and returned without locking or reservation.
- `src/CartSvc/CouponService.cs:18-25`: redemption is a later unconditional `uses = uses + 1` update.
- `src/CartSvc/CartService.cs:44-57`: other checkout work occurs between validation and redemption.
- `fixtures/ConcurrentCheckoutFixture/Program.cs:19-50`: five requests share a one-use coupon; the fixture fails when uses exceed one.
- `src/CartSvc/Db.cs:32`: the table has no check constraint enforcing `uses <= usage_limit`.
- `tests/CartSvc.Tests/ServiceTests.cs:66-68`: tests cover available/exhausted coupons only in single-threaded calls.

## Comparison with verified fixed defect

| Dimension | Previous SQL-injection fix | CART-003 |
| --- | --- | --- |
| Boundary | Untrusted search text crossing into SQL syntax | Concurrent requests crossing a shared coupon-state boundary |
| Root cause | String interpolation in command text | Split check-and-update with no atomic guard |
| Effective control | Parameterized SQL plus focused regression | Proposed conditional atomic redemption/transaction plus concurrent regression |
| Shared lesson | Encode the boundary in the database operation and prove it with a behavior-level test |
| Important difference | SQL injection was reproduced, fixed, and passed 20/20 tests; CART-003 is analyzed only |

Historical source: `/Users/venkatesh/Documents/ChatGPT/codex_Internal_automotion/bugswillsmile/README.md`.

## Proposed acceptance evidence

Under .NET 8 and an isolated PostgreSQL schema, run five overlapping checkouts against a coupon with limit one. Require no more than one successful redemption and persisted `uses <= 1`. Add a focused concurrency regression, then run the full suite and standalone coupon fixture. No implementation is authorized by this dossier.

## One-day checkpoint

Analysis and remediation design fit the one-day investigation timebox. Implementation confidence is medium until the transaction design is reconciled with CART-004 and runtime prerequisites are available.
