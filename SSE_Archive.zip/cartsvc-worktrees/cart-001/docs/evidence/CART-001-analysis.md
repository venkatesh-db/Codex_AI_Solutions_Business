# CART-001 defect analysis

## Analysis context

| Field | Value |
| --- | --- |
| Profile | `rxanalyst` (read-only defect analysis) |
| Repository | `cartsvc-dotnet` |
| Branch | `ticket/cart-001` |
| Baseline | `3ea5ffd507c16f866ab94326bd9161b085a4a57f` |
| Analysis date | 2026-09-10 |
| Implementation status | Not started |

## Finding

**Confirmed defect:** coupon checkout calculates GST from the pre-discount subtotal, causing the customer to be overcharged.

| Field | Evidence-backed conclusion |
| --- | --- |
| Affected users | Customers checking out with a non-zero percentage coupon |
| Expected behavior | Apply the coupon discount to the subtotal, then calculate GST from the discounted taxable amount |
| Actual behavior | Calculate GST from the full subtotal, then subtract the discount |
| Trigger | Any non-zero `couponPercent` passed to `PricingService.Totals` |
| Failure mechanism | `Totals` passes `subtotal` directly to `TaxOn`; the separately calculated discount never reduces the taxable amount |
| Root cause | Incorrect operation ordering and taxable-base selection in `PricingService.Totals` |
| Violated invariant | GST for a discounted order must be calculated from the post-discount taxable amount |
| Business impact | The persisted order total and amount evaluated by risk screening are greater than the correct payable amount |
| Confidence | High: the implementation path and repository fixture encode conflicting actual and expected calculations |

## Traceable evidence

1. `src/CartSvc/PricingService.cs:10-15` calculates `tax = TaxOn(subtotal)` before calculating `discount`, then combines both values into the total.
2. `src/CartSvc/CartService.cs:44-46` passes the coupon percentage into `Totals` and uses the returned excessive total for risk assessment.
3. `src/CartSvc/CartService.cs:62-68` persists that returned total in the order record.
4. `fixtures/ConcurrentCheckoutFixture/Program.cs:3-14` defines expected GST as `TaxOn(totals.Subtotal - totals.Discount)` and reports the excess GST and total.
5. `tests/CartSvc.Tests/ServiceTests.cs:34-38` tests tax, discount, and zero-coupon totals independently but has no non-zero-coupon `Totals` assertion.

## Deterministic reproduction

Input:

- Subtotal: INR 1,000.00
- Coupon: 20%
- GST: 18%

| Result | Current implementation | Expected |
| --- | ---: | ---: |
| Discount | INR 200.00 | INR 200.00 |
| Taxable amount | INR 1,000.00 | INR 800.00 |
| GST | INR 180.00 | INR 144.00 |
| Total | INR 980.00 | INR 944.00 |
| Excess charged | INR 36.00 | INR 0.00 |

Calculation:

```text
current = 1000 - (1000 * 20%) + (1000 * 18%) = 980
expected = 1000 - (1000 * 20%) + ((1000 - 200) * 18%) = 944
overcharge = 980 - 944 = 36
```

## Validation status

| Expected evidence | Check | Observed result | Status |
| --- | --- | --- | --- |
| Code uses the wrong taxable base | Inspect `PricingService.Totals` | `TaxOn(subtotal)` is used while a discount is applied | Confirmed |
| Defect reaches checkout behavior | Trace `CartService.Checkout` | Returned total is risk-checked and persisted | Confirmed |
| Numeric impact is reproducible | Independent arithmetic for INR 1,000, 20% coupon, 18% GST | Actual INR 980; expected INR 944; difference INR 36 | Confirmed |
| Existing automated test detects defect | Inspect xUnit tests | No discounted-total assertion exists | Gap confirmed |
| Repository fixture executes | `dotnet run --project fixtures/ConcurrentCheckoutFixture -- --pricing` | Environment has .NET 6.0.400; project targets .NET 8 | Unverified due to environment |

## Proposed regression protection

Before changing production code, add a focused test requiring `PricingService.Totals` for INR 1,000 with a 20% coupon to return:

- subtotal `1000m`;
- discount `200m`;
- tax `144m`;
- total `944m`.

After a correction, run that test, the full `dotnet test` suite, and the standalone `--pricing` fixture under .NET 8. This proposal is not implemented.

## Scope boundary

This analysis does not modify application code, tests, database state, or ticket CART-002. It does not claim runtime reproduction in the current environment.
