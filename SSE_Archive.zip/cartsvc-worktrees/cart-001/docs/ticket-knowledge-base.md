# CartSvc ticket knowledge base

## Scope

- Repository: `cartsvc-dotnet`
- Inspection date: 2026-09-10
- Mode: read-only defect analysis; this document is the only change
- Sources: service implementation, xUnit tests, standalone fixture, and project instructions
- Ticket count: 2 open defect tickets
- Runtime limitation: the available .NET SDK is 6.0.400, while the repository targets .NET 8. The documented fixture scenarios could not be executed in this environment.

## Ticket index

| Ticket | Summary | Priority | Evidence | Status |
| --- | --- | --- | --- | --- |
| CART-001 | Coupon checkout calculates GST before discount | High | Confirmed by implementation and deterministic example | Analysis complete; implementation not authorized |
| CART-002 | Concurrent checkout can oversell stock | Critical | Confirmed mechanism; runtime reproduction pending .NET 8 | Awaiting confirmation |

## CART-001 — Coupon checkout calculates GST before discount

| Field | Detail |
| --- | --- |
| Status | Open; analysis complete; implementation not authorized |
| Evidence level | Confirmed by implementation and deterministic calculation; fixture execution unavailable |
| Affected component | `PricingService.Totals` and every checkout using a coupon |
| User/business impact | Customers using a coupon are charged excess GST and an excessive order total |
| Expected behavior | Calculate GST from the subtotal after the coupon discount |
| Actual behavior | GST is calculated from the original subtotal, then the discount is subtracted |
| Trigger | Checkout with a non-zero coupon percentage |
| Failure mechanism | `Totals` calls `TaxOn(subtotal)` before applying the calculated discount |
| Root cause | The taxable amount passed to `TaxOn` excludes the discount adjustment |
| Violated invariant | A discounted checkout's tax must be based on the discounted taxable amount |
| Detection | The standalone pricing fixture compares actual GST and total with post-discount values |
| Resolution | Not implemented |
| Regression protection | Gap: unit tests cover tax, discount, and zero-coupon totals separately but do not assert discounted totals |

### Evidence

- `src/CartSvc/PricingService.cs:10-15`: `Totals` calculates `tax = TaxOn(subtotal)` and only then calculates the discount.
- `fixtures/ConcurrentCheckoutFixture/Program.cs:3-14`: the fixture defines expected GST as `TaxOn(subtotal - discount)` and reports excess GST.
- `tests/CartSvc.Tests/ServiceTests.cs:34-38`: existing tests do not exercise `Totals` with a non-zero coupon percentage.
- Deterministic example: for INR 1,000 with a 20% discount, the implementation produces INR 180 GST and INR 980 total. Post-discount GST is INR 144 and the expected total is INR 944, so the customer is overcharged INR 36.

### Proposed acceptance check

Add a regression test for `Totals([INR 1,000], 20%)` requiring discount `200`, tax `144`, and total `944`. Run the fixture with `--pricing` under .NET 8 and require zero excess GST.

Detailed analysis: `docs/evidence/CART-001-analysis.md`.

## CART-002 — Concurrent checkout can oversell stock

| Field | Detail |
| --- | --- |
| Status | Open; awaiting user confirmation |
| Evidence level | Failure mechanism confirmed by code; runtime manifestation not executed in the current SDK environment |
| Affected component | `CartService.Checkout` stock validation and decrement boundary |
| User/business impact | More orders can be accepted than available inventory, leaving negative stock and creating fulfillment failures |
| Expected behavior | Stock validation and decrement must be atomic; successful orders must never exceed available stock |
| Actual behavior | Each checkout reads stock independently and later performs an unconditional decrement using separate database connections |
| Trigger | Two or more checkouts for the same product overlap after reading sufficient stock |
| Failure mechanism | A time-of-check/time-of-use race allows all requests to pass validation before any request decrements stock |
| Root cause | No transaction, row lock, or conditional atomic update joins stock validation to stock consumption |
| Contributing conditions | The checkout performs its operations across multiple connections and the schema has no non-negative-stock constraint |
| Violated invariant | Successful order quantity must not exceed inventory, and persisted stock must never be negative |
| Detection | The standalone fixture coordinates five checkouts against three units and checks both order count and remaining stock |
| Resolution | Not implemented |
| Regression protection | Gap: xUnit coverage verifies only a single checkout and a pre-existing zero-stock rejection; the concurrency fixture is outside test discovery |

### Evidence

- `src/CartSvc/CartService.cs:34-42`: availability is checked with a standalone `SELECT stock` on a separate connection.
- `src/CartSvc/CartService.cs:48-56`: stock is later decremented unconditionally with `UPDATE products SET stock = stock - @qty`.
- `src/CartSvc/CartService.cs:59-69`: order persistence occurs through another connection, so stock decrement and order creation are not one transaction.
- `fixtures/ConcurrentCheckoutFixture/Program.cs:19-50`: the fixture deliberately overlaps five checkouts with only three units and treats negative stock or more than three orders as failure.
- `tests/CartSvc.Tests/ServiceTests.cs:50-64`: existing tests cover zero stock and one successful checkout but not overlapping checkout requests.

### Proposed acceptance check

Under .NET 8 with the configured isolated PostgreSQL test database, run the stock fixture. With three units and five simultaneous carts, require exactly three successful orders, zero remaining stock, and no negative inventory. Add a repeatable integration regression test before implementing a correction.

## Relationship and sequencing

The tickets are independent: CART-001 changes pricing calculations, while CART-002 changes the checkout/database concurrency boundary. After confirmation, each should use its own branch and isolated worktree. Analyze and validate CART-001 first, then CART-002, as requested.

## Change history

- 2026-09-10: Created CART-001 and CART-002 from repository evidence. No application code changed.
- 2026-09-10: Completed CART-001 analysis in isolated branch `ticket/cart-001`; implementation remains unstarted.
