# CART-004 — Operation Broken Chain

**Classification:** MEDIUM PRIORITY · **Profile:** `bugfixs` · **Status:** Analysis complete; no fix implemented

## Mission outcome

Checkout does not form one atomic state transition. A failure after stock decrement or coupon redemption can leave committed side effects without an order. The transaction-boundary defect is confirmed by source; individual failure manifestations require injected runtime failures.

## Defect record

| Field | Evidence-backed conclusion |
| --- | --- |
| Expected behavior | Stock, coupon usage, order creation, and cart clearing commit or roll back together |
| Actual behavior | Each stage executes and commits independently through separate database connections |
| Trigger | A database, process, or command failure after an earlier checkout mutation succeeds |
| Failure mechanism | Earlier operations auto-commit before later operations begin; no rollback or compensation exists |
| Root cause | `Checkout` has no encompassing connection and database transaction |
| Business impact | Stock or coupon capacity can be consumed without an order, and a retry can duplicate side effects |
| Violated invariant | Failed checkout must leave inventory, coupon usage, cart, and order state mutually consistent |
| Priority rationale | Data corruption is material but requires a downstream failure window; observed production frequency is unknown |
| Confidence | High for lack of atomicity; medium for specific manifestations until failure injection is executed |

## Failure sequence evidence

1. `src/CartSvc/CartService.cs:48-56` opens a connection and commits stock decrements.
2. `src/CartSvc/CartService.cs:57` calls coupon redemption, which opens and commits on its own connection (`CouponService.cs:18-25`).
3. `src/CartSvc/CartService.cs:59-69` opens another connection to insert the order and clear the cart.
4. If step 2 or 3 fails, no code reverses the already committed mutations.
5. `tests/CartSvc.Tests/ServiceTests.cs:56-65` proves only the all-success path and has no failure injection or rollback assertion.

## Comparison with verified fixed defect

| Dimension | Previous SQL-injection fix | CART-004 |
| --- | --- | --- |
| Boundary | Input data versus SQL syntax | Multi-step state mutation versus transaction commit |
| Root cause | Unsafe query construction | Missing unit-of-work transaction |
| Effective control | Parameterized command | Proposed single transaction with rollback semantics and injected-failure regression |
| Shared lesson | Correctness must be enforced at the external database boundary, not assumed by method ordering |
| Important difference | SQL injection had before/after execution evidence; CART-004 currently has source and path evidence only |

Historical source: `/Users/venkatesh/Documents/ChatGPT/codex_Internal_automotion/bugswillsmile/07-report/delivery-handoff.md`.

## Proposed acceptance evidence

Inject a deterministic failure immediately before order insertion. Require zero new orders, unchanged stock, unchanged coupon uses, and an intact cart. Repeat for a failure during coupon redemption. After a correction, run focused integration checks, the full suite, and the concurrency fixture because CART-003 shares the same transaction boundary.

## One-day checkpoint

The analysis is complete within the timebox. A correct implementation should be planned jointly with CART-003; treating them as independent fixes risks nested connections or inconsistent transaction ownership.
