namespace Banking.Interest;

/// <summary>
/// Computes daily interest accrual per account for the nightly batch.
/// </summary>
public sealed class AccrualService
{
    private const int DaysInYear = 365;

    /// <summary>
    /// Computes the interest accrued for a single account for one day.
    /// </summary>
    /// <remarks>
    /// Formula: principal * (annualRate / daysInYear).
    /// Result is rounded to 2 decimal places (paise) before being
    /// returned, matching the ledger's minor-unit precision.
    /// </remarks>
    public decimal ComputeDailyAccrual(Account account)
    {
        if (account is null)
        {
            throw new ArgumentNullException(nameof(account));
        }

        if (account.PrincipalBalance < 0)
        {
            throw new ArgumentOutOfRangeException(
                nameof(account),
                "Principal balance cannot be negative.");
        }

        if (account.AnnualInterestRate < 0)
        {
            throw new ArgumentOutOfRangeException(
                nameof(account),
                "Annual interest rate cannot be negative.");
        }

        decimal dailyRate = account.AnnualInterestRate / DaysInYear;
        decimal dailyInterest = account.PrincipalBalance * dailyRate;

        // Single rounding point for the account: 2 decimal places
        // (paise), MidpointRounding.AwayFromZero. All math above is
        // decimal-only — no double/float in the money path.
        return Math.Round(dailyInterest, 2, MidpointRounding.AwayFromZero);
    }
}
