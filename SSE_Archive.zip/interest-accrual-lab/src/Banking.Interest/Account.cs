namespace Banking.Interest;

public sealed class Account
{
    public string AccountId { get; init; } = string.Empty;

    public decimal PrincipalBalance { get; init; }

    public decimal AnnualInterestRate { get; init; }
}
