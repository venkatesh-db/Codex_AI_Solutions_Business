namespace Banking.Reconciliation;

/// <summary>
/// The acceptable gap between a batch's ledger total and the sum of its
/// posted entries. This figure is a compliance-owned constant, not an
/// engineering default — the value assigned here (0m) is a placeholder
/// only, and must not be treated as production-ready until compliance
/// sign-off lands on what tolerance is actually acceptable for a
/// regulated posting figure. Callers must supply an explicit tolerance
/// to <see cref="ReconciliationService.CheckBatch"/> rather than relying
/// on any default wired into this type.
/// </summary>
public sealed class ReconciliationTolerance
{
    public decimal Value { get; init; } = 0m;
}
