namespace Banking.Reconciliation;

/// <summary>
/// The outcome of comparing a batch's <see cref="Gap"/> against a
/// <see cref="Tolerance"/>.
/// </summary>
/// <remarks>
/// <see cref="Passed"/> is a computed property derived from
/// <see cref="Gap"/> and <see cref="Tolerance"/> (mirroring
/// <c>BatchPostingResult.ReconciliationGap</c>'s computed-property
/// convention), rather than an independently stored value a caller
/// could set inconsistently with the other two fields. Whether the
/// comparison should be computed this way at all — and whether a gap
/// exactly equal to tolerance should pass (<c>&lt;=</c>) or fail
/// (<c>&lt;</c>) — is flagged as a policy decision in
/// <see cref="ReconciliationService"/>'s remarks; this type only
/// reflects whatever <see cref="ReconciliationService"/> decides.
/// </remarks>
public sealed class ReconciliationReport
{
    public decimal Gap { get; init; }

    public decimal Tolerance { get; init; }

    public bool Passed => Math.Abs(Gap) <= Tolerance;
}
