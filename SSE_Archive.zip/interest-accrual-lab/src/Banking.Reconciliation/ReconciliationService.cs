using Banking.Ledger;

namespace Banking.Reconciliation;

/// <summary>
/// Checks a posted batch's reconciliation gap against a caller-supplied
/// tolerance.
/// </summary>
/// <remarks>
/// The tolerance is taken as an explicit parameter and is never
/// hardcoded inside this method. What that tolerance value should
/// actually be (0? 0.01? something scaled to batch size or entry
/// count?) is a compliance/business-policy decision, not an engineering
/// one — exactly like the <c>AwayFromZero</c> rounding mode flagged
/// elsewhere in this codebase — and needs explicit sign-off before any
/// default is wired into a caller such as <c>Banking.Api</c>.
///
/// Similarly, whether a gap exactly equal to the tolerance should pass
/// (using <c>&lt;=</c>, as implemented here via
/// <see cref="ReconciliationReport.Passed"/>) or fail (<c>&lt;</c>) is a
/// policy call this class has adopted rather than one dictated by the
/// data — flagged, not silently assumed.
/// </remarks>
public sealed class ReconciliationService
{
    /// <summary>
    /// Compares a batch's <see cref="BatchPostingResult.ReconciliationGap"/>
    /// against <paramref name="tolerance"/> and reports whether it passes.
    /// </summary>
    public ReconciliationReport CheckBatch(BatchPostingResult result, decimal tolerance)
    {
        if (result is null)
        {
            throw new ArgumentNullException(nameof(result));
        }

        if (tolerance < 0)
        {
            throw new ArgumentOutOfRangeException(nameof(tolerance), "Tolerance cannot be negative.");
        }

        return new ReconciliationReport
        {
            Gap = result.ReconciliationGap,
            Tolerance = tolerance,
        };
    }
}
