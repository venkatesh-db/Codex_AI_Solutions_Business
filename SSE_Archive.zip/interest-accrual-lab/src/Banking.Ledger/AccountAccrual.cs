namespace Banking.Ledger;

/// <summary>
/// A single account's computed daily interest accrual, as produced by
/// <see cref="Banking.Interest.AccrualService"/>, awaiting posting to
/// the ledger.
/// </summary>
public sealed class AccountAccrual
{
    public string AccountId { get; init; } = string.Empty;

    public decimal DailyInterest { get; init; }
}
