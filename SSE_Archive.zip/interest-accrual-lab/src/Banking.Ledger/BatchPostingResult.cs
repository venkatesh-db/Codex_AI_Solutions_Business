namespace Banking.Ledger;

/// <summary>
/// The result of posting one night's interest accrual batch: the
/// individual entries posted per account, the batch total posted to
/// the ledger, and the independently summed total of those same
/// entries — the two figures the reconciliation job compares.
/// </summary>
public sealed class BatchPostingResult
{
    public IReadOnlyList<LedgerEntry> PostedEntries { get; init; } = Array.Empty<LedgerEntry>();

    public decimal LedgerBatchTotal { get; init; }

    public decimal SumOfPostedEntries { get; init; }

    public decimal ReconciliationGap => LedgerBatchTotal - SumOfPostedEntries;
}
