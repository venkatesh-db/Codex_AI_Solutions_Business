# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this repository is

A .NET banking lab built around one seeded defect: a nightly reconciliation job where the
ledger's posted batch total didn't equal the sum of per-account interest entries, off by a
few paise across ~50,000 accounts. See [README.md](README.md) for the original defect
write-up and the lab's design rationale (why this specific bug — it forces a distinction
between a technically correct patch and one actually authorised, since changing rounding
*policy* or backfilling historical accruals are compliance decisions, not engineering ones).

**The defects described in README.md are already fixed in the current code** — `AccrualService`
and `PostingService` are decimal-only today, and the README's line numbers and "verified
failing tests today" claims are from the original seeded state, not the current one. The fix
history, evidence, and open follow-up items are in [reports/](reports/), [CODE_REVIEW.md](CODE_REVIEW.md),
and [AI_CHANGE_LOG.md](AI_CHANGE_LOG.md); a chronological summary of everything done in the
project is in [PROJECT_EXECUTION_STEPS.md](PROJECT_EXECUTION_STEPS.md).

## Commands

```bash
# Build everything
dotnet build InterestAccrualLab.sln

# Run all tests in one project
dotnet test tests/Banking.Interest.Tests/Banking.Interest.Tests.csproj
dotnet test tests/Banking.Ledger.Tests/Banking.Ledger.Tests.csproj
dotnet test tests/Banking.Reconciliation.Tests/Banking.Reconciliation.Tests.csproj
dotnet test tests/Banking.Api.Tests/Banking.Api.Tests.csproj

# Run a single test (matches on method/class name substring)
dotnet test tests/Banking.Api.Tests/Banking.Api.Tests.csproj --filter "PostNightlyBatch_ValidAccruals_ReturnsMatchingTotals"

# Run Banking.Api locally
dotnet run --project src/Banking.Api/Banking.Api.csproj --urls http://localhost:5299
```

**Runtime gotcha:** `Banking.Interest`, `Banking.Ledger`, and their test projects target
`net6.0`. If only a newer .NET SDK/runtime is installed (check with `dotnet --list-runtimes`),
those test projects fail to launch at all (`You must install or update .NET to run this
application`) — that's an environment gap, not a code defect; don't "fix" it by patching
source. `Banking.Api` and `Banking.Api.Tests` deliberately target `net10.0` instead, for
exactly this reason — see the note in `.claude/skills/new-api-conventions/SKILL.md` §1
before changing either project's target framework. Don't paper over the mismatch with
`<RollForward>` on the net6.0 projects: combining that with the `Microsoft.AspNetCore.Mvc.Testing`
6.0.x `TestServer` produces a `PipeWriter.UnflushedBytes` crash on any JSON response — real
requests over Kestrel look fine, `dotnet test` doesn't. Always confirm with `dotnet test`
itself, not just a manual `curl` against `dotnet run`.

## Architecture

Three independent class libraries plus one thin HTTP layer, wired only in one direction:

```
Banking.Interest          Banking.Ledger              Banking.Api
Account                   AccountAccrual  <──────────  (HTTP request body)
  └─ AccrualService          LedgerEntry
     .ComputeDailyAccrual    BatchPostingResult
     (decimal, per account)    └─ PostingService.PostNightlyBatch
                                   (decimal, per batch)  ──────────>  (HTTP response)
                                   |
                                   v
                              Banking.Reconciliation
                                   └─ ReconciliationService.CheckBatch
                                      (BatchPostingResult, tolerance) -> ReconciliationReport
```

- `Banking.Ledger` does **not** reference `Banking.Interest`. The two connect only through
  the plain data type `AccountAccrual`, which a caller assembles after calling
  `AccrualService.ComputeDailyAccrual`. `Banking.Api` currently wraps `PostingService` only
  (`POST /api/postings/nightly-batch` takes pre-computed `AccountAccrual`s) — it does not
  call `AccrualService`, by design (see the "pre-computed accruals only" decision recorded
  in this project's history).
- `Banking.Reconciliation` depends on `Banking.Ledger` only (for `BatchPostingResult`), the
  same one-way pattern as `Banking.Ledger`'s relationship to `Banking.Interest` — no library
  references it back. `ReconciliationService.CheckBatch` takes the tolerance as an explicit
  caller-supplied parameter rather than a hardcoded default; the actual tolerance value and
  whether an exact-equal gap should pass are compliance/business-policy calls, not
  engineering ones — flagged, not decided, in `ReconciliationService`'s remarks.
- **Money-path rule that drove the whole fix:** `decimal` only, end to end, in both
  libraries — never `double`/`float` for anything monetary, including loop accumulators.
  Round exactly once, at the point a value is finalized (`Math.Round(value, 2,
  MidpointRounding.AwayFromZero)`), never again when that value is later summed. A batch
  total is always a plain `decimal` sum of already-rounded entries, never an independently
  re-derived figure — that re-derivation was the original bug.
- Guard-clause convention: a null parameter throws `ArgumentNullException`; an
  out-of-range value nested in an otherwise-valid parameter throws
  `ArgumentOutOfRangeException(nameof(param), ...)`; a problem discovered per-element while
  iterating a collection parameter (e.g. `PostNightlyBatch` finding an entry with a missing
  `AccountId`) throws `InvalidOperationException`, not `ArgumentException`. `Banking.Api`
  maps that `InvalidOperationException` to HTTP 400 rather than inventing a new exception
  type at the edge.

The full, detailed convention set for extending either library or `Banking.Api` — model
shape, exact validation ordering, xunit patterns (including two non-obvious gotchas around
`decimal` in `[InlineData]` and rounding-oracle tests) — is in
[.claude/skills/new-api-conventions/SKILL.md](.claude/skills/new-api-conventions/SKILL.md).
Read it before adding a new public method to this codebase rather than re-deriving these
rules from scratch.

## Automation in this repo

- **`.claude/hooks/verify_cs_change.py`** (wired via `.claude/settings.json`, `PostToolUse` on
  `Write|Edit`) — after any `.cs` edit, builds the owning project and runs its matching test
  project automatically, reporting real pass/fail back immediately. This exists specifically
  because a prior session reported a new API as built without ever running it — don't remove
  or bypass this to "save time"; that's the exact failure mode it closes.
  net6.0 test projects that can't launch in a runtime-less sandbox are reported as skipped,
  not failed (see the Runtime gotcha above) — a real build or test failure is never suppressed.
- **`.claude/workflows/add-new-api.js`** — a named Workflow (`Workflow({name: "add-new-api",
  args: {spec: "..."}})`) that runs the full add-an-API pipeline: design against the skill,
  test-first implement, a real `dotnet build`/`dotnet test` run, a self-audit against the
  skill checklist, and an adversarial review pass (independent agents trying to refute the
  audit) before reporting. Use it instead of an ad hoc multi-turn implementation when adding
  a new public API — it structurally forces the verification and audit steps a manual session
  can skip under time pressure.

## Known open items

Carried from the self-review after the original fix (still unresolved as of the last
skill-based re-check in [reports/08-skill-code-review.md](reports/08-skill-code-review.md)):

1. `PostingService.cs`'s class-level `<remarks>` still describe the old double-rounding
   behavior that no longer happens.
2. `SumEntries` and `ComputeLedgerBatchTotal` in `PostingService.cs` are now identical,
   undeduplicated private methods.
3. No test covers an exact rounding midpoint under `MidpointRounding.AwayFromZero`.

Also still outstanding, and explicitly **not** an engineering decision: compliance
confirmation that `AwayFromZero` is the correct rounding rule, and whether this change to a
regulated posting figure needs sign-off beyond code review.
