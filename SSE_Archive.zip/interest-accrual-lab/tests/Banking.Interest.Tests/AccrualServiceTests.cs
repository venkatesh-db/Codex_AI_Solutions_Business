using Banking.Interest;
using Xunit;

namespace Banking.Interest.Tests;

public sealed class AccrualServiceTests
{
    private readonly AccrualService _sut = new();

    [Fact]
    public void ComputeDailyAccrual_ThrowsOnNullAccount()
    {
        Assert.Throws<ArgumentNullException>(() => _sut.ComputeDailyAccrual(null!));
    }

    [Fact]
    public void ComputeDailyAccrual_ThrowsOnNegativePrincipal()
    {
        var account = new Account
        {
            AccountId = "ACC-1",
            PrincipalBalance = -100m,
            AnnualInterestRate = 0.05m,
        };

        Assert.Throws<ArgumentOutOfRangeException>(() => _sut.ComputeDailyAccrual(account));
    }

    [Fact]
    public void ComputeDailyAccrual_ThrowsOnNegativeRate()
    {
        var account = new Account
        {
            AccountId = "ACC-1",
            PrincipalBalance = 1000m,
            AnnualInterestRate = -0.05m,
        };

        Assert.Throws<ArgumentOutOfRangeException>(() => _sut.ComputeDailyAccrual(account));
    }

    /// <summary>
    /// Confirmed reproduction cases: for these (principal, rate) pairs,
    /// the true decimal-arithmetic daily interest and the value
    /// <see cref="AccrualService.ComputeDailyAccrual"/> actually
    /// returns (computed via <c>double</c>, per lines 44-52) round to
    /// different paise. Values were found by exhaustively comparing
    /// decimal vs. double arithmetic across randomised (principal,
    /// rate) pairs — see the lab's investigation notes for the search
    /// used to derive them.
    /// </summary>
    [Theory]
    [InlineData(6661.25, 0.18, 3.29)]
    [InlineData(1825.00, 0.187, 0.93)]
    public void ComputeDailyAccrual_KnownMismatchPair_MatchesExactDecimalArithmetic(
        decimal principal, decimal rate, decimal expectedExact)
    {
        var account = new Account
        {
            AccountId = "ACC-MISMATCH",
            PrincipalBalance = principal,
            AnnualInterestRate = rate,
        };

        // Sanity check: expectedExact really is what exact decimal
        // arithmetic produces for this pair, independent of the
        // service under test.
        decimal exact = Math.Round(
            principal * (rate / 365m), 2, MidpointRounding.ToEven);
        Assert.Equal(expectedExact, exact);

        decimal actual = _sut.ComputeDailyAccrual(account);

        // This is the assertion that fails against the seeded defect:
        // the service's double-based computation rounds to a
        // different paisa than exact decimal arithmetic for the same
        // account.
        Assert.Equal(expectedExact, actual);
    }
}
