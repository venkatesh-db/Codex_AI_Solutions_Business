using System.Net;
using System.Net.Http.Json;
using Banking.Ledger;
using Microsoft.AspNetCore.Mvc.Testing;
using Xunit;

namespace Banking.Api.Tests;

public sealed class PostingsEndpointTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _client;

    public PostingsEndpointTests(WebApplicationFactory<Program> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task PostNightlyBatch_ValidAccruals_ReturnsMatchingTotals()
    {
        var accruals = new[]
        {
            new AccountAccrual { AccountId = "ACC-1", DailyInterest = 1.23m },
            new AccountAccrual { AccountId = "ACC-2", DailyInterest = 4.56m },
        };

        var response = await _client.PostAsJsonAsync("/api/postings/nightly-batch", accruals);

        var body = await response.Content.ReadAsStringAsync();
        Assert.True(response.IsSuccessStatusCode, $"Status {response.StatusCode}: {body}");
        var result = await response.Content.ReadFromJsonAsync<BatchPostingResult>();

        Assert.NotNull(result);
        Assert.Equal(2, result!.PostedEntries.Count);
        Assert.Equal(result.SumOfPostedEntries, result.LedgerBatchTotal);
        Assert.Equal(0m, result.ReconciliationGap);
    }

    [Fact]
    public async Task PostNightlyBatch_LargeBatch_MatchesSumOfPostedEntries()
    {
        var accruals = Enumerable.Range(1, 5_000)
            .Select(i => new AccountAccrual
            {
                AccountId = $"ACC-{i}",
                DailyInterest = Math.Round(0.005m * (i % 37), 2),
            })
            .ToList();

        var response = await _client.PostAsJsonAsync("/api/postings/nightly-batch", accruals);

        response.EnsureSuccessStatusCode();
        var result = await response.Content.ReadFromJsonAsync<BatchPostingResult>();

        Assert.NotNull(result);
        Assert.Equal(result!.SumOfPostedEntries, result.LedgerBatchTotal);
        Assert.Equal(0m, result.ReconciliationGap);
    }

    [Fact]
    public async Task PostNightlyBatch_MissingAccountId_ReturnsBadRequest()
    {
        var accruals = new[]
        {
            new AccountAccrual { AccountId = "", DailyInterest = 1.23m },
        };

        var response = await _client.PostAsJsonAsync("/api/postings/nightly-batch", accruals);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task PostNightlyBatch_EmptyBody_ReturnsBadRequest()
    {
        var response = await _client.PostAsync(
            "/api/postings/nightly-batch",
            JsonContent.Create<AccountAccrual[]?>(null));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }
}
