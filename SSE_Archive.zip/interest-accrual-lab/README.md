# Interest Accrual Reconciliation Mismatch — Lab Project

Retail banking, daily interest accrual. The nightly reconciliation
batch fails: the ledger total does not equal the sum of per-account
interest. The gap is a few paise across roughly 50,000 accounts —
small enough to ignore, large enough to fail reconciliation every
night and become an audit finding if it persists.

## Solution layout

```
InterestAccrualLab.sln
src/
  Banking.Interest/
    Account.cs
    AccrualService.cs        <- seeded defects #1 and #2
  Banking.Ledger/
    AccountAccrual.cs
    LedgerEntry.cs
    BatchPostingResult.cs
    PostingService.cs        <- seeded defect #3
tests/
  Banking.Interest.Tests/
    AccrualServiceTests.cs
  Banking.Ledger.Tests/
    PostingServiceTests.cs
```

## Seeded defects

1. **`src/Banking.Interest/AccrualService.cs:47`** — the per-account
   daily interest is computed in `double`
   (`principal * dailyRate`), after both operands are converted from
   `decimal` to `double`.
2. **`src/Banking.Interest/AccrualService.cs:52`** — the `double`
   result is rounded back with `Math.Round(value, 2)`. .NET's default
   `MidpointRounding` is `ToEven` (banker's rounding), so this is
   correct *policy*, but it is rounding a value that has already lost
   precision in step 1.
3. **`src/Banking.Ledger/PostingService.cs:120`** — the batch total
   posted to the ledger is re-derived by summing the already-rounded
   per-account entries in `double` and rounding *again*, instead of
   reusing the exact `decimal` sum of the same entries
   (`SumOfPostedEntries`).

The mismatch comes from rounding twice at different levels (once per
account, once per batch), compounded by binary `double`
representation error at the per-account level.

## Reproducing the defect

```bash
dotnet test
```

`Banking.Interest.Tests.AccrualServiceTests` includes two
deterministic, confirmed-mismatch cases:

| Principal | Annual rate | Exact decimal result | `AccrualService` returns |
|---|---|---|---|
| 6661.25 | 0.18 | 3.29 | 3.28 |
| 1825.00 | 0.187 | 0.93 | 0.94 |

Both are verified failing tests today — they demonstrate that for
specific (principal, rate) pairs, the `double`-based computation in
`AccrualService.ComputeDailyAccrual` rounds to a different paisa than
exact `decimal` arithmetic would for the exact same account. Across
~50,000 real accounts, enough balances land near one of these
midpoint-adjacent values that the net reconciliation gap is small but
persistent — never zero, never large, always a few paise.

`Banking.Ledger.Tests.PostingServiceTests` exercises the
`PostNightlyBatch` plumbing (validation, one entry per accrual,
`ReconciliationGap` calculation). Note: at realistic banking-batch
magnitudes (tens of thousands of entries, each already rounded to 2
decimal places, summing to a few crore), IEEE-754 `double` has enough
precision that the *summation* step in `ComputeLedgerBatchTotal`
alone essentially never drifts a full cent — this was confirmed by
random search over millions of synthetic batches. Defect #3 is a real
architectural anti-pattern (an unnecessary `double` round-trip on data
that was already exact `decimal`), and it is the layer at which the
*real* production incident would show a mismatch once fed
`AccrualService`'s already-biased per-account amounts — but it is not
independently reproducible as a unit test in isolation from defect
#1/#2. That distinction — "structurally wrong" vs. "empirically
provable at this scale" — is itself part of what this lab is testing
participants on.

## Why this defect was chosen (per the lab design notes)

The arithmetic is simple enough that every participant can follow it,
but two of the seven stages of triage surface decisions engineering
is not authorised to make alone:

- Changing the rounding **policy** (e.g. switching away from banker's
  rounding, or changing where in the pipeline rounding happens)
  changes numbers on customer-facing statements and the general
  ledger — that requires sign-off from Finance/Compliance, not just
  an engineering patch.
- Backfilling ~50,000 accounts' historical accrual once the
  computation changes is a data-remediation decision with audit
  implications, not a code-review decision.

The gap between a technically correct patch (switch `double` to
`decimal`, remove the redundant re-round) and an *authorised* one is
the point of the exercise.
