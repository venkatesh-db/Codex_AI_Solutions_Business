# The `add-new-api` workflow — a guide for newcomers

This project has an automated pipeline for adding a new public API to the codebase. It
lives at [.claude/workflows/add-new-api.js](.claude/workflows/add-new-api.js) and is meant
to replace the ad hoc "implement it, then maybe test it, then maybe review it" flow with
something that always does all of those steps, in order, whether or not anyone remembers to
ask.

It exists because an earlier manual session on this project reported a new API ("done!")
before ever running its tests. This workflow makes that specific failure structurally
impossible: verification and review aren't optional follow-ups here, they're phases 3–5 of
the same run.

## How to run it

There's no separate CLI command — you ask Claude Code in plain language, and it invokes the
workflow on your behalf. The trigger is:

```
Run the add-new-api workflow with spec: "<plain-language description of the new API>"
```

**Sample, ready to use:**

```
Run the add-new-api workflow with spec: "A LedgerHistoryService in Banking.Ledger with
GetEntriesForAccount(string accountId, IReadOnlyList<LedgerEntry> allEntries) returning
only that account's entries."
```

Under the hood this becomes a `Workflow` tool call with `args: { spec: "..." }`. Invoking it
*by name* (`Workflow({ name: "add-new-api" })`) is not currently reliable in this
environment — Claude Code falls back to passing the saved script's contents inline instead,
which works the same way and has already been proven to run correctly end-to-end (see
[Real example run](#real-example-run-what-actually-happened) below).

**Cost, before you run it:** this is not a quick action. A real run is ~9 agents, on the
order of 450,000 tokens, and takes several minutes. It's worth it for a real new API; it
isn't worth running just to see what happens.

## What it actually does — six phases

The script (plain JavaScript, not TypeScript, run by the `Workflow` tool) defines six
phases. Every phase is a real agent doing real work against the actual repository — reading
files, writing files, running `dotnet` — not a summary of what *should* happen.

### 1. Design
One agent reads [.claude/skills/new-api-conventions/SKILL.md](.claude/skills/new-api-conventions/SKILL.md)
in full, then [CLAUDE.md](CLAUDE.md), then reads the existing service most similar to what's
being asked for — end to end, not just its signature — before proposing anything. It returns
a structured plan (validated against a JSON schema, not free text): exact files to create or
modify, exact public method signatures, a list of tests to write *first*, and anything that
looks like a business or compliance decision rather than an engineering one (so it can be
flagged instead of silently decided).

### 2. Implement
Two agents run in sequence, enforcing test-first order for real:
- The first writes the test file(s) from the design's test list, confirms they fail to even
  build against the current (nonexistent) implementation, and stops — no production code yet.
- The second then writes the production code to make those tests pass, following the skill's
  guard-clause order, decimal-only rule (where money is involved), and API shape — without
  touching the test file it was just handed.

### 3. Verify
A dedicated agent runs `dotnet build InterestAccrualLab.sln` and `dotnet test` on every
affected test project, using Bash — and reports the *actual* exit codes and *actual* output
tail, not a restated claim. If a net6.0-targeted test project can't even launch because this
sandbox has no net6.0 runtime installed, that's reported as an environment gap, not a code
failure — see the Runtime gotcha in [CLAUDE.md](CLAUDE.md). Every other kind of failure is
reported as a real failure.

### 4. Audit
A separate agent re-reads the skill's checklist (§8) and independently re-checks the diff —
it greps the changed files for `double`/`float` itself, checks guard-clause ordering itself,
checks file modification times to confirm tests were really written first, rather than
trusting anything the Implement phase reported about itself.

### 5. Adversarial Review
Three independent agents each try to find *one real issue* the audit missed — a wrong
exception type, a rounding call that isn't a single application, a test that doesn't
actually discriminate between correct and buggy behavior, a decision that was flagged in a
comment but implemented anyway instead of left open. Each is explicitly told not to
manufacture an issue just to seem thorough — "no issue found" is an accepted, honest answer.

### 6. Report
One final agent synthesizes everything above — what was built, the real verify results, the
audit's pass/fail table, whatever the adversarial reviewers found (or didn't), and the list
of anything still waiting on human/compliance sign-off — into one report.

## Real example run — what actually happened

This isn't hypothetical. The workflow has already been run once for real, with the spec:

> "A ReconciliationService in a new Banking.Reconciliation library, with one public method
> CheckBatch(BatchPostingResult result) returning a ReconciliationReport (pass/fail, the
> gap, and a tolerance value). The tolerance itself must be flagged as a compliance
> decision, not hardcoded silently."

What actually came out of it:

- **9 agents, ~459,000 tokens, ~9 minutes.**
- **Built for real:** a new `Banking.Reconciliation` library with
  `ReconciliationService.CheckBatch(BatchPostingResult, decimal tolerance)`, verified to
  exist on disk and to build with 0 errors independently of the workflow's own claim.
- **Verify was honest about its own limits:** `dotnet build` succeeded, but only one of the
  four touched test projects (`Banking.Api.Tests`, net10.0) could actually *execute* in this
  sandbox — the new `Banking.Reconciliation.Tests` project compiled but never ran, same
  net6.0-runtime gap as the rest of the repo. The report said so plainly instead of claiming
  a pass it hadn't demonstrated.
- **Audit caught a real defect on itself:** a `ReconciliationTolerance` wrapper class was
  created but never actually wired into `CheckBatch`'s signature — dead code contradicting
  its own doc comment.
- **Adversarial review caught two more things the audit missed:** one test whose chosen
  values passed under both the correct implementation and an obviously wrong one (so it
  wasn't really testing anything), and one policy decision that was flagged in a code
  comment but shipped as live, unguarded logic anyway — which the skill explicitly says not
  to do.

None of that was invented for this document — it's the literal outcome of the one real run
so far. That's also the point: the workflow is designed to surface exactly this kind of
thing on its own, so a newcomer reviewing its output doesn't have to take "it's done" at
face value.

## When to use it vs. when not to

Use it for adding a genuine new public API to `Banking.Interest`, `Banking.Ledger`,
`Banking.Api`, or a new sibling library — anything where you want the design decisions,
test-first discipline, real verification, and a second opinion, without a long manual
back-and-forth.

Don't use it to fix an already-identified bug in existing code, to make a small edit, or
just to see the pipeline work — it's expensive, and a normal editing turn is faster and
cheaper for anything that isn't "build a new public API from a description."
