export const meta = {
  name: 'add-new-api',
  description: 'Add a new API to interest-accrual-lab end-to-end: design against the skill, test-first implement, real dotnet build/test verification, skill-compliance audit, adversarial review, report.',
  whenToUse: 'Invoke with args: { spec: "plain-language description of the new API to add" } whenever adding a new public method/endpoint to this project. Structurally enforces the verification step that was previously skipped by default: it always runs dotnet build/test for real and always has independent skeptics try to refute the self-audit before reporting done.',
  phases: [
    { title: 'Design', detail: 'plan the new API against .claude/skills/new-api-conventions/SKILL.md' },
    { title: 'Implement', detail: 'write failing tests first, then the production code' },
    { title: 'Verify', detail: 'run dotnet build/test for real, report actual output' },
    { title: 'Audit', detail: 'independently re-check the diff against the skill checklist' },
    { title: 'Adversarial Review', detail: '3 independent skeptics try to refute the audit' },
    { title: 'Report', detail: 'synthesize the run into one report' },
  ],
}

if (!args || !args.spec) {
  throw new Error('add-new-api requires args: { spec: "plain-language description of the new API to add" }')
}

const DESIGN_SCHEMA = {
  type: 'object',
  properties: {
    filesToCreate: { type: 'array', items: { type: 'string' } },
    filesToModify: { type: 'array', items: { type: 'string' } },
    publicSignatures: { type: 'array', items: { type: 'string' } },
    testPlan: { type: 'array', items: { type: 'string' } },
    openFlags: {
      type: 'array',
      items: { type: 'string' },
      description: 'Anything that looks like a rounding-policy, compliance, or historical-data decision that must be flagged to a human rather than decided silently.',
    },
  },
  required: ['filesToCreate', 'filesToModify', 'publicSignatures', 'testPlan', 'openFlags'],
}

const VERIFY_SCHEMA = {
  type: 'object',
  properties: {
    buildOk: { type: 'boolean' },
    perProject: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          project: { type: 'string' },
          testsOk: { type: 'boolean' },
          note: { type: 'string', description: 'e.g. "environment gap: no net6.0 runtime" vs a real failure summary' },
        },
        required: ['project', 'testsOk', 'note'],
      },
    },
    rawOutputTail: { type: 'string' },
  },
  required: ['buildOk', 'perProject', 'rawOutputTail'],
}

const AUDIT_SCHEMA = {
  type: 'object',
  properties: {
    checklistResults: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          item: { type: 'string' },
          verdict: { type: 'string', enum: ['PASS', 'FAIL', 'N/A'] },
          why: { type: 'string' },
        },
        required: ['item', 'verdict', 'why'],
      },
    },
    testFirstOrderHonored: { type: 'boolean' },
  },
  required: ['checklistResults', 'testFirstOrderHonored'],
}

const REFUTE_SCHEMA = {
  type: 'object',
  properties: {
    foundIssue: { type: 'boolean' },
    description: { type: 'string' },
    file: { type: 'string' },
  },
  required: ['foundIssue', 'description'],
}

phase('Design')
const design = await agent(
  `You are extending the .NET project interest-accrual-lab. Read .claude/skills/new-api-conventions/SKILL.md in full, then CLAUDE.md, then read the existing service most similar to what's being requested end to end (not just its signature) before proposing anything. The new API to add: ${args.spec}. Produce a concrete plan: exact file paths to create or modify, exact public method signatures following the skill's guard-clause and decimal-only conventions where money is involved, and a test list to write FIRST (guard-clause cases, plus a large-N aggregate test if the method sums or batches many entries, per the skill's §7). Separately list anything that looks like a rounding-policy, compliance, or historical-data decision — those get flagged, never decided silently.`,
  { schema: DESIGN_SCHEMA, phase: 'Design' }
)
log(`Design ready: ${design.filesToCreate.length} new file(s), ${design.filesToModify.length} modified, ${design.testPlan.length} test(s) planned.`)

phase('Implement')
const testsWritten = await agent(
  `Given this design: ${JSON.stringify(design)}. Write the test file(s) from testPlan FIRST, following .claude/skills/new-api-conventions/SKILL.md §7 exactly — including the decimal-in-[InlineData] gotcha and the rounding-oracle gotcha if either applies. Do NOT write the production code yet. Confirm the tests fail to build/run against the current (unimplemented) code, since that's the point of writing them first. Report the exact file paths you created.`,
  { phase: 'Implement', label: 'write-tests-first' }
)
const implemented = await agent(
  `Given this design: ${JSON.stringify(design)} and these already-written failing tests: ${testsWritten}. Now implement the production code in filesToCreate/filesToModify, following the skill's money-path rules (§3), validation ordering (§4), and public API shape (§5) exactly. Do not modify the test files you just read about. Report the files you changed and a one-line summary of each change.`,
  { phase: 'Implement', label: 'implement-production-code' }
)

phase('Verify')
const verify = await agent(
  `Using Bash, run \`dotnet build InterestAccrualLab.sln\` and then \`dotnet test\` on every test project touched by this change (see CLAUDE.md's project layout). Report the ACTUAL exit codes and ACTUAL output — do not summarize as "should pass"; paste real tail output. If a net6.0-targeted test project fails specifically with "You must install or update .NET to run this application", treat that one project as an environment gap (note it, testsOk should reflect that this is not a code failure), per CLAUDE.md's documented runtime gotcha — every other failure is real and must be reported as such.`,
  { schema: VERIFY_SCHEMA, phase: 'Verify' }
)
log(`Verify: build ${verify.buildOk ? 'OK' : 'FAILED'}; ${verify.perProject.map(p => `${p.project}=${p.testsOk ? 'OK' : 'FAIL'}`).join(', ')}`)

phase('Audit')
const audit = await agent(
  `Re-read .claude/skills/new-api-conventions/SKILL.md §8 (the checklist) and independently re-check the change just made against every item: guard-clause order, decimal-only math, single rounding point (if applicable), model shape reuse, whether test-first order was actually honored (read file mtimes / the reported sequence, don't just trust the implementer), the xunit gotchas from §7, and whether anything should have been flagged per §6 but wasn't. Grep the new/changed files for "double" and "float" yourself rather than trusting any prior summary. List each checklist item with PASS, FAIL, or N/A and why.`,
  { schema: AUDIT_SCHEMA, phase: 'Audit' }
)

phase('Adversarial Review')
const votes = await parallel(
  Array.from({ length: 3 }, (_, i) => () =>
    agent(
      `Independently audit the new API just added to interest-accrual-lab. Design: ${JSON.stringify(design)}. The self-audit claimed: ${JSON.stringify(audit)}. Try to find ONE real compliance or correctness violation the self-audit missed — a decimal/double slip, a wrong exception type, a rounding call that isn't a single AwayFromZero application, a test that wouldn't actually have failed without the implementation, or a business/compliance decision made silently instead of flagged. Read the actual files yourself; do not trust prior summaries. If you genuinely can't find a real issue, say so honestly — do not manufacture one to seem thorough.`,
      { schema: REFUTE_SCHEMA, phase: 'Adversarial Review', label: `skeptic-${i + 1}` }
    )
  )
)
const realIssues = votes.filter(Boolean).filter(v => v.foundIssue)
log(realIssues.length ? `${realIssues.length} issue(s) surfaced by adversarial review.` : 'No issues survived adversarial review.')

phase('Report')
const report = await agent(
  `Write a concise end-to-end report of this "add new API" run. Cover: what was built (files and public signatures), the REAL build/test results from Verify (${JSON.stringify(verify)}) — paste actual pass/fail, not a restated claim — the Audit's PASS/FAIL table (${JSON.stringify(audit)}), and the adversarial review's findings (${JSON.stringify(realIssues)}, or state plainly that none were found). End with an explicit list of anything flagged for human or compliance sign-off rather than decided (from design.openFlags: ${JSON.stringify(design.openFlags)}).`,
  { phase: 'Report' }
)

return { design, verify, audit, issuesFound: realIssues, report }
