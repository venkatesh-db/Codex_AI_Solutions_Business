# AI Change Log — Interest Accrual Reconciliation Fix

Full, itemized record of every change made by the AI (Claude) to this repository during this session, for human tracking/audit. Every source-code change is numbered `T1`, `T2`, ... in the order it was made. Nothing in this repo was changed outside of what is listed here.

**Scope note:** this session touched exactly **2 source files**. No other `.cs` file, `.csproj`, `.sln`, model type, test file, or config was modified.

---

## T1 — `src/Banking.Interest/AccrualService.cs`

**What changed:** the per-account daily interest calculation, inside `ComputeDailyAccrual`.

**Before:**
```csharp
double principal = (double)account.PrincipalBalance;
double dailyRate = (double)account.AnnualInterestRate / DaysInYear;

double dailyInterest = principal * dailyRate;

decimal rounded = Math.Round((decimal)dailyInterest, 2);

return rounded;
```

**After:**
```csharp
decimal dailyRate = account.AnnualInterestRate / DaysInYear;
decimal dailyInterest = account.PrincipalBalance * dailyRate;

return Math.Round(dailyInterest, 2, MidpointRounding.AwayFromZero);
```

**Exactly what this does:**
- Removed both `double` casts. `PrincipalBalance` and `AnnualInterestRate` (both `decimal` on the model) are now multiplied/divided in `decimal` throughout — no floating-point step at all.
- Rounding mode changed from the implicit default (`MidpointRounding.ToEven`) to explicit `MidpointRounding.AwayFromZero`.
- Rounding still happens exactly once, at the same point in the method (immediately before return).

**Why:** `AccrualServiceTests.ComputeDailyAccrual_KnownMismatchPair_MatchesExactDecimalArithmetic` failed against the old code for two known (principal, rate) pairs — the `double` round-trip produced a different paisa than exact decimal arithmetic. The rounding-mode change to `AwayFromZero` was an explicit instruction, not something I inferred.

**Who approved this:** you, explicitly, in the message beginning "Approved. Constraints for implementation: ... MidpointRounding.AwayFromZero..."

**Verification:** `dotnet test` — both previously-failing cases now pass. See T-VERIFY below.

---

## T2 — `src/Banking.Ledger/PostingService.cs`

**What changed:** the private method `ComputeLedgerBatchTotal`, called once from `PostNightlyBatch`.

**Before:**
```csharp
private static decimal ComputeLedgerBatchTotal(IReadOnlyList<LedgerEntry> entries)
{
    double runningTotal = 0d;

    foreach (var entry in entries)
    {
        runningTotal += (double)entry.Amount;
    }

    return Math.Round((decimal)runningTotal, 2);
}
```

**After:**
```csharp
private static decimal ComputeLedgerBatchTotal(IReadOnlyList<LedgerEntry> entries)
{
    decimal runningTotal = 0m;

    foreach (var entry in entries)
    {
        runningTotal += entry.Amount;
    }

    return runningTotal;
}
```

**Exactly what this does:**
- Accumulator type changed `double` → `decimal`.
- Removed the `(double)` cast on each entry's `Amount` inside the loop.
- Removed the final `Math.Round((decimal)runningTotal, 2)` call entirely — the batch total is no longer rounded a second time. (It's already an exact sum of 2dp `decimal` values, so no rounding is needed or applied.)
- The method's XML doc comment was also edited to describe the new behavior (from "re-derives via double round-trip" to "plain decimal sum, no further rounding"). This is a comment-only change, no behavior implication.

**What did NOT change in this file:**
- `PostNightlyBatch` (the public entry point) — untouched, same signature, same validation logic, same call sequence.
- `SumEntries` — untouched (was already correct, `decimal`-only).
- The class-level and `PostNightlyBatch`-level `<remarks>`/comments describing the *old* buggy behavior were **left in place, not updated** — flagged separately in the code review as now-stale/misleading documentation. This is a known gap, not an oversight I'm hiding.

**Why:** `ComputeLedgerBatchTotal` re-derived the batch total via a `double` accumulator on values that were already exact 2dp decimals, reintroducing floating-point representation error, then rounded a second time — a second, unnecessary, and non-deterministic-relative-to-`SumEntries` rounding step. This is what the original recon failure was traced to.

**Who approved this:** you, via the same approval message — "Round once, per account. Never round the batch total" and "decimal only. No double or float anywhere in the money path."

**Verification:** `dotnet test` — `PostNightlyBatch_LedgerBatchTotal_MatchesSumOfPostedEntries` (50,000-account fixture) and a separate 5,000-account synthetic fixture I ran manually both show `ReconciliationGap == 0.00` exactly. See T-VERIFY below.

---

## T-VERIFY — Verification run after T1 + T2

Command: `dotnet test InterestAccrualLab.sln`

Result: **9/9 tests passed** (0 before this session's fix; 2 were failing beforehand in `AccrualServiceTests`).

5,000-account synthetic fixture (built outside the repo in `/tmp/fixture-check`, run once, then deleted — not part of this repository, no trace left behind):
```
Accounts: 5000
SumOfPostedEntries: 203831.35
LedgerBatchTotal:   203831.35
ReconciliationGap:  0.00
```

Full raw command output for both is in [reports/05-validate.md](reports/05-validate.md).

---

## Everything else created this session (documentation, not code)

These files were **added**, not modified — they don't touch any existing file's behavior, and none of them are compiled/executed as part of the application:

| File | Type |
|---|---|
| `reports/recon-fail-2026-08-16-investigation.md` | Investigation notes (problem statement, code trace, plan) |
| `reports/04-implement.md` | Implementation notes (this T1/T2 diff, narrated) |
| `reports/05-validate.md` | Raw test/fixture output |
| `reports/06-review.md` | Self-review / self-identified objections |
| `reports/07-report.md` | Commands-run / files-changed / unresolved-items summary |
| `CODE_REVIEW.md` | Team-facing review summary |
| `AI_CHANGE_LOG.md` | This file |

## What I did NOT touch, and want to be explicit about

- No test file (`AccrualServiceTests.cs`, `PostingServiceTests.cs`) was modified, even though `AccrualServiceTests.cs` still hard-codes `MidpointRounding.ToEven` in its own sanity-check math — flagged in the review docs as worth a second look, but I did not silently edit a test to make my change look more correct.
- No model type (`Account.cs`, `AccountAccrual.cs`, `LedgerEntry.cs`, `BatchPostingResult.cs`) was touched.
- No `.csproj` or `.sln` file was touched.
- Interest rates, the accrual formula's structure (`principal × rate / 365`), the batch schedule, and the reconciliation job itself were not touched — all explicitly out of bounds per your constraints, and I did not go near them.
- No historical/backfill logic was written for the ~50,000 existing accounts — explicitly out of scope per your instruction ("historical balances are out of scope — future accruals only").
