# 8. SKILL CODE REVIEW — `dotnet-code-review` applied to current state

**Skill:** `~/.claude/skills/dotnet-code-review/SKILL.md`
**Scope:** full checklist applied against the current committed state of `src/Banking.Interest`, `src/Banking.Ledger`, and `tests/` — not just the diff.

## 1. Numeric-type audit

- **No live `double`/`float` in the money path.** Confirmed by grep across `src/` and `tests/`: the only remaining occurrences of "double" are in comments/doc text (`PostingService.cs:67`, `AccrualService.cs:44`, and three test doc-comments), not executable code. **Pass.**
- **Independent-total paths.** `PostingService.ComputeLedgerBatchTotal` and `SumEntries` are now structurally identical — both accumulate `decimal` in a loop, no rounding. They can no longer diverge. **Pass**, but see §3 — they're now duplicates of each other rather than one deriving from the other.
- **Rounding count/location.** `AccrualService.ComputeDailyAccrual` rounds exactly once (`Math.Round(..., 2, MidpointRounding.AwayFromZero)`, line 45). `PostingService.ComputeLedgerBatchTotal` and `SumEntries` round zero times — they sum already-rounded values and return the sum as-is. **Pass** — matches "round once per account, never round the batch total."
- **Rounding mode.** `AwayFromZero`, explicit, single declared site (`AccrualService.cs:45`). **Flag (not a code defect):** this is a behavior change from the previous `ToEven` default and needs the sign-off called out in `CODE_REVIEW.md`. I have no evidence that sign-off has actually happened, only that it's logged as required.

## 2. Test evidence

- Fail-before/pass-after evidence exists and is documented with raw `dotnet test` output, not summaries (`reports/04-implement.md`, `05-validate.md`). **Pass.**
- Numeric acceptance criterion (`ReconciliationGap == 0.00`, exact) is present both in `PostingServiceTests.cs:70` and in the manually-run 5,000-account fixture. **Pass.**
- **Open defect, confirmed still present:** `tests/Banking.Interest.Tests/AccrualServiceTests.cs:68-69` computes its "exact" sanity value using `MidpointRounding.ToEven`, while the production code it checks now rounds `AwayFromZero`. The test currently passes only because neither seeded (principal, rate) pair lands on an exact `x.xx5` midpoint after full-precision decimal division — not because the rounding mode is actually verified. **No midpoint test case exists anywhere in the suite.**
- The 50,000-account fixture in `PostingServiceTests.cs:56-65` (37 distinct values, cycled) gives reasonable coverage for the batch-summation bug it targets, but does not exercise `AccrualService` at all (it constructs `AccountAccrual` directly), so it does not substitute for the missing midpoint test above.

## 3. Scope discipline

- Diff scope matches what's documented — only `AccrualService.cs` and `PostingService.cs` changed; re-verified by grep, no stray edits elsewhere. **Pass.**
- Rates, schedule, reconciliation job, and all model types (`Account.cs`, `AccountAccrual.cs`, `LedgerEntry.cs`, `BatchPostingResult.cs`) confirmed untouched by direct inspection. **Pass.**
- **Open defect, confirmed still present:** `PostingService.cs` lines 15-21 (class remarks) and 64-69 (`PostNightlyBatch` comment) still describe the *old* buggy double round-trip as if it were current behavior ("re-derives... round-trips through double before rounding again... for consistency with the summary report formatter downstream"). Factually wrong now.
- **Open defect, confirmed still present:** `ComputeLedgerBatchTotal` and `SumEntries` in `PostingService.cs` are now functionally identical (same loop, same accumulator, same return). No decision has been made or recorded to consolidate or justify keeping both.

## 4. General C#/.NET correctness

- Nullable reference types: `Nullable=enable` on both `src` projects; no `!` suppressions found. **Pass.**
- No async code in this path — `.Result`/`.Wait()` check is not applicable.
- Models use `sealed class` with `init`-only properties — effectively immutable, consistent across all four types even though not declared as `record`. Not a defect.
- Guard clauses at method entry in both `AccrualService.ComputeDailyAccrual` and `PostingService.PostNightlyBatch` — null/negative/empty checks up front, business logic after. **Pass.**
- Exceptions are specific (`ArgumentNullException`, `ArgumentOutOfRangeException`, `InvalidOperationException`); no generic `catch (Exception)` anywhere in `src/`. **Pass.**

## 5. AI-authored-change verification

- The numbered change log (`AI_CHANGE_LOG.md`, T1/T2) was independently re-verified against current source via grep/read in this pass, not just re-cited. It holds up.
- "Not touched" claims (rates, schedule, models, recon job) were independently confirmed above, not merely re-asserted from the log.
- "All tests pass" was treated as a starting point: the numeric-type and test-evidence checks were re-run directly against current source in this review rather than relying on prior results alone.

## Summary — open items

Three items, all previously flagged in [06-review.md](06-review.md), are **confirmed still open** in the current codebase. No new issues were found in this pass.

| # | File | Issue | Status |
|---|---|---|---|
| 1 | `PostingService.cs:15-21, 64-69` | Stale comments describing the old, now-fixed double-based behavior as current | Open |
| 2 | `PostingService.cs` | `ComputeLedgerBatchTotal` and `SumEntries` are functionally duplicate methods; no consolidation decision recorded | Open |
| 3 | `AccrualServiceTests.cs` | No test exercises an exact rounding midpoint under `AwayFromZero`; existing sanity check uses `ToEven` math and passes only because its two data points aren't midpoints | Open |

Recommend treating items 1-3 as blocking for merge sign-off, or explicitly deferring each with a named owner and date — currently they are noted but not tracked to closure.
