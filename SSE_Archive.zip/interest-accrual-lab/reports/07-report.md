# 7. REPORT — Recon Fail 2026-08-16

## Commands run

- `dotnet test InterestAccrualLab.sln` — before patch (2 failures in `AccrualServiceTests`; `Banking.Ledger.Tests` all green)
- `dotnet test InterestAccrualLab.sln` — after patch (9/9 passed)
- Ad hoc `dotnet run` of a throwaway 5,000-account console fixture (`/tmp/fixture-check`, deleted after use — not part of the repo) exercising `AccrualService` → `PostingService` end-to-end

## Files changed

- [src/Banking.Interest/AccrualService.cs](../src/Banking.Interest/AccrualService.cs) — removed `double` cast/multiply; single decimal computation, single `Math.Round(..., 2, MidpointRounding.AwayFromZero)` call.
- [src/Banking.Ledger/PostingService.cs](../src/Banking.Ledger/PostingService.cs) — `ComputeLedgerBatchTotal` now accumulates in `decimal` (was `double`) and returns the sum unrounded (removed the second `Math.Round` pass).

No changes made to: rates, batch schedule, the reconciliation job, or any model types (`Account`, `AccountAccrual`, `LedgerEntry`, `BatchPostingResult`). No historical/backfill code written — future accruals only, per the stated boundary.

## What remains unverified

- The original `evidence/recon-fail-2026-08-16.txt` diff was never located in this repo — cannot confirm this fix matches the exact incident numbers, only that it eliminates the mechanism described in the code comments and produces an exact `0.00` delta on a synthetic 5,000-account fixture.
- No test in the suite currently exercises an exact rounding midpoint (x.xx5) to confirm `AwayFromZero` is wired correctly versus merely "not yet contradicted." Recommended as the next test to add before treating rounding-mode coverage as complete.
- Stale comments in `PostingService.cs` describing the old buggy behavior were left in place (see [06-review.md](06-review.md), item 1) — worth a follow-up documentation pass.

## Related reports

- [../reports/recon-fail-2026-08-16-investigation.md](recon-fail-2026-08-16-investigation.md) — UNDERSTAND / INSPECT / PLAN
- [04-implement.md](04-implement.md)
- [05-validate.md](05-validate.md)
- [06-review.md](06-review.md)
