# Interest Accrual Lab — Codex instructions

## Scope and working agreement

These instructions apply to this project and its descendants. Follow the parent
workspace `AGENTS.md` and read `../docs/principal-architect-workflow.md` before
substantial work. The user retains architectural and business-policy decision
authority. Continue authorized implementation, validation, and reporting without
routine approval pauses; preserve unrelated work.

This is a .NET banking training lab for daily interest accrual, ledger batch
posting, reconciliation, and a thin HTTP API. Preserve the lab's requested
diagnostic or simulation behavior. Do not add production infrastructure without
a concrete requirement.

## Inspect before changing

- State the intended observable outcome, material assumptions, and completion
  checks before substantial implementation.
- Inspect repository status, affected callers, implementation, tests, and project
  files. Treat current code as evidence of behavior, not historical reports.
- `README.md` describes the original seeded defect. The current accrual and
  posting implementations already use decimal arithmetic; do not assume the
  original failing state still exists.
- Consult `CLAUDE.md` for background and `reports/`, `CODE_REVIEW.md`,
  `AI_CHANGE_LOG.md`, and `PROJECT_EXECUTION_STEPS.md` when task history matters.
  Recheck historical claims against current files. In particular, `CLAUDE.md`
  says Ledger does not reference Interest, but its `.csproj` currently does.
- Before adding a public method or API, read
  `.claude/skills/new-api-conventions/SKILL.md` for the detailed model, validation,
  and test conventions. Read `WORKFLOW.md` when working on the existing workflow.

## Architecture and contracts

- `src/Banking.Interest`: account models and `AccrualService.ComputeDailyAccrual`.
- `src/Banking.Ledger`: posting models and `PostingService.PostNightlyBatch`;
  its project references Banking.Interest.
- `src/Banking.Reconciliation`: `ReconciliationService.CheckBatch`; references
  Banking.Ledger and accepts an explicit caller-supplied tolerance.
- `src/Banking.Api`: references Banking.Ledger and exposes
  `POST /api/postings/nightly-batch`. It accepts precomputed `AccountAccrual`
  values and calls PostingService; it does not compute interest itself.
- `tests/`: one matching xUnit test project for each component.

Keep dependencies one-way and the HTTP layer thin. Preserve existing public
contracts unless the requested change includes changing them.

## Monetary and validation rules

- Use `decimal` throughout monetary calculations, including accumulators. Do
  not round-trip monetary values through `double` or `float`.
- Preserve the current daily accrual formula and its single final rounding point:
  `Math.Round(value, 2, MidpointRounding.AwayFromZero)`.
- Posting preserves supplied amounts. Batch totals are decimal sums of posted
  entries, with no additional rounding or independent interest calculation.
- Rounding policy, tolerance defaults, tolerance-boundary semantics, and
  historical backfills are business decisions. Preserve current behavior unless
  a change is authorized; do not describe existing behavior as compliance approval.
- Follow existing guard conventions: null parameters use ArgumentNullException;
  out-of-range values use ArgumentOutOfRangeException; per-entry posting
  validation such as a missing account ID uses InvalidOperationException.
  The HTTP endpoint currently maps that posting exception to HTTP 400.

## Environment and verification

Run commands from this directory. Check `dotnet --info` and
`dotnet --list-runtimes` early when build or execution is needed. Interest,
Ledger, Reconciliation, and their tests target net6.0; Api and Api.Tests target
net10.0. Verify the current `.csproj` files before changing framework assumptions.
Do not retarget projects or add runtime roll-forward just to conceal a missing
runtime. Report a test host that cannot launch as unverified due to an environment
gap, never as a passing test.

```sh
dotnet build InterestAccrualLab.sln
dotnet test tests/Banking.Interest.Tests/Banking.Interest.Tests.csproj
dotnet test tests/Banking.Ledger.Tests/Banking.Ledger.Tests.csproj
dotnet test tests/Banking.Reconciliation.Tests/Banking.Reconciliation.Tests.csproj
dotnet test tests/Banking.Api.Tests/Banking.Api.Tests.csproj
```

For code changes, build the solution and run affected test projects, including
downstream consumers when shared behavior changes. Use focused regression tests
for bug fixes where useful; for new public APIs, write meaningful tests before
implementation and verify both the initial failure and final result. A manual
HTTP request does not replace the API integration tests. Documentation-only
changes require checking accuracy, paths, and the diff, not running .NET tests.

For local HTTP checks:

```sh
dotnet run --project src/Banking.Api/Banking.Api.csproj --urls http://localhost:5299
```

## Tooling and completion evidence

The `.claude/settings.json` hooks and `.claude/workflows/add-new-api.js` belong to
the Claude tooling. Do not assume they execute in Codex or that a named Workflow
tool exists. Perform the required design, implementation, verification, and
self-review explicitly with available tools. Use additional agents only when
authorized; label self-review accurately.

Review the final diff against the request. Report what changed, actual checks
and their results, and any remaining gaps. Never present historical test results
as results from the current run or claim completion based only on a successful
edit or a running process. Update relevant documentation when behavior changes.
