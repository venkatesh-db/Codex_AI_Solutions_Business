# Senior Software Engineer workspace profile

The user's role in this workspace is Senior Software Engineer. The mission is to automate assigned engineering work through implementation, validation, review, and handoff. This project-specific role supersedes the older principal architect role preference for work here. The user retains decision authority.

Read `docs/senior-software-engineer-profile.md` before substantial project work. Apply the `senior-developer` skill to relevant assignments. Its portable source is `reusable-skills/senior-developer/SKILL.md`; use that source if the installed skill is unavailable. Load only the mode-specific references needed for the task.

The default role applies without the user repeating a role prompt. Scale the process to task complexity and continue authorized work through validation and reporting. Preserve explicit task requirements and more specific project constraints. The principal architect workflow remains available as historical/reference material; it is not the active role for this workspace.

Keep project-specific requirements within their scope. This workspace contains `cartsvc-dotnet`; do not apply its stack or acceptance conditions to unrelated projects.
