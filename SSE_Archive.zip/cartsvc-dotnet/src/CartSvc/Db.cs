using Npgsql;

namespace CartSvc;

public sealed class Db
{
    private readonly string connectionString;
    private readonly string schema;

    public Db(string connectionString, string schema = "cartsvc")
    {
        if (string.IsNullOrEmpty(schema) || schema.Any(c => !char.IsAsciiLetterOrDigit(c) && c != '_'))
            throw new ArgumentException("Invalid schema name", nameof(schema));
        this.schema = schema;
        this.connectionString = new NpgsqlConnectionStringBuilder(connectionString) { SearchPath = schema }.ConnectionString;
    }

    public NpgsqlConnection Open()
    {
        var connection = new NpgsqlConnection(connectionString);
        connection.Open();
        return connection;
    }

    public void Initialize()
    {
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText = $"""
            CREATE SCHEMA IF NOT EXISTS "{schema}";
            CREATE TABLE IF NOT EXISTS products (id integer NOT NULL, name text NOT NULL, price numeric(12,2) NOT NULL, stock integer NOT NULL);
            CREATE TABLE IF NOT EXISTS coupons (code text NOT NULL, percent numeric(5,2) NOT NULL, usage_limit integer NOT NULL, uses integer NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS cart_lines (cart_id uuid NOT NULL, product_id integer NOT NULL, quantity integer NOT NULL, unit_price numeric(12,2) NOT NULL);
            CREATE TABLE IF NOT EXISTS orders (id uuid NOT NULL, cart_id uuid NOT NULL, email text NOT NULL, address text NOT NULL, total numeric(12,2) NOT NULL, coupon text);
            """;
        command.ExecuteNonQuery();
    }
}
