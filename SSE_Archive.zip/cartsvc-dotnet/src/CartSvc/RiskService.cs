namespace CartSvc;

public sealed class RiskService
{
    private readonly Func<string, decimal, bool> assess;

    public RiskService(Func<string, decimal, bool>? assess = null)
    {
        this.assess = assess ?? ((email, amount) =>
            string.IsNullOrWhiteSpace(email) || amount > 100_000m);
    }

    public bool IsBlocked(string email, decimal amount) => assess(email, amount);
}
