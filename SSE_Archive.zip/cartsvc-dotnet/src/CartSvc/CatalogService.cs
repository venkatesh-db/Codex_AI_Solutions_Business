namespace CartSvc;

public sealed class CatalogService(Db db)
{
    public IReadOnlyList<string> Search(string query)
    {
        using var connection = db.Open();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT name FROM products WHERE name ILIKE @query ORDER BY name";
        command.Parameters.AddWithValue("query", $"%{query}%");
        using var reader = command.ExecuteReader();
        var names = new List<string>();
        while (reader.Read()) names.Add(reader.GetString(0));
        return names;
    }
}
