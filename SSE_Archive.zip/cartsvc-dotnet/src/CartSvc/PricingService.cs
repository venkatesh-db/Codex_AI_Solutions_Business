namespace CartSvc;

public sealed class PricingService
{
    public decimal Subtotal(IEnumerable<CartService.Line> lines) => lines.Sum(x => x.UnitPrice * x.Quantity);
    public decimal TaxOn(decimal amount) => decimal.Round(amount * 0.18m, 2, MidpointRounding.AwayFromZero);
    public decimal DiscountOn(decimal amount, decimal percent) => decimal.Round(amount * percent / 100m, 2, MidpointRounding.AwayFromZero);
    public decimal AmountDue(decimal subtotal, decimal discount, decimal tax) => subtotal - discount + tax;

    public TotalsResult Totals(IEnumerable<CartService.Line> lines, decimal couponPercent)
    {
        var subtotal = Subtotal(lines);
        var tax = TaxOn(subtotal);
        var discount = DiscountOn(subtotal, couponPercent);
        return new(subtotal, discount, tax, AmountDue(subtotal, discount, tax));
    }

    public readonly record struct TotalsResult(decimal Subtotal, decimal Discount, decimal Tax, decimal Total);
}
