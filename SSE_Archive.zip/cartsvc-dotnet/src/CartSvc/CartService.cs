namespace CartSvc;

public sealed class CartService(Db db, CouponService coupons, PricingService pricing, RiskService risk, TextWriter log)
{
    public readonly record struct Line(int ProductId, int Quantity, decimal UnitPrice);

    public void AddItem(Guid cartId, int productId, int quantity)
    {
        if (quantity <= 0) throw new ArgumentOutOfRangeException(nameof(quantity));
        using var connection = db.Open();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT price FROM products WHERE id = @id";
        command.Parameters.AddWithValue("id", productId);
        var price = command.ExecuteScalar() ?? throw new InvalidOperationException("Product not found");
        command.CommandText = "INSERT INTO cart_lines(cart_id, product_id, quantity, unit_price) VALUES (@cart, @id, @qty, @price)";
        command.Parameters.AddWithValue("cart", cartId);
        command.Parameters.AddWithValue("qty", quantity);
        command.Parameters.AddWithValue("price", (decimal)price);
        command.ExecuteNonQuery();
    }

    public Guid Checkout(Guid cartId, string email, string address, string? coupon = null)
    {
        var lines = new List<Line>();
        using (var connection = db.Open())
        using (var command = connection.CreateCommand())
        {
            command.CommandText = "SELECT product_id, SUM(quantity)::integer, unit_price FROM cart_lines WHERE cart_id = @cart GROUP BY product_id, unit_price";
            command.Parameters.AddWithValue("cart", cartId);
            using var reader = command.ExecuteReader();
            while (reader.Read()) lines.Add(new(reader.GetInt32(0), reader.GetInt32(1), reader.GetDecimal(2)));
        }
        if (lines.Count == 0) throw new InvalidOperationException("Cart is empty");
        foreach (var group in lines.GroupBy(x => x.ProductId))
        {
            using var connection = db.Open();
            using var command = connection.CreateCommand();
            command.CommandText = "SELECT stock FROM products WHERE id = @id";
            command.Parameters.AddWithValue("id", group.Key);
            if (command.ExecuteScalar() is not int stock || stock < group.Sum(x => x.Quantity))
                throw new InvalidOperationException("Insufficient stock");
        }

        var percent = coupons.Validate(coupon);
        var totals = pricing.Totals(lines, percent);
        if (risk.IsBlocked(email, totals.Total)) throw new InvalidOperationException("Order declined");

        using (var connection = db.Open())
        foreach (var line in lines)
        {
            using var command = connection.CreateCommand();
            command.CommandText = "UPDATE products SET stock = stock - @qty WHERE id = @id";
            command.Parameters.AddWithValue("qty", line.Quantity);
            command.Parameters.AddWithValue("id", line.ProductId);
            command.ExecuteNonQuery();
        }
        coupons.Redeem(coupon);
        var orderId = Guid.NewGuid();
        using (var connection = db.Open())
        using (var command = connection.CreateCommand())
        {
            command.CommandText = "INSERT INTO orders(id, cart_id, email, address, total, coupon) VALUES (@id, @cart, @email, @address, @total, @coupon); DELETE FROM cart_lines WHERE cart_id = @cart";
            command.Parameters.AddWithValue("id", orderId);
            command.Parameters.AddWithValue("cart", cartId);
            command.Parameters.AddWithValue("email", email);
            command.Parameters.AddWithValue("address", address);
            command.Parameters.AddWithValue("total", totals.Total);
            command.Parameters.AddWithValue("coupon", NpgsqlTypes.NpgsqlDbType.Text, (object?)coupon ?? DBNull.Value);
            command.ExecuteNonQuery();
        }
        log.WriteLine($"Checkout {orderId} completed for {email}, shipping to {address}");
        return orderId;
    }
}
