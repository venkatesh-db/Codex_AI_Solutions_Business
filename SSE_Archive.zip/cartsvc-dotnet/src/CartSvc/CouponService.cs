namespace CartSvc;

public sealed class CouponService(Db db)
{
    public decimal Validate(string? code)
    {
        if (string.IsNullOrWhiteSpace(code)) return 0m;
        using var connection = db.Open();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT percent, usage_limit, uses FROM coupons WHERE code = @code";
        command.Parameters.AddWithValue("code", code);
        using var reader = command.ExecuteReader();
        if (!reader.Read() || reader.GetInt32(2) >= reader.GetInt32(1))
            throw new InvalidOperationException("Coupon unavailable");
        return reader.GetDecimal(0);
    }

    public void Redeem(string? code)
    {
        if (string.IsNullOrWhiteSpace(code)) return;
        using var connection = db.Open();
        using var command = connection.CreateCommand();
        command.CommandText = "UPDATE coupons SET uses = uses + 1 WHERE code = @code";
        command.Parameters.AddWithValue("code", code);
        command.ExecuteNonQuery();
    }
}
