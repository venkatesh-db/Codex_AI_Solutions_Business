using CartSvc;

if (args.Contains("--pricing"))
{
    var pricing = new PricingService();
    var totals = pricing.Totals([new CartService.Line(1, 1, 1000m)], 20m);
    var expectedTax = pricing.TaxOn(totals.Subtotal - totals.Discount);
    Console.WriteLine(FormattableString.Invariant($"Subtotal: INR {totals.Subtotal:F2}"));
    Console.WriteLine(FormattableString.Invariant($"Discount (20%): INR {totals.Discount:F2}"));
    Console.WriteLine(FormattableString.Invariant($"Actual GST: INR {totals.Tax:F2}"));
    Console.WriteLine(FormattableString.Invariant($"GST on discounted subtotal: INR {expectedTax:F2}"));
    Console.WriteLine(FormattableString.Invariant($"Actual total: INR {totals.Total:F2}"));
    Console.WriteLine(FormattableString.Invariant($"Expected total: INR {totals.Subtotal - totals.Discount + expectedTax:F2}"));
    Console.WriteLine(FormattableString.Invariant($"Excess GST: INR {totals.Tax - expectedTax:F2}"));
    return 0;
}

var failures = 0;
foreach (var scenario in new[] { "stock", "coupon" })
{
    var schema = "fixture_" + Guid.NewGuid().ToString("N");
    var db = new Db(Environment.GetEnvironmentVariable("CARTSVC_CONNECTION_STRING")
        ?? "Host=localhost;Database=cartsvc_lab;Username=postgres", schema);
    db.Initialize();
    try
    {
        var initialStock = scenario == "stock" ? 3 : 10;
        Execute($"INSERT INTO products VALUES (1, 'Coffee', 100, {initialStock}); INSERT INTO coupons VALUES ('ONE', 20, 1, 0)");
        using var gate = new Barrier(5);
        var risk = new RiskService((_, _) =>
        {
            if (!gate.SignalAndWait(TimeSpan.FromSeconds(30)))
                throw new TimeoutException("Risk assessment coordination timed out");
            return false;
        });
        var service = new CartService(db, new(db), new(), risk, TextWriter.Null);
        var carts = Enumerable.Range(0, 5).Select(_ => Guid.NewGuid()).ToArray();
        foreach (var id in carts) service.AddItem(id, 1, 1);
        var jobs = carts.Select(id => Task.Factory.StartNew(
            () => service.Checkout(id, "buyer@example.test", "12 Market Road", scenario == "coupon" ? "ONE" : null),
            CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default)).ToArray();
        await Task.WhenAll(jobs);
        var orders = Convert.ToInt32(Execute("SELECT count(*) FROM orders"));
        var stock = Convert.ToInt32(Execute("SELECT stock FROM products WHERE id = 1"));
        var uses = Convert.ToInt32(Execute("SELECT uses FROM coupons WHERE code = 'ONE'"));
        var passed = scenario == "stock" ? stock >= 0 && orders <= initialStock : uses <= 1;
        if (!passed) failures++;
        Console.WriteLine(scenario == "stock"
            ? $"{(passed ? "PASS" : "FAIL")} stock: initial={initialStock}, orders={orders}, remaining={stock}, oversold={Math.Max(0, orders - initialStock)}"
            : $"{(passed ? "PASS" : "FAIL")} coupon: limit=1, orders={orders}, redeemed={uses}, excess={Math.Max(0, uses - 1)}");
    }
    catch (Exception ex)
    {
        Console.Error.WriteLine($"ERROR {scenario}: {ex.Message}");
        return 2;
    }
    finally
    {
        Execute($"DROP SCHEMA {schema} CASCADE");
    }
    object? Execute(string sql)
    {
        using var c = db.Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = sql;
        return cmd.ExecuteScalar();
    }
}
Console.WriteLine($"Scenarios failed: {failures}/2");
return failures == 0 ? 0 : 1;
