using CartSvc;
using Xunit;

[assembly: CollectionBehavior(DisableTestParallelization = true)]

namespace CartSvc.Tests;

public sealed class ServiceTests : IDisposable
{
    private readonly Db db;
    private readonly string schema = "test_" + Guid.NewGuid().ToString("N");
    private readonly PricingService pricing = new();
    private readonly CartService cart;

    public ServiceTests()
    {
        db = new Db(Environment.GetEnvironmentVariable("CARTSVC_CONNECTION_STRING")
            ?? "Host=localhost;Database=cartsvc_lab;Username=postgres", schema);
        db.Initialize();
        Sql("INSERT INTO products VALUES (1, 'Coffee', 100, 10), (2, 'Tea', 200, 0); INSERT INTO coupons VALUES ('SAVE20', 20, 5, 0), ('USED', 10, 1, 1)");
        cart = new(db, new(db), pricing, new(), TextWriter.Null);
    }

    private object? Sql(string sql)
    {
        using var c = db.Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = sql;
        return cmd.ExecuteScalar();
    }

    [Fact] public void SubtotalUsesQuantity() => Assert.Equal(300m, pricing.Subtotal([new(1, 3, 100m)]));
    [Fact] public void EmptySubtotalIsZero() => Assert.Equal(0m, pricing.Subtotal([]));
    [Fact] public void TaxUsesEighteenPercent() => Assert.Equal(180m, pricing.TaxOn(1000m));
    [Fact] public void TaxRoundsToPaise() => Assert.Equal(1.81m, pricing.TaxOn(10.03m));
    [Fact] public void DiscountUsesPercentage() => Assert.Equal(200m, pricing.DiscountOn(1000m, 20m));
    [Fact] public void AmountDueCombinesAmounts() => Assert.Equal(944m, pricing.AmountDue(1000m, 200m, 144m));
    [Fact] public void TotalsWithoutCouponReportsTax() => Assert.Equal(18m, pricing.Totals([new(1, 1, 100m)], 0m).Tax);
    [Fact] public void RiskAllowsOrdinaryOrder() => Assert.False(new RiskService().IsBlocked("buyer@example.test", 500m));
    [Fact] public void RiskBlocksLargeOrder() => Assert.True(new RiskService().IsBlocked("buyer@example.test", 100001m));
    [Fact] public void RiskBlocksMissingEmail() => Assert.True(new RiskService().IsBlocked("", 100m));
    [Fact] public void AddItemStoresQuantity()
    {
        cart.AddItem(Guid.NewGuid(), 1, 2);
        Assert.Equal(2, (int)Sql("SELECT quantity FROM cart_lines")!);
    }
    [Fact] public void AddItemRejectsZero() => Assert.Throws<ArgumentOutOfRangeException>(() => cart.AddItem(Guid.NewGuid(), 1, 0));
    [Fact] public void AddItemRejectsUnknownProduct() => Assert.Throws<InvalidOperationException>(() => cart.AddItem(Guid.NewGuid(), 99, 1));
    [Fact] public void EmptyCheckoutIsRejected() => Assert.Throws<InvalidOperationException>(() => cart.Checkout(Guid.NewGuid(), "buyer@example.test", "12 Market Road"));
    [Fact] public void CheckoutRejectsUnavailableStock()
    {
        var id = Guid.NewGuid();
        cart.AddItem(id, 2, 1);
        Assert.Throws<InvalidOperationException>(() => cart.Checkout(id, "buyer@example.test", "12 Market Road"));
    }
    [Fact] public void CheckoutWritesOrderAndClearsCart()
    {
        var id = Guid.NewGuid();
        cart.AddItem(id, 1, 1);
        Assert.NotEqual(Guid.Empty, cart.Checkout(id, "buyer@example.test", "12 Market Road", "SAVE20"));
        Assert.Equal(1L, (long)Sql("SELECT count(*) FROM orders")!);
        Assert.Equal(0L, (long)Sql("SELECT count(*) FROM cart_lines")!);
        Assert.Equal(9, (int)Sql("SELECT stock FROM products WHERE id = 1")!);
        Assert.Equal(1, (int)Sql("SELECT uses FROM coupons WHERE code = 'SAVE20'")!);
    }
    [Fact] public void CouponReturnsPercentage() => Assert.Equal(20m, new CouponService(db).Validate("SAVE20"));
    [Fact] public void ExhaustedCouponIsRejected() => Assert.Throws<InvalidOperationException>(() => new CouponService(db).Validate("USED"));
    [Fact] public void MissingCouponMeansNoDiscount() => Assert.Equal(0m, new CouponService(db).Validate(null));
    [Fact]
    public void CatalogSearchTreatsInputAsText()
    {
        var catalog = new CatalogService(db);

        Assert.Equal(new[] { "Coffee" }, catalog.Search("COF"));
        Assert.Empty(catalog.Search("' OR 1=1 --"));
        Assert.Empty(catalog.Search("'"));
    }

    public void Dispose() => Sql($"DROP SCHEMA {schema} CASCADE");
}
