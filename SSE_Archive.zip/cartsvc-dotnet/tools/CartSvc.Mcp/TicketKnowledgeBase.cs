using System.Text.RegularExpressions;

namespace CartSvc.Mcp;

public sealed partial class TicketKnowledgeBase
{
    private const string KnowledgeBaseEnvironmentVariable = "CARTSVC_TICKET_KB";
    private readonly string path;

    public TicketKnowledgeBase()
    {
        path = Environment.GetEnvironmentVariable(KnowledgeBaseEnvironmentVariable)
            ?? Path.Combine(AppContext.BaseDirectory, "ticket-knowledge-base.md");
    }

    public string GetTicket(string ticketId)
    {
        var normalizedId = ticketId?.Trim().ToUpperInvariant()
            ?? throw new ArgumentNullException(nameof(ticketId));

        if (!TicketIdPattern().IsMatch(normalizedId))
            throw new ArgumentException("Ticket ID must use CART-NNN format.", nameof(ticketId));

        if (!File.Exists(path))
            throw new FileNotFoundException(
                $"CartSvc ticket knowledge base was not found. Set {KnowledgeBaseEnvironmentVariable} to its absolute path.",
                path);

        var headingPrefix = $"## {normalizedId} ";
        var lines = File.ReadAllLines(path);
        var start = Array.FindIndex(lines, line => line.StartsWith(headingPrefix, StringComparison.Ordinal));
        if (start < 0)
            throw new KeyNotFoundException($"Ticket {normalizedId} was not found.");

        var end = Array.FindIndex(lines, start + 1, line => line.StartsWith("## ", StringComparison.Ordinal));
        if (end < 0) end = lines.Length;

        return string.Join(Environment.NewLine, lines[start..end]).TrimEnd();
    }

    [GeneratedRegex("^CART-[0-9]{3}$", RegexOptions.CultureInvariant)]
    private static partial Regex TicketIdPattern();
}
