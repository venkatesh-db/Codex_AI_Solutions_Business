using System.ComponentModel;
using ModelContextProtocol.Server;

namespace CartSvc.Mcp;

[McpServerToolType]
public sealed class CartSvcTools(TicketKnowledgeBase knowledgeBase)
{
    [McpServerTool(Name = "get_cartsvc_ticket"),
     Description("Returns one CartSvc defect ticket from the local ticket knowledge base. Read-only.")]
    public string GetTicket(
        [Description("Ticket identifier in CART-NNN format, for example CART-001.")]
        string ticketId) => knowledgeBase.GetTicket(ticketId);
}
