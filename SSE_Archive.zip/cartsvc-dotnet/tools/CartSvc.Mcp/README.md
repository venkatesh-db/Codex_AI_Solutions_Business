# CartSvc local MCP server

This local stdio server exposes exactly one read-only tool:

- `get_cartsvc_ticket(ticketId)` returns one ticket section from `docs/ticket-knowledge-base.md`.

The tool accepts identifiers in `CART-NNN` format. It cannot modify tickets, application data, Git state, or PostgreSQL.

## Run locally

The repository requires the .NET 8 SDK:

```sh
dotnet run --project tools/CartSvc.Mcp
```

The knowledge-base Markdown file is copied into the build output. To read the live repository file instead, set an absolute path:

```sh
export CARTSVC_TICKET_KB="$(pwd)/docs/ticket-knowledge-base.md"
dotnet run --project tools/CartSvc.Mcp
```

## Example client configuration

Replace `/absolute/path/to/cartsvc-dotnet` with the local repository path:

```json
{
  "mcpServers": {
    "cartsvc": {
      "command": "dotnet",
      "args": [
        "run",
        "--project",
        "/absolute/path/to/cartsvc-dotnet/tools/CartSvc.Mcp"
      ],
      "env": {
        "CARTSVC_TICKET_KB": "/absolute/path/to/cartsvc-dotnet/docs/ticket-knowledge-base.md"
      }
    }
  }
}
```

Logs go to standard error because standard output is reserved for MCP protocol messages.
