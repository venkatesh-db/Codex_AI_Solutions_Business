# cartsvc-dotnet

A small storefront cart and checkout lab using .NET 8, PostgreSQL, and plain Npgsql commands. The six service classes live in `src/CartSvc`. Tests use xUnit; the test SDK and runner are test-only dependencies.

Install the .NET 8 SDK and PostgreSQL, then create a dedicated database:

```sh
createdb cartsvc_lab
export CARTSVC_CONNECTION_STRING='Host=localhost;Database=cartsvc_lab;Username=your_user'
dotnet restore
dotnet test
```

The database user needs permission to create and drop schemas. Tests and fixture scenarios each create a separate schema and remove it afterward. The service accepts its connection string and schema through `Db` and creates tables through `Initialize()`.

The console fixture is separate from the solution and test discovery:

```sh
dotnet run --project fixtures/ConcurrentCheckoutFixture
dotnet run --project fixtures/ConcurrentCheckoutFixture -- --pricing
```

A local read-only MCP server with one ticket lookup tool is documented in
[`tools/CartSvc.Mcp`](tools/CartSvc.Mcp/README.md).

The concurrent fixture runs five distinct carts for each scenario. The stock scenario starts with three units; the coupon scenario starts with ten units and a single-use coupon. It coordinates risk assessments to overlap requests, checks stored outcomes, and exits 1 for failed business invariants or 2 for execution errors. The pricing mode prints a worked INR example.

Checkout checks each product, validates the coupon, computes charges, asks the risk assessor, updates stock, redeems the coupon, and saves an order. Risk assessment accepts a callback for integration with another scorer. Monetary helpers round to two decimal places. All sample customer details are fictional.
