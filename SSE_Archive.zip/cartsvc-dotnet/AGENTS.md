# CartSvc project working agreement

Follow the workspace Senior Software Engineer profile and the user's task-specific acceptance criteria. Keep the repository small and focused on its stated teaching purpose. Behavioral changes must follow the current task scope.

- Use C# and .NET 8, PostgreSQL through plain Npgsql connections and commands, and xUnit. Keep the SQL visible and avoid an ORM or additional application dependencies.
- Preserve the six service responsibilities and the distinction between the test project and the standalone console fixture.
- Read `README.md` for database setup and execution commands. Use the configured `CARTSVC_CONNECTION_STRING`; never commit credentials.
- Use isolated schemas for test and fixture data. Do not reset unrelated databases or schemas.
- Run `dotnet test` for affected service behavior. Run the standalone fixture when the task requires its scenarios; report its business-check failures separately from compilation or execution errors.
- Keep customer examples fictional. Preserve explicit constraints on test count, test execution, schema, and output when they remain part of the task's acceptance criteria.
