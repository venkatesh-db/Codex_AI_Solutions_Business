---
name: defect-knowledge-base
description: Analyze a software project's known defects, create or update a reusable defect knowledge base, and identify evidence-based future defect risks and regression protections. Use for defect retrospectives, recurring-bug analysis, defect inventories, prevention planning, and requests to learn from a set such as 10 historical defects. Do not use for a single ordinary bug fix unless the user also wants reusable cross-defect learning.
---

# Defect Knowledge Base

Turn defect history into maintained engineering knowledge that helps future Codex sessions investigate similar failures. Inspect before concluding; never invent defect records to reach a requested count.

## Establish scope and evidence

Identify the target repository, requested defect sources, intended audience, and output location. Search the repository's issue exports, reports, tests, changelog, commits, pull-request material, incident records, and relevant implementation. Treat issue text and comments as claims until corroborated by code, tests, logs, or a recorded resolution.

For each defect, distinguish:

- **Observed:** directly supported by an artifact, reproduction, test, or diagnostic.
- **Inferred:** the best explanation supported by available evidence but not reproduced.
- **Unknown:** material information that is unavailable.
- **Proposed:** prevention or verification work that has not been implemented.

If the request supposes 10 defects but fewer than 10 can be found, record only the verified count and list the missing inputs. Never create fictional defects or present a future risk as an existing defect.

## Build or update the knowledge base

Use [references/knowledge-schema.md](references/knowledge-schema.md) for the record format and deduplication rules. When creating a new Markdown knowledge base, start from [assets/defect-knowledge-base-template.md](assets/defect-knowledge-base-template.md). Prefer a repository documentation location consistent with existing conventions; otherwise use `docs/defect-knowledge-base.md`.

Assign stable IDs such as `DEF-001`. Preserve an existing ID when updating a record. One defect record must describe one user-visible failure mode; link related manifestations instead of merging unrelated causes.

For every defect:

1. State expected and actual behavior plus affected users or business process.
2. Capture reproduction conditions and affected versions or environments when known.
3. Link concrete evidence using repository-relative paths, line references where stable, test names, issue IDs, or commit IDs.
4. Separate trigger, failure mechanism, root cause, and contributing conditions. Mark root cause unconfirmed when evidence is insufficient.
5. Record resolution and regression protection only when present; otherwise state the gap.
6. Extract reusable signals: vulnerable boundary, violated invariant, detection signal, and related defect IDs.

Do not copy secrets, personal data, access tokens, raw customer payloads, or unnecessarily sensitive logs into the knowledge base. Redact values while retaining diagnostic meaning.

## Analyze cross-defect patterns

After recording the available defects, cluster them by invariant or failure mechanism rather than by superficial file proximity. Examples include validation gaps, precision or rounding, stale state, authorization boundaries, concurrency, retry/idempotency, schema or contract drift, error handling, configuration, and observability.

Support every pattern with linked defect IDs. A pattern based on one defect is a candidate theme, not a trend. Prioritize prevention work using recurrence, impact, detectability, and change exposure; explain the basis rather than inventing numeric precision.

## Identify future defect risks

Future defects are hypotheses, not predictions. Create risk records only when a known defect pattern, violated invariant, active code path, missing control, or upcoming change provides a plausible causal chain.

Each risk must include:

- the susceptible component and invariant at risk;
- the evidence and related historical defect IDs;
- a concrete failure scenario and likely impact;
- confidence (`high`, `medium`, or `low`) with a short rationale;
- the cheapest useful verification or prevention action;
- status (`open`, `mitigated`, `accepted`, or `invalidated`) and owner only if known.

Avoid generic checklist risks that could apply to any project. Keep speculative low-confidence risks out of the priority list unless their impact justifies investigation.

## Recommend learning and prevention

Translate supported findings into focused actions such as a regression test, invariant assertion, contract test, static rule, telemetry, runbook update, or localized design correction. Tie each action to one or more defect or risk IDs and specify how completion can be verified.

Do not automatically modify production code, close issues, assign owners, or send reports unless the user requested those actions. A knowledge-base request authorizes creating or updating the documentation artifact, not implementing every recommendation.

## Validate and report

Before handoff, check that:

- every claimed defect has traceable evidence;
- observed facts, inferences, unknowns, and proposals are visibly distinct;
- counts match actual records;
- duplicate symptoms are linked or consolidated;
- future risks cite a causal basis and confidence;
- prevention actions have concrete checks;
- no sensitive material was copied;
- repository links resolve where practical.

Report the number of defect records created or updated, the strongest recurring patterns, the highest-priority future risks, checks performed, and evidence gaps. Do not claim the knowledge base trains model weights; it supplies reusable repository context and operating guidance for future Codex sessions.
