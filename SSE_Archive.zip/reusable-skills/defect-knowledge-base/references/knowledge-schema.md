# Defect knowledge schema

Use this schema when creating or updating a defect knowledge base. Omit empty optional fields only when their absence is obvious; otherwise write `Unknown` so missing evidence is visible.

## Repository summary

- Scope and revision or date inspected
- Evidence sources inspected
- Confirmed defect count
- Unresolved evidence gaps
- Business invariants learned from the defect set

## Defect record

### DEF-NNN — Concise failure mode

| Field | Content |
| --- | --- |
| Status | Open, fixed, mitigated, cannot reproduce, or unknown |
| Evidence level | Confirmed, inferred, or reported-only |
| First/last known version | Version, date, commit, or unknown |
| Affected component | Owned subsystem or boundary |
| User/business impact | Concrete consequence and affected users |
| Expected behavior | Observable contract |
| Actual behavior | Observable failure |
| Trigger | Input, state, timing, environment, or action |
| Failure mechanism | How the system produces the failure |
| Root cause | Supported cause, or explicitly unconfirmed |
| Contributing conditions | Factors that enabled or amplified it |
| Violated invariant | Rule that should always hold |
| Detection | Test, alert, report, log, or user discovery |
| Resolution | Implemented correction and revision, or gap |
| Regression protection | Existing test/control and its location, or gap |
| Related records | Defect and risk IDs |

Follow the table with:

- **Evidence:** repository-relative links, issue/commit IDs, commands, and concise observed results.
- **Unknowns:** unanswered questions that affect confidence or prevention.
- **Learning:** the reusable diagnostic or design lesson, stated narrowly enough to remain valid.

## Pattern record

### PAT-NNN — Pattern name

- Supporting defects: at least one `DEF-NNN`; call it a candidate theme unless multiple independent defects support recurrence.
- Shared invariant or mechanism: what actually connects the defects.
- Exposure: components or future changes likely to encounter the same condition.
- Existing controls and gaps: tests, validation, monitoring, review checks, or missing protections.
- Priority rationale: recurrence, impact, detectability, and change exposure described qualitatively.

## Future-risk record

### RISK-NNN — Plausible future failure

| Field | Content |
| --- | --- |
| Status | Open, mitigated, accepted, or invalidated |
| Confidence | High, medium, or low, with rationale |
| Susceptible component | Concrete code, boundary, or workflow |
| Invariant at risk | Rule that may be violated |
| Historical basis | Related `DEF-NNN` and `PAT-NNN` records |
| Scenario | Trigger-to-impact causal chain |
| Likely impact | User, financial, security, operational, or maintenance effect |
| Verification | Cheapest focused check that can confirm or reduce the risk |
| Prevention | Proposed control or correction |
| Owner | Named owner only when supplied; otherwise unassigned |

## Action record

Use `ACT-NNN` for recommended work. Include related defect/risk IDs, expected behavior, proposed change, completion check, priority rationale, and implementation status. Never label a proposal as implemented.

## Deduplication and updates

- Match records using failure mode, trigger, mechanism, and root cause—not title alone.
- One root cause may have several manifestations; retain separate defect records when user impact or regression checks differ, and link them.
- Preserve stable IDs and append new evidence or status changes rather than rewriting history invisibly.
- Add a dated change note when a conclusion, confidence rating, or status materially changes.
- Revalidate conclusions affected by code changes; stale evidence must retain its original revision/date.
