# Defect knowledge base

> This document separates confirmed history from forward-looking risk hypotheses. Future risks are not known defects.

## Scope and evidence

- Repository/revision:
- Analysis date:
- Sources inspected:
- Confirmed defects documented:
- Evidence gaps:

## Business and engineering invariants

| Invariant | Evidence | Affected components | Existing protection | Gap |
| --- | --- | --- | --- | --- |

## Defect index

| ID | Failure mode | Status | Evidence level | Impact | Component | Related pattern |
| --- | --- | --- | --- | --- | --- | --- |

## Defect records

<!-- Repeat the defect record from references/knowledge-schema.md for each evidenced defect. If 10 defects are supplied or discovered, create DEF-001 through DEF-010. Do not create placeholders or fictional records merely to reach 10. -->

## Cross-defect patterns

| ID | Pattern | Supporting defects | Existing controls | Priority rationale |
| --- | --- | --- | --- | --- |

## Future defect risks

| ID | Scenario | Historical basis | Confidence | Likely impact | Verification | Status |
| --- | --- | --- | --- | --- | --- | --- |

## Prevention backlog

| ID | Related defects/risks | Proposed action | Completion check | Priority | Status |
| --- | --- | --- | --- | --- | --- |

## Change log

| Date | Revision | Records changed | Evidence and rationale |
| --- | --- | --- | --- |
