# Lab throughput contract

This contract applies to `ThroughputCalculator`. Wiring a completion or availability source into an API is intentionally out of scope because RxFlow currently has neither a completed-at field nor a lab-availability source.

## Selected contract

- **Throughput** is the number of unique completed job IDs in the reporting window divided by the lab's online duration in hours. The rate is rounded half-up to six decimal places.
- **Offline** means covered by an explicit availability interval supplied by the caller. Missing jobs or telemetry do not imply offline status.
- The **reporting window** and all completion/offline intervals use Instants and half-open `[from, to)` semantics. The window must have positive duration.
- A **gap** is the portion of an explicit offline interval overlapping the reporting window. Overlapping, adjacent and duplicate gaps are merged before their duration is deducted. Portions outside the window are clipped.
- A job ID is counted once, including when completion events are replayed. Events at `from` count; events at `to` do not. Late events affect a recomputed report only when their completion time is inside the window.
- A lab offline for the whole window has zero online duration and an undefined (`Optional.empty`) rate. Zero-duration offline intervals are invalid.
- Instants make elapsed-time/DST behavior unambiguous. Calendar-day grouping and stale/missing availability policy remain the responsibility of a future data-source adapter.

## Alternatives considered

For 90 unique completions in `08:00–12:00` with an explicit `09:00–10:00` gap:

1. Wall-clock throughput is `90 / 4 = 22.5 jobs/hour`. This measures output against scheduled elapsed time but depresses a lab's rate during known outages.
2. Online-time throughput is `90 / 3 = 30 jobs/online-hour`. This measures production while the lab was available and is the selected interpretation for the reported offline-day defect.

The repository had no prior product definition choosing between these alternatives. The selected interpretation is therefore an explicit implementation assumption requiring product approval before an API or persisted report contract is introduced.
