# RxFlow

Training service for prescription lens ordering and lab routing.

## Modules

- `orders` accepts and tracks orders
- `prescription` checks manufacturing limits
- `pricing` calculates quoted prices
- `routing` chooses labs and maintains capacity state
- `fulfillment` schedules lab work and publishes lifecycle events
- `reporting` supports operations exports
- `catalogue` is retained for the frame catalogue migration

## Run

```bash
docker compose up --build
```

Submit a synthetic order with `scripts/submit-order.sh`. API requests use `Authorization: Bearer training-token`.

## Engineering commands

```bash
./mvnw test
./mvnw verify
./mvnw spotless:check
./mvnw spotbugs:check pmd:check
./mvnw dependency-check:check
```

The local services are PostgreSQL on 5432, Redis on 6379, Redpanda on 9092, and RxFlow on 8080.
