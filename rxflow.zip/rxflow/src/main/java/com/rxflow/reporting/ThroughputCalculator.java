package com.rxflow.reporting;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.springframework.stereotype.Service;

@Service
public class ThroughputCalculator {
    private static final BigDecimal NANOS_PER_HOUR = BigDecimal.valueOf(3_600_000_000_000L);
    private static final int RATE_SCALE = 6;

    public ThroughputReport calculate(
            Instant from,
            Instant to,
            List<Completion> completions,
            List<OfflineInterval> offlineIntervals) {
        Objects.requireNonNull(from, "from");
        Objects.requireNonNull(to, "to");
        Objects.requireNonNull(completions, "completions");
        Objects.requireNonNull(offlineIntervals, "offlineIntervals");
        if (!from.isBefore(to)) {
            throw new IllegalArgumentException("reporting window must have positive duration");
        }

        Set<String> completedJobIds = new HashSet<>();
        for (Completion completion : completions) {
            Objects.requireNonNull(completion, "completions must not contain null");
            if (!completion.completedAt().isBefore(from) && completion.completedAt().isBefore(to)) {
                completedJobIds.add(completion.jobId());
            }
        }

        Duration offlineDuration = mergedOfflineDuration(from, to, offlineIntervals);
        Duration onlineDuration = Duration.between(from, to).minus(offlineDuration);
        Optional<BigDecimal> rate = onlineDuration.isZero()
                ? Optional.empty()
                : Optional.of(BigDecimal.valueOf(completedJobIds.size())
                        .multiply(NANOS_PER_HOUR)
                        .divide(BigDecimal.valueOf(onlineDuration.toNanos()), RATE_SCALE, RoundingMode.HALF_UP));
        return new ThroughputReport(from, to, completedJobIds.size(), onlineDuration, rate);
    }

    private Duration mergedOfflineDuration(
            Instant windowFrom, Instant windowTo, List<OfflineInterval> offlineIntervals) {
        List<OfflineInterval> clipped = new ArrayList<>();
        for (OfflineInterval interval : offlineIntervals) {
            Objects.requireNonNull(interval, "offlineIntervals must not contain null");
            Instant from = interval.from().isBefore(windowFrom) ? windowFrom : interval.from();
            Instant to = interval.to().isAfter(windowTo) ? windowTo : interval.to();
            if (from.isBefore(to)) {
                clipped.add(new OfflineInterval(from, to));
            }
        }
        clipped.sort(Comparator.comparing(OfflineInterval::from).thenComparing(OfflineInterval::to));

        Duration total = Duration.ZERO;
        Instant mergedFrom = null;
        Instant mergedTo = null;
        for (OfflineInterval interval : clipped) {
            if (mergedFrom == null) {
                mergedFrom = interval.from();
                mergedTo = interval.to();
            } else if (!interval.from().isAfter(mergedTo)) {
                if (interval.to().isAfter(mergedTo)) {
                    mergedTo = interval.to();
                }
            } else {
                total = total.plus(Duration.between(mergedFrom, mergedTo));
                mergedFrom = interval.from();
                mergedTo = interval.to();
            }
        }
        return mergedFrom == null ? total : total.plus(Duration.between(mergedFrom, mergedTo));
    }
}
