package com.rxflow.reporting;

import java.time.Instant;
import java.util.Objects;

/** A synthetic-safe reference to a uniquely identifiable completed lab job. */
public record Completion(String jobId, Instant completedAt) {
    public Completion {
        Objects.requireNonNull(jobId, "jobId");
        Objects.requireNonNull(completedAt, "completedAt");
        if (jobId.isBlank()) {
            throw new IllegalArgumentException("jobId must not be blank");
        }
    }
}
