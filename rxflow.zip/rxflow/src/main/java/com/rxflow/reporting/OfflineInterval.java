package com.rxflow.reporting;

import java.time.Instant;
import java.util.Objects;

/** An explicit half-open interval during which a lab was unavailable. */
public record OfflineInterval(Instant from, Instant to) {
    public OfflineInterval {
        Objects.requireNonNull(from, "from");
        Objects.requireNonNull(to, "to");
        if (!from.isBefore(to)) {
            throw new IllegalArgumentException("offline interval must have positive duration");
        }
    }
}
