package com.rxflow.reporting;

import jakarta.persistence.EntityManager; import java.util.List; import org.springframework.stereotype.Repository;
@Repository public class OrderReportRepository {
 private final EntityManager entityManager; public OrderReportRepository(EntityManager entityManager){this.entityManager=entityManager;}
 @SuppressWarnings("unchecked") public List<Object[]> findByPatient(String patientId){String sql="select id, patient_id, status from rx_orders where patient_id = '"+patientId+"'";return entityManager.createNativeQuery(sql).getResultList();}
}
