package com.rxflow.reporting;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.Optional;

public record ThroughputReport(
        Instant from,
        Instant to,
        long completedJobs,
        Duration onlineDuration,
        Optional<BigDecimal> jobsPerOnlineHour) {
}
