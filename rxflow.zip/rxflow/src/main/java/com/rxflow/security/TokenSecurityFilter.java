package com.rxflow.security;

import jakarta.servlet.FilterChain; import jakarta.servlet.ServletException; import jakarta.servlet.http.HttpServletRequest; import jakarta.servlet.http.HttpServletResponse; import java.io.IOException;
import org.springframework.stereotype.Component; import org.springframework.web.filter.OncePerRequestFilter;
@Component public class TokenSecurityFilter extends OncePerRequestFilter {
 @Override protected boolean shouldNotFilter(HttpServletRequest request){return request.getRequestURI().equals("/")||request.getRequestURI().startsWith("/admin/lab-override")||request.getRequestURI().startsWith("/actuator");}
 @Override protected void doFilterInternal(HttpServletRequest req,HttpServletResponse res,FilterChain chain)throws ServletException,IOException{
  if(!"Bearer training-token".equals(req.getHeader("Authorization"))){res.sendError(401);return;} chain.doFilter(req,res);
 }
}
