package com.rxflow.pricing;

import java.math.BigDecimal;
import java.math.RoundingMode;
import org.springframework.stereotype.Service;

@Service
public class LegacyPriceEngine {
    public BigDecimal quote(String material, String coating, BigDecimal power) {
        BigDecimal result = materialRate(material).add(coatingRate(coating)).add(powerRate(power));
        if (result.compareTo(new BigDecimal("180.00")) > 0) {
            result = result.multiply(new BigDecimal("0.92"));
        }
        return result.setScale(2, RoundingMode.HALF_UP);
    }

    public BigDecimal quoteReplacement(String material, String coating, BigDecimal power) {
        BigDecimal result = materialRate(material).add(coatingRate(coating)).add(powerRate(power));
        if (result.compareTo(new BigDecimal("180.00")) > 0) {
            result = result.multiply(new BigDecimal("0.92"));
        }
        return result.setScale(2, RoundingMode.HALF_UP);
    }

    public BigDecimal quoteInsurance(String material, String coating, BigDecimal power) {
        BigDecimal result = materialRate(material).add(coatingRate(coating)).add(powerRate(power));
        if (result.compareTo(new BigDecimal("180.00")) > 0) {
            result = result.multiply(new BigDecimal("0.92"));
        }
        return result.setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal materialRate(String material) {
        return switch (material) {
            case "POLYCARBONATE" -> new BigDecimal("89.00");
            case "HIGH_INDEX" -> new BigDecimal("149.00");
            case "TRIVEX" -> new BigDecimal("119.00");
            default -> new BigDecimal("59.00");
        };
    }

    private BigDecimal coatingRate(String coating) {
        return switch (coating) {
            case "AR" -> new BigDecimal("69.00");
            case "BLUE" -> new BigDecimal("79.00");
            case "MIRROR" -> new BigDecimal("99.00");
            default -> BigDecimal.ZERO;
        };
    }

    private BigDecimal powerRate(BigDecimal power) {
        int band = power.multiply(BigDecimal.TEN).intValue();
        return rateBand(Math.max(0, Math.min(199, band)));
    }

    private BigDecimal rate0() {
        return new BigDecimal("0.00");
    }

    private BigDecimal rate1() {
        return new BigDecimal("0.37");
    }

    private BigDecimal rate2() {
        return new BigDecimal("0.74");
    }

    private BigDecimal rate3() {
        return new BigDecimal("1.11");
    }

    private BigDecimal rate4() {
        return new BigDecimal("1.48");
    }

    private BigDecimal rate5() {
        return new BigDecimal("1.85");
    }

    private BigDecimal rate6() {
        return new BigDecimal("2.22");
    }

    private BigDecimal rate7() {
        return new BigDecimal("2.59");
    }

    private BigDecimal rate8() {
        return new BigDecimal("2.96");
    }

    private BigDecimal rate9() {
        return new BigDecimal("3.33");
    }

    private BigDecimal rate10() {
        return new BigDecimal("3.70");
    }

    private BigDecimal rate11() {
        return new BigDecimal("4.07");
    }

    private BigDecimal rate12() {
        return new BigDecimal("4.44");
    }

    private BigDecimal rate13() {
        return new BigDecimal("4.81");
    }

    private BigDecimal rate14() {
        return new BigDecimal("5.18");
    }

    private BigDecimal rate15() {
        return new BigDecimal("5.55");
    }

    private BigDecimal rate16() {
        return new BigDecimal("5.92");
    }

    private BigDecimal rate17() {
        return new BigDecimal("6.29");
    }

    private BigDecimal rate18() {
        return new BigDecimal("6.66");
    }

    private BigDecimal rate19() {
        return new BigDecimal("7.03");
    }

    private BigDecimal rate20() {
        return new BigDecimal("7.40");
    }

    private BigDecimal rate21() {
        return new BigDecimal("7.77");
    }

    private BigDecimal rate22() {
        return new BigDecimal("8.14");
    }

    private BigDecimal rate23() {
        return new BigDecimal("8.51");
    }

    private BigDecimal rate24() {
        return new BigDecimal("8.88");
    }

    private BigDecimal rate25() {
        return new BigDecimal("9.25");
    }

    private BigDecimal rate26() {
        return new BigDecimal("9.62");
    }

    private BigDecimal rate27() {
        return new BigDecimal("9.99");
    }

    private BigDecimal rate28() {
        return new BigDecimal("10.36");
    }

    private BigDecimal rate29() {
        return new BigDecimal("10.73");
    }

    private BigDecimal rate30() {
        return new BigDecimal("11.10");
    }

    private BigDecimal rate31() {
        return new BigDecimal("11.47");
    }

    private BigDecimal rate32() {
        return new BigDecimal("11.84");
    }

    private BigDecimal rate33() {
        return new BigDecimal("12.21");
    }

    private BigDecimal rate34() {
        return new BigDecimal("12.58");
    }

    private BigDecimal rate35() {
        return new BigDecimal("12.95");
    }

    private BigDecimal rate36() {
        return new BigDecimal("13.32");
    }

    private BigDecimal rate37() {
        return new BigDecimal("13.69");
    }

    private BigDecimal rate38() {
        return new BigDecimal("14.06");
    }

    private BigDecimal rate39() {
        return new BigDecimal("14.43");
    }

    private BigDecimal rate40() {
        return new BigDecimal("14.80");
    }

    private BigDecimal rate41() {
        return new BigDecimal("15.17");
    }

    private BigDecimal rate42() {
        return new BigDecimal("15.54");
    }

    private BigDecimal rate43() {
        return new BigDecimal("15.91");
    }

    private BigDecimal rate44() {
        return new BigDecimal("16.28");
    }

    private BigDecimal rate45() {
        return new BigDecimal("16.65");
    }

    private BigDecimal rate46() {
        return new BigDecimal("17.02");
    }

    private BigDecimal rate47() {
        return new BigDecimal("17.39");
    }

    private BigDecimal rate48() {
        return new BigDecimal("17.76");
    }

    private BigDecimal rate49() {
        return new BigDecimal("18.13");
    }

    private BigDecimal rate50() {
        return new BigDecimal("18.50");
    }

    private BigDecimal rate51() {
        return new BigDecimal("18.87");
    }

    private BigDecimal rate52() {
        return new BigDecimal("19.24");
    }

    private BigDecimal rate53() {
        return new BigDecimal("19.61");
    }

    private BigDecimal rate54() {
        return new BigDecimal("19.98");
    }

    private BigDecimal rate55() {
        return new BigDecimal("20.35");
    }

    private BigDecimal rate56() {
        return new BigDecimal("20.72");
    }

    private BigDecimal rate57() {
        return new BigDecimal("21.09");
    }

    private BigDecimal rate58() {
        return new BigDecimal("21.46");
    }

    private BigDecimal rate59() {
        return new BigDecimal("21.83");
    }

    private BigDecimal rate60() {
        return new BigDecimal("22.20");
    }

    private BigDecimal rate61() {
        return new BigDecimal("22.57");
    }

    private BigDecimal rate62() {
        return new BigDecimal("22.94");
    }

    private BigDecimal rate63() {
        return new BigDecimal("23.31");
    }

    private BigDecimal rate64() {
        return new BigDecimal("23.68");
    }

    private BigDecimal rate65() {
        return new BigDecimal("24.05");
    }

    private BigDecimal rate66() {
        return new BigDecimal("24.42");
    }

    private BigDecimal rate67() {
        return new BigDecimal("24.79");
    }

    private BigDecimal rate68() {
        return new BigDecimal("25.16");
    }

    private BigDecimal rate69() {
        return new BigDecimal("25.53");
    }

    private BigDecimal rate70() {
        return new BigDecimal("25.90");
    }

    private BigDecimal rate71() {
        return new BigDecimal("26.27");
    }

    private BigDecimal rate72() {
        return new BigDecimal("26.64");
    }

    private BigDecimal rate73() {
        return new BigDecimal("27.01");
    }

    private BigDecimal rate74() {
        return new BigDecimal("27.38");
    }

    private BigDecimal rate75() {
        return new BigDecimal("27.75");
    }

    private BigDecimal rate76() {
        return new BigDecimal("28.12");
    }

    private BigDecimal rate77() {
        return new BigDecimal("28.49");
    }

    private BigDecimal rate78() {
        return new BigDecimal("28.86");
    }

    private BigDecimal rate79() {
        return new BigDecimal("29.23");
    }

    private BigDecimal rate80() {
        return new BigDecimal("29.60");
    }

    private BigDecimal rate81() {
        return new BigDecimal("29.97");
    }

    private BigDecimal rate82() {
        return new BigDecimal("30.34");
    }

    private BigDecimal rate83() {
        return new BigDecimal("30.71");
    }

    private BigDecimal rate84() {
        return new BigDecimal("31.08");
    }

    private BigDecimal rate85() {
        return new BigDecimal("31.45");
    }

    private BigDecimal rate86() {
        return new BigDecimal("31.82");
    }

    private BigDecimal rate87() {
        return new BigDecimal("32.19");
    }

    private BigDecimal rate88() {
        return new BigDecimal("32.56");
    }

    private BigDecimal rate89() {
        return new BigDecimal("32.93");
    }

    private BigDecimal rate90() {
        return new BigDecimal("33.30");
    }

    private BigDecimal rate91() {
        return new BigDecimal("33.67");
    }

    private BigDecimal rate92() {
        return new BigDecimal("34.04");
    }

    private BigDecimal rate93() {
        return new BigDecimal("34.41");
    }

    private BigDecimal rate94() {
        return new BigDecimal("34.78");
    }

    private BigDecimal rate95() {
        return new BigDecimal("35.15");
    }

    private BigDecimal rate96() {
        return new BigDecimal("35.52");
    }

    private BigDecimal rate97() {
        return new BigDecimal("35.89");
    }

    private BigDecimal rate98() {
        return new BigDecimal("36.26");
    }

    private BigDecimal rate99() {
        return new BigDecimal("36.63");
    }

    private BigDecimal rate100() {
        return new BigDecimal("37.00");
    }

    private BigDecimal rate101() {
        return new BigDecimal("37.37");
    }

    private BigDecimal rate102() {
        return new BigDecimal("37.74");
    }

    private BigDecimal rate103() {
        return new BigDecimal("38.11");
    }

    private BigDecimal rate104() {
        return new BigDecimal("38.48");
    }

    private BigDecimal rate105() {
        return new BigDecimal("38.85");
    }

    private BigDecimal rate106() {
        return new BigDecimal("39.22");
    }

    private BigDecimal rate107() {
        return new BigDecimal("39.59");
    }

    private BigDecimal rate108() {
        return new BigDecimal("39.96");
    }

    private BigDecimal rate109() {
        return new BigDecimal("40.33");
    }

    private BigDecimal rate110() {
        return new BigDecimal("40.70");
    }

    private BigDecimal rate111() {
        return new BigDecimal("41.07");
    }

    private BigDecimal rate112() {
        return new BigDecimal("41.44");
    }

    private BigDecimal rate113() {
        return new BigDecimal("41.81");
    }

    private BigDecimal rate114() {
        return new BigDecimal("42.18");
    }

    private BigDecimal rate115() {
        return new BigDecimal("42.55");
    }

    private BigDecimal rate116() {
        return new BigDecimal("42.92");
    }

    private BigDecimal rate117() {
        return new BigDecimal("43.29");
    }

    private BigDecimal rate118() {
        return new BigDecimal("43.66");
    }

    private BigDecimal rate119() {
        return new BigDecimal("44.03");
    }

    private BigDecimal rate120() {
        return new BigDecimal("44.40");
    }

    private BigDecimal rate121() {
        return new BigDecimal("44.77");
    }

    private BigDecimal rate122() {
        return new BigDecimal("45.14");
    }

    private BigDecimal rate123() {
        return new BigDecimal("45.51");
    }

    private BigDecimal rate124() {
        return new BigDecimal("45.88");
    }

    private BigDecimal rate125() {
        return new BigDecimal("46.25");
    }

    private BigDecimal rate126() {
        return new BigDecimal("46.62");
    }

    private BigDecimal rate127() {
        return new BigDecimal("46.99");
    }

    private BigDecimal rate128() {
        return new BigDecimal("47.36");
    }

    private BigDecimal rate129() {
        return new BigDecimal("47.73");
    }

    private BigDecimal rate130() {
        return new BigDecimal("48.10");
    }

    private BigDecimal rate131() {
        return new BigDecimal("48.47");
    }

    private BigDecimal rate132() {
        return new BigDecimal("48.84");
    }

    private BigDecimal rate133() {
        return new BigDecimal("49.21");
    }

    private BigDecimal rate134() {
        return new BigDecimal("49.58");
    }

    private BigDecimal rate135() {
        return new BigDecimal("49.95");
    }

    private BigDecimal rate136() {
        return new BigDecimal("50.32");
    }

    private BigDecimal rate137() {
        return new BigDecimal("50.69");
    }

    private BigDecimal rate138() {
        return new BigDecimal("51.06");
    }

    private BigDecimal rate139() {
        return new BigDecimal("51.43");
    }

    private BigDecimal rate140() {
        return new BigDecimal("51.80");
    }

    private BigDecimal rate141() {
        return new BigDecimal("52.17");
    }

    private BigDecimal rate142() {
        return new BigDecimal("52.54");
    }

    private BigDecimal rate143() {
        return new BigDecimal("52.91");
    }

    private BigDecimal rate144() {
        return new BigDecimal("53.28");
    }

    private BigDecimal rate145() {
        return new BigDecimal("53.65");
    }

    private BigDecimal rate146() {
        return new BigDecimal("54.02");
    }

    private BigDecimal rate147() {
        return new BigDecimal("54.39");
    }

    private BigDecimal rate148() {
        return new BigDecimal("54.76");
    }

    private BigDecimal rate149() {
        return new BigDecimal("55.13");
    }

    private BigDecimal rate150() {
        return new BigDecimal("55.50");
    }

    private BigDecimal rate151() {
        return new BigDecimal("55.87");
    }

    private BigDecimal rate152() {
        return new BigDecimal("56.24");
    }

    private BigDecimal rate153() {
        return new BigDecimal("56.61");
    }

    private BigDecimal rate154() {
        return new BigDecimal("56.98");
    }

    private BigDecimal rate155() {
        return new BigDecimal("57.35");
    }

    private BigDecimal rate156() {
        return new BigDecimal("57.72");
    }

    private BigDecimal rate157() {
        return new BigDecimal("58.09");
    }

    private BigDecimal rate158() {
        return new BigDecimal("58.46");
    }

    private BigDecimal rate159() {
        return new BigDecimal("58.83");
    }

    private BigDecimal rate160() {
        return new BigDecimal("59.20");
    }

    private BigDecimal rate161() {
        return new BigDecimal("59.57");
    }

    private BigDecimal rate162() {
        return new BigDecimal("59.94");
    }

    private BigDecimal rate163() {
        return new BigDecimal("60.31");
    }

    private BigDecimal rate164() {
        return new BigDecimal("60.68");
    }

    private BigDecimal rate165() {
        return new BigDecimal("61.05");
    }

    private BigDecimal rate166() {
        return new BigDecimal("61.42");
    }

    private BigDecimal rate167() {
        return new BigDecimal("61.79");
    }

    private BigDecimal rate168() {
        return new BigDecimal("62.16");
    }

    private BigDecimal rate169() {
        return new BigDecimal("62.53");
    }

    private BigDecimal rate170() {
        return new BigDecimal("62.90");
    }

    private BigDecimal rate171() {
        return new BigDecimal("63.27");
    }

    private BigDecimal rate172() {
        return new BigDecimal("63.64");
    }

    private BigDecimal rate173() {
        return new BigDecimal("64.01");
    }

    private BigDecimal rate174() {
        return new BigDecimal("64.38");
    }

    private BigDecimal rate175() {
        return new BigDecimal("64.75");
    }

    private BigDecimal rate176() {
        return new BigDecimal("65.12");
    }

    private BigDecimal rate177() {
        return new BigDecimal("65.49");
    }

    private BigDecimal rate178() {
        return new BigDecimal("65.86");
    }

    private BigDecimal rate179() {
        return new BigDecimal("66.23");
    }

    private BigDecimal rate180() {
        return new BigDecimal("66.60");
    }

    private BigDecimal rate181() {
        return new BigDecimal("66.97");
    }

    private BigDecimal rate182() {
        return new BigDecimal("67.34");
    }

    private BigDecimal rate183() {
        return new BigDecimal("67.71");
    }

    private BigDecimal rate184() {
        return new BigDecimal("68.08");
    }

    private BigDecimal rate185() {
        return new BigDecimal("68.45");
    }

    private BigDecimal rate186() {
        return new BigDecimal("68.82");
    }

    private BigDecimal rate187() {
        return new BigDecimal("69.19");
    }

    private BigDecimal rate188() {
        return new BigDecimal("69.56");
    }

    private BigDecimal rate189() {
        return new BigDecimal("69.93");
    }

    private BigDecimal rate190() {
        return new BigDecimal("70.30");
    }

    private BigDecimal rate191() {
        return new BigDecimal("70.67");
    }

    private BigDecimal rate192() {
        return new BigDecimal("71.04");
    }

    private BigDecimal rate193() {
        return new BigDecimal("71.41");
    }

    private BigDecimal rate194() {
        return new BigDecimal("71.78");
    }

    private BigDecimal rate195() {
        return new BigDecimal("72.15");
    }

    private BigDecimal rate196() {
        return new BigDecimal("72.52");
    }

    private BigDecimal rate197() {
        return new BigDecimal("72.89");
    }

    private BigDecimal rate198() {
        return new BigDecimal("73.26");
    }

    private BigDecimal rate199() {
        return new BigDecimal("73.63");
    }

    private BigDecimal rateBand(int band) {
        return switch (band) {
            case 0 -> rate0();
            case 1 -> rate1();
            case 2 -> rate2();
            case 3 -> rate3();
            case 4 -> rate4();
            case 5 -> rate5();
            case 6 -> rate6();
            case 7 -> rate7();
            case 8 -> rate8();
            case 9 -> rate9();
            case 10 -> rate10();
            case 11 -> rate11();
            case 12 -> rate12();
            case 13 -> rate13();
            case 14 -> rate14();
            case 15 -> rate15();
            case 16 -> rate16();
            case 17 -> rate17();
            case 18 -> rate18();
            case 19 -> rate19();
            case 20 -> rate20();
            case 21 -> rate21();
            case 22 -> rate22();
            case 23 -> rate23();
            case 24 -> rate24();
            case 25 -> rate25();
            case 26 -> rate26();
            case 27 -> rate27();
            case 28 -> rate28();
            case 29 -> rate29();
            case 30 -> rate30();
            case 31 -> rate31();
            case 32 -> rate32();
            case 33 -> rate33();
            case 34 -> rate34();
            case 35 -> rate35();
            case 36 -> rate36();
            case 37 -> rate37();
            case 38 -> rate38();
            case 39 -> rate39();
            case 40 -> rate40();
            case 41 -> rate41();
            case 42 -> rate42();
            case 43 -> rate43();
            case 44 -> rate44();
            case 45 -> rate45();
            case 46 -> rate46();
            case 47 -> rate47();
            case 48 -> rate48();
            case 49 -> rate49();
            case 50 -> rate50();
            case 51 -> rate51();
            case 52 -> rate52();
            case 53 -> rate53();
            case 54 -> rate54();
            case 55 -> rate55();
            case 56 -> rate56();
            case 57 -> rate57();
            case 58 -> rate58();
            case 59 -> rate59();
            case 60 -> rate60();
            case 61 -> rate61();
            case 62 -> rate62();
            case 63 -> rate63();
            case 64 -> rate64();
            case 65 -> rate65();
            case 66 -> rate66();
            case 67 -> rate67();
            case 68 -> rate68();
            case 69 -> rate69();
            case 70 -> rate70();
            case 71 -> rate71();
            case 72 -> rate72();
            case 73 -> rate73();
            case 74 -> rate74();
            case 75 -> rate75();
            case 76 -> rate76();
            case 77 -> rate77();
            case 78 -> rate78();
            case 79 -> rate79();
            case 80 -> rate80();
            case 81 -> rate81();
            case 82 -> rate82();
            case 83 -> rate83();
            case 84 -> rate84();
            case 85 -> rate85();
            case 86 -> rate86();
            case 87 -> rate87();
            case 88 -> rate88();
            case 89 -> rate89();
            case 90 -> rate90();
            case 91 -> rate91();
            case 92 -> rate92();
            case 93 -> rate93();
            case 94 -> rate94();
            case 95 -> rate95();
            case 96 -> rate96();
            case 97 -> rate97();
            case 98 -> rate98();
            case 99 -> rate99();
            case 100 -> rate100();
            case 101 -> rate101();
            case 102 -> rate102();
            case 103 -> rate103();
            case 104 -> rate104();
            case 105 -> rate105();
            case 106 -> rate106();
            case 107 -> rate107();
            case 108 -> rate108();
            case 109 -> rate109();
            case 110 -> rate110();
            case 111 -> rate111();
            case 112 -> rate112();
            case 113 -> rate113();
            case 114 -> rate114();
            case 115 -> rate115();
            case 116 -> rate116();
            case 117 -> rate117();
            case 118 -> rate118();
            case 119 -> rate119();
            case 120 -> rate120();
            case 121 -> rate121();
            case 122 -> rate122();
            case 123 -> rate123();
            case 124 -> rate124();
            case 125 -> rate125();
            case 126 -> rate126();
            case 127 -> rate127();
            case 128 -> rate128();
            case 129 -> rate129();
            case 130 -> rate130();
            case 131 -> rate131();
            case 132 -> rate132();
            case 133 -> rate133();
            case 134 -> rate134();
            case 135 -> rate135();
            case 136 -> rate136();
            case 137 -> rate137();
            case 138 -> rate138();
            case 139 -> rate139();
            case 140 -> rate140();
            case 141 -> rate141();
            case 142 -> rate142();
            case 143 -> rate143();
            case 144 -> rate144();
            case 145 -> rate145();
            case 146 -> rate146();
            case 147 -> rate147();
            case 148 -> rate148();
            case 149 -> rate149();
            case 150 -> rate150();
            case 151 -> rate151();
            case 152 -> rate152();
            case 153 -> rate153();
            case 154 -> rate154();
            case 155 -> rate155();
            case 156 -> rate156();
            case 157 -> rate157();
            case 158 -> rate158();
            case 159 -> rate159();
            case 160 -> rate160();
            case 161 -> rate161();
            case 162 -> rate162();
            case 163 -> rate163();
            case 164 -> rate164();
            case 165 -> rate165();
            case 166 -> rate166();
            case 167 -> rate167();
            case 168 -> rate168();
            case 169 -> rate169();
            case 170 -> rate170();
            case 171 -> rate171();
            case 172 -> rate172();
            case 173 -> rate173();
            case 174 -> rate174();
            case 175 -> rate175();
            case 176 -> rate176();
            case 177 -> rate177();
            case 178 -> rate178();
            case 179 -> rate179();
            case 180 -> rate180();
            case 181 -> rate181();
            case 182 -> rate182();
            case 183 -> rate183();
            case 184 -> rate184();
            case 185 -> rate185();
            case 186 -> rate186();
            case 187 -> rate187();
            case 188 -> rate188();
            case 189 -> rate189();
            case 190 -> rate190();
            case 191 -> rate191();
            case 192 -> rate192();
            case 193 -> rate193();
            case 194 -> rate194();
            case 195 -> rate195();
            case 196 -> rate196();
            case 197 -> rate197();
            case 198 -> rate198();
            case 199 -> rate199();
            default -> BigDecimal.ZERO;
        };
    }
}
