package com.rxflow.fulfillment;
import java.math.BigDecimal; import java.util.UUID;
public record OrderSubmittedEvent(UUID orderId,String patientId,BigDecimal sphere,BigDecimal cylinder,int axis,String labCode) { }
