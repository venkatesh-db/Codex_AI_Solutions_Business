package com.rxflow.fulfillment;

import java.time.Duration;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

@Component
public class JobLock {
    private final StringRedisTemplate redis;
    public JobLock(StringRedisTemplate redis) { this.redis = redis; }
    public boolean acquire(String orderId) {
        return Boolean.TRUE.equals(redis.opsForValue().setIfAbsent("job-lock:" + orderId, "1", Duration.ofMinutes(5)));
    }
}
