package com.rxflow.fulfillment;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rxflow.connectors.LabConnector;
import com.rxflow.orders.model.RxOrder;
import com.rxflow.orders.repo.OrderRepository;
import java.util.UUID;
import java.util.concurrent.Executor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class LabJobWorker {
    private static final Logger LOG=LoggerFactory.getLogger(LabJobWorker.class);
    private final Executor executor; private final OrderRepository orders; private final LabConnector connector;
    private final KafkaTemplate<String,Object> kafka; private final ObjectMapper mapper;
    public LabJobWorker(@Qualifier("labExecutor") Executor executor,OrderRepository orders,LabConnector connector,KafkaTemplate<String,Object> kafka,ObjectMapper mapper){this.executor=executor;this.orders=orders;this.connector=connector;this.kafka=kafka;this.mapper=mapper;}
    public void enqueue(UUID id){executor.execute(()->processWithRetry(id));}
    void processWithRetry(UUID id){
        for(int attempt=0;attempt<3;attempt++){
            try{process(id);return;}catch(IllegalStateException exception){LOG.warn("Lab submission attempt {} failed for {}",attempt+1,id);}
        }
    }
    void process(UUID id){
        RxOrder order=orders.findById(id).orElseThrow();
        try { connector.schedule(mapper.writeValueAsString(order)); } catch(JsonProcessingException e){throw new IllegalStateException(e);}
        order.setStatus("SCHEDULED"); orders.save(order);
        kafka.send("rxflow.orders",id.toString(),new OrderSubmittedEvent(id,order.getPatientId(),order.getSphere(),order.getCylinder(),order.getAxis(),order.getLabCode()));
    }
}
