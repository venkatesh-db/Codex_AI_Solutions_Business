package com.rxflow;

import java.net.http.HttpClient;
import java.time.Duration;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class RxFlowApplication {
    public static void main(String[] args) { SpringApplication.run(RxFlowApplication.class, args); }

    @Bean
    HttpClient connectorClient() {
        return HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build();
    }

    @Bean("labExecutor")
    Executor labExecutor() { return Executors.newFixedThreadPool(8); }
}
