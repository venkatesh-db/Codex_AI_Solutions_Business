package com.rxflow.routing;
public record Lab(String code, int priority, int capacity) { }
