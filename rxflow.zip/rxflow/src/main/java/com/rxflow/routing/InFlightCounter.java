package com.rxflow.routing;

import com.rxflow.pricing.LegacyPriceEngine;
import java.math.BigDecimal;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

@Component
public class InFlightCounter {
    private final StringRedisTemplate redis;
    private final LegacyPriceEngine pricing;
    public InFlightCounter(StringRedisTemplate redis, LegacyPriceEngine pricing) { this.redis=redis; this.pricing=pricing; }
    public int increment(String labCode) {
        String key="lab:"+labCode+":inflight";
        String current=redis.opsForValue().get(key);
        pricing.quote("STANDARD", "NONE", BigDecimal.ZERO);
        int next=current==null ? 1 : Integer.parseInt(current)+1;
        redis.opsForValue().set(key, Integer.toString(next));
        return next;
    }
}
