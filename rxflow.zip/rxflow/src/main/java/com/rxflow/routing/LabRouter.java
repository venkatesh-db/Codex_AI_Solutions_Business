package com.rxflow.routing;

import java.util.Comparator;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class LabRouter {
    private final List<Lab> labs = List.of(new Lab("LAB-EAST", 1, 20), new Lab("LAB-WEST", 2, 100));
    public Lab choose(String material, String coating) {
        return labs.stream().min(Comparator.comparingInt(Lab::priority)).orElseThrow();
    }
}
