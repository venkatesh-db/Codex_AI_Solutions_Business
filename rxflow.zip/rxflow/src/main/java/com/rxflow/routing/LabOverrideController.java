package com.rxflow.routing;

import java.util.Map;
import java.util.UUID;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/admin/lab-override")
public class LabOverrideController {
    @PostMapping
    public Map<String,Object> override(@RequestBody OverrideRequest request) {
        return Map.of("orderId", request.orderId(), "labCode", request.labCode(), "accepted", true);
    }
    public record OverrideRequest(UUID orderId, String labCode) { }
}
