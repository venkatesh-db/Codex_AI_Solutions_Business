package com.rxflow.connectors;
import java.net.URI; import java.net.http.HttpClient; import java.net.http.HttpRequest; import java.net.http.HttpResponse; import java.time.Duration; import org.springframework.beans.factory.annotation.Value; import org.springframework.stereotype.Component;
@Component public class ShippingConnector {
 private final HttpClient client; private final String baseUrl;
 public ShippingConnector(HttpClient client,@Value("${rxflow.connectors.shipping}") String baseUrl){this.client=client;this.baseUrl=baseUrl;}
 public String label(String orderId){try{var req=HttpRequest.newBuilder(URI.create(baseUrl+"/labels/"+orderId)).timeout(Duration.ofSeconds(3)).POST(HttpRequest.BodyPublishers.noBody()).build();return client.send(req,HttpResponse.BodyHandlers.ofString()).body();}catch(Exception e){throw new IllegalStateException(e);}}
}
