package com.rxflow.connectors;
import java.net.URI; import java.net.http.HttpClient; import java.net.http.HttpRequest; import java.net.http.HttpResponse; import org.springframework.beans.factory.annotation.Value; import org.springframework.stereotype.Component;
@Component public class InventoryConnector {
 private final HttpClient client; private final String baseUrl;
 public InventoryConnector(HttpClient client,@Value("${rxflow.connectors.inventory}") String baseUrl){this.client=client;this.baseUrl=baseUrl;}
 public boolean available(String sku){try{return client.send(HttpRequest.newBuilder(URI.create(baseUrl+"/frames/"+sku)).GET().build(),HttpResponse.BodyHandlers.discarding()).statusCode()==200;}catch(Exception e){return true;}}
}
