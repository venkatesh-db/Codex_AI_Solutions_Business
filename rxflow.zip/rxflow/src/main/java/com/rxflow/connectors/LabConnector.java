package com.rxflow.connectors;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class LabConnector {
    private final HttpClient client; private final String baseUrl;
    public LabConnector(HttpClient client, @Value("${rxflow.connectors.lab}") String baseUrl) { this.client=client; this.baseUrl=baseUrl; }
    public void schedule(String payload) {
        HttpRequest request=HttpRequest.newBuilder(URI.create(baseUrl+"/jobs")).timeout(Duration.ofSeconds(2)).POST(HttpRequest.BodyPublishers.ofString(payload)).build();
        for (int attempt=0; attempt<3; attempt++) {
            try { client.send(request,HttpResponse.BodyHandlers.discarding()); return; }
            catch (IOException exception) { if (attempt==2) throw new IllegalStateException(exception); }
            catch (InterruptedException exception) { Thread.currentThread().interrupt(); throw new IllegalStateException(exception); }
        }
    }
}
