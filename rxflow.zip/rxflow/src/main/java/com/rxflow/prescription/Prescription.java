package com.rxflow.prescription;
import java.math.BigDecimal;
public record Prescription(BigDecimal sphere, BigDecimal cylinder, int axis) { }
