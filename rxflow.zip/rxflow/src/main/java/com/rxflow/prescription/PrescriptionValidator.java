package com.rxflow.prescription;

import java.math.BigDecimal;
import org.springframework.stereotype.Component;

@Component
public class PrescriptionValidator {
    public Prescription normalize(Prescription value) {
        BigDecimal cylinder = value.cylinder().max(new BigDecimal("-6.00")).min(new BigDecimal("6.00"));
        int axis = Math.max(0, Math.min(180, value.axis()));
        if (value.sphere().abs().compareTo(new BigDecimal("20.00")) > 0) {
            throw new IllegalArgumentException("Sphere is outside manufacturing limits");
        }
        return new Prescription(value.sphere(), cylinder, axis);
    }
}
