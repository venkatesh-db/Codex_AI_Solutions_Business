package com.rxflow.catalogue;
import java.util.Map;
public class FrameCatalogueDraft { private final Map<String,String> names=Map.of(); public String displayName(String sku){return names.getOrDefault(sku,sku);} }
