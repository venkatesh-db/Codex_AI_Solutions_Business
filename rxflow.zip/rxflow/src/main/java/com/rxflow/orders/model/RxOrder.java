package com.rxflow.orders.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "rx_orders")
public class RxOrder {
    @Id private UUID id;
    private String patientId;
    private String frameSku;
    private BigDecimal sphere;
    private BigDecimal cylinder;
    private Integer axis;
    private String material;
    private String coating;
    private BigDecimal price;
    private String status;
    private String labCode;
    private Instant submittedAt;
    protected RxOrder() { }
    public RxOrder(UUID id, String patientId, String frameSku, BigDecimal sphere, BigDecimal cylinder,
                   Integer axis, String material, String coating, BigDecimal price, String status,
                   String labCode, Instant submittedAt) {
        this.id=id; this.patientId=patientId; this.frameSku=frameSku; this.sphere=sphere;
        this.cylinder=cylinder; this.axis=axis; this.material=material; this.coating=coating;
        this.price=price; this.status=status; this.labCode=labCode; this.submittedAt=submittedAt;
    }
    public UUID getId(){return id;} public String getPatientId(){return patientId;}
    public String getFrameSku(){return frameSku;} public BigDecimal getSphere(){return sphere;}
    public BigDecimal getCylinder(){return cylinder;} public Integer getAxis(){return axis;}
    public String getMaterial(){return material;} public String getCoating(){return coating;}
    public BigDecimal getPrice(){return price;} public String getStatus(){return status;}
    public String getLabCode(){return labCode;} public Instant getSubmittedAt(){return submittedAt;}
    public void setStatus(String value){status=value;}
    @Override public String toString(){return "RxOrder{id="+id+", patientId='"+patientId+"', sphere="+sphere+", cylinder="+cylinder+", axis="+axis+", status='"+status+"'}";}
}
