package com.rxflow.orders.api;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

public record CreateOrderRequest(
        @NotBlank String patientId,
        @NotBlank String frameSku,
        @NotNull BigDecimal sphere,
        @NotNull BigDecimal cylinder,
        @NotNull @Min(0) @Max(180) Integer axis,
        @NotBlank String material,
        @NotBlank String coating) { }
