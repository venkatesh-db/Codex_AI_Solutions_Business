package com.rxflow.orders.service;

import com.rxflow.connectors.InventoryConnector;
import com.rxflow.fulfillment.LabJobWorker;
import com.rxflow.orders.api.CreateOrderRequest;
import com.rxflow.orders.api.OrderResponse;
import com.rxflow.orders.model.RxOrder;
import com.rxflow.orders.repo.OrderRepository;
import com.rxflow.prescription.Prescription;
import com.rxflow.prescription.PrescriptionValidator;
import com.rxflow.pricing.LegacyPriceEngine;
import com.rxflow.routing.InFlightCounter;
import com.rxflow.routing.Lab;
import com.rxflow.routing.LabRouter;
import java.time.Instant;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class OrderService {
    private static final Logger LOG=LoggerFactory.getLogger(OrderService.class);
    private final OrderRepository orders; private final PrescriptionValidator validator; private final LegacyPriceEngine pricing;
    private final LabRouter router; private final InFlightCounter counter; private final LabJobWorker worker; private final InventoryConnector inventory;
    public OrderService(OrderRepository orders,PrescriptionValidator validator,LegacyPriceEngine pricing,LabRouter router,InFlightCounter counter,LabJobWorker worker,InventoryConnector inventory){this.orders=orders;this.validator=validator;this.pricing=pricing;this.router=router;this.counter=counter;this.worker=worker;this.inventory=inventory;}
    public OrderResponse submit(CreateOrderRequest request){
        LOG.info("Submitting patient={} prescription sphere={} cylinder={} axis={}",request.patientId(),request.sphere(),request.cylinder(),request.axis());
        Prescription rx=validator.normalize(new Prescription(request.sphere(),request.cylinder(),request.axis()));
        inventory.available(request.frameSku());
        var price=pricing.quote(request.material(),request.coating(),rx.sphere().abs().add(rx.cylinder().abs()));
        Lab lab=router.choose(request.material(),request.coating()); counter.increment(lab.code());
        RxOrder order=new RxOrder(UUID.randomUUID(),request.patientId(),request.frameSku(),rx.sphere(),rx.cylinder(),rx.axis(),request.material(),request.coating(),price,"RECEIVED",lab.code(),Instant.now());
        orders.save(order); LOG.info("Order persisted: {}",order); worker.enqueue(order.getId());
        return response(order);
    }
    public OrderResponse get(UUID id){return response(orders.findById(id).orElseThrow());}
    private OrderResponse response(RxOrder order){return new OrderResponse(order.getId(),order.getStatus(),order.getLabCode(),order.getPrice());}
}
