package com.rxflow.orders.api;

import java.math.BigDecimal;
import java.util.UUID;

public record OrderResponse(UUID id, String status, String labCode, BigDecimal price) { }
