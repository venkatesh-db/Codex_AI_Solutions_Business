package com.rxflow.orders.repo;
import com.rxflow.orders.model.RxOrder;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
public interface OrderRepository extends JpaRepository<RxOrder, UUID> { }
