package com.rxflow.orders.api;

import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {
    @GetMapping("/")
    public Map<String, Object> home() {
        return Map.of(
                "service", "RxFlow",
                "purpose", "Prescription-to-lens corporate training lab",
                "status", "ready",
                "ordersEndpoint", "POST /orders",
                "authentication", "Authorization: Bearer training-token");
    }
}
