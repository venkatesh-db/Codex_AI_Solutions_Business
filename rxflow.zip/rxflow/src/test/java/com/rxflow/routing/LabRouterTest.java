package com.rxflow.routing;
import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;
class LabRouterTest { @Test void selectsConfiguredLab(){assertThat(new LabRouter().choose("POLYCARBONATE","AR").code()).isEqualTo("LAB-EAST");} }
