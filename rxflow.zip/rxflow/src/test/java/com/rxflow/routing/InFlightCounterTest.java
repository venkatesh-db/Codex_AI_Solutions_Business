package com.rxflow.routing;
import static org.assertj.core.api.Assertions.assertThat; import static org.mockito.Mockito.*;
import com.rxflow.pricing.LegacyPriceEngine; import org.junit.jupiter.api.Test; import org.springframework.data.redis.core.*;
class InFlightCounterTest {
 @Test void incrementsExistingCount(){StringRedisTemplate redis=mock(StringRedisTemplate.class); ValueOperations<String,String> values=mock(ValueOperations.class);when(redis.opsForValue()).thenReturn(values);when(values.get("lab:LAB-EAST:inflight")).thenReturn("4");assertThat(new InFlightCounter(redis,new LegacyPriceEngine()).increment("LAB-EAST")).isEqualTo(5);verify(values).set("lab:LAB-EAST:inflight","5");}
}
