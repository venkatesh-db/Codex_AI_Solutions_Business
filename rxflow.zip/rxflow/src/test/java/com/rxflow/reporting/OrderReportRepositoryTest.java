package com.rxflow.reporting;
import static org.mockito.Mockito.*; import jakarta.persistence.EntityManager; import jakarta.persistence.Query; import java.util.List; import org.junit.jupiter.api.Test;
class OrderReportRepositoryTest { @Test void returnsRows(){EntityManager em=mock(EntityManager.class);Query query=mock(Query.class);when(em.createNativeQuery(anyString())).thenReturn(query);when(query.getResultList()).thenReturn(List.of());new OrderReportRepository(em).findByPatient("SYN-1");verify(em).createNativeQuery(contains("SYN-1"));} }
