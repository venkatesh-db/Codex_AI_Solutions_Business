package com.rxflow.reporting;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import org.junit.jupiter.api.Test;

class ThroughputCalculatorTest {
    private static final Instant START = Instant.parse("2026-01-15T08:00:00Z");
    private static final Instant END = Instant.parse("2026-01-15T12:00:00Z");
    private final ThroughputCalculator calculator = new ThroughputCalculator();

    @Test
    void excludesOfflineGapFromThroughputDenominator() {
        ThroughputReport report = calculator.calculate(
                START,
                END,
                completions(90, START.plusSeconds(30)),
                List.of(new OfflineInterval(
                        Instant.parse("2026-01-15T09:00:00Z"),
                        Instant.parse("2026-01-15T10:00:00Z"))));

        assertThat(report.completedJobs()).isEqualTo(90);
        assertThat(report.onlineDuration()).isEqualTo(Duration.ofHours(3));
        assertThat(report.jobsPerOnlineHour()).contains(new BigDecimal("30.000000"));
    }

    @Test
    void mergesAndClipsOverlappingAdjacentAndDuplicateGaps() {
        ThroughputReport report = calculator.calculate(
                START,
                END,
                List.of(),
                List.of(
                        new OfflineInterval(START.minusSeconds(60), START.plusSeconds(1800)),
                        new OfflineInterval(START, START.plusSeconds(1800)),
                        new OfflineInterval(START.plusSeconds(1200), START.plusSeconds(3600)),
                        new OfflineInterval(START.plusSeconds(3600), START.plusSeconds(5400)),
                        new OfflineInterval(END, END.plusSeconds(60))));

        assertThat(report.onlineDuration()).isEqualTo(Duration.ofHours(2).plusMinutes(30));
    }

    @Test
    void usesHalfOpenWindowAndDeduplicatesReplayedCompletions() {
        ThroughputReport report = calculator.calculate(
                START,
                END,
                List.of(
                        new Completion("before", START.minusNanos(1)),
                        new Completion("first", START),
                        new Completion("first", START.plusSeconds(30)),
                        new Completion("last", END.minusNanos(1)),
                        new Completion("at-end", END)),
                List.of());

        assertThat(report.completedJobs()).isEqualTo(2);
        assertThat(report.jobsPerOnlineHour()).contains(new BigDecimal("0.500000"));
    }

    @Test
    void reportsUndefinedRateWhenLabWasOfflineForWholeWindow() {
        ThroughputReport report = calculator.calculate(
                START, END, List.of(), List.of(new OfflineInterval(START, END)));

        assertThat(report.onlineDuration()).isZero();
        assertThat(report.jobsPerOnlineHour()).isEmpty();
    }

    @Test
    void rejectsInvalidWindowsAndIntervals() {
        assertThatIllegalArgumentException()
                .isThrownBy(() -> calculator.calculate(START, START, List.of(), List.of()));
        assertThatIllegalArgumentException()
                .isThrownBy(() -> new OfflineInterval(START, START));
    }

    private List<Completion> completions(int count, Instant completedAt) {
        return java.util.stream.IntStream.range(0, count)
                .mapToObj(index -> new Completion("synthetic-job-" + index, completedAt))
                .toList();
    }
}
