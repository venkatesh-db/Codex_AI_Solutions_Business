package com.rxflow.fulfillment;
import static org.mockito.ArgumentMatchers.*; import static org.mockito.Mockito.*;
import com.fasterxml.jackson.databind.ObjectMapper; import com.rxflow.connectors.LabConnector; import com.rxflow.orders.model.RxOrder; import com.rxflow.orders.repo.OrderRepository; import java.math.BigDecimal; import java.time.Instant; import java.util.Optional; import java.util.UUID; import org.junit.jupiter.api.Test; import org.springframework.kafka.core.KafkaTemplate;
class LabJobWorkerTest {
 @Test void publishesScheduledJob(){UUID id=UUID.randomUUID();OrderRepository orders=mock(OrderRepository.class);LabConnector connector=mock(LabConnector.class);KafkaTemplate<String,Object> kafka=mock(KafkaTemplate.class);var order=new RxOrder(id,"SYN-2","F-2",BigDecimal.ONE,BigDecimal.ZERO,90,"STANDARD","NONE",BigDecimal.TEN,"RECEIVED","LAB-EAST",Instant.now());when(orders.findById(id)).thenReturn(Optional.of(order));new LabJobWorker(Runnable::run,orders,connector,kafka,new ObjectMapper().findAndRegisterModules()).process(id);verify(connector).schedule(anyString());verify(kafka).send(eq("rxflow.orders"),eq(id.toString()),any());}
}
