package com.rxflow.prescription;

import static org.assertj.core.api.Assertions.assertThat;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;

class PrescriptionValidatorTest {
    private final PrescriptionValidator validator = new PrescriptionValidator();
    @Test void acceptsManufacturablePrescription() {
        var input=new Prescription(new BigDecimal("-2.25"),new BigDecimal("-1.25"),92);
        assertThat(validator.normalize(input)).isEqualTo(input);
    }
}
